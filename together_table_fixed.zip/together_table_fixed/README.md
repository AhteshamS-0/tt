# 🍽️ Together Table v19

AI-powered food tracking, meal planning, and community donation app.  
Built with React · Powered by Gemini AI · Optional Firebase sync.

---

## ⚡ Quick Start (3 commands)

> **Requirements:** Node.js 18+ must be installed.  
> Check: `node -v` — if it shows v18 or higher, you are good to go.

```bash
# 1. Install dependencies
npm install

# 2. Set up your environment file
cp .env.example .env

# 3. Start the app
npm start
```

The app opens automatically at **http://localhost:3000**

> ✅ The app works immediately without any keys. Add them later for AI features.

---

## 🔑 Adding API Keys

Open the `.env` file in any text editor and paste your keys.

### Gemini Key — AI Meal Plans, Image Scan, Store Suggestions
1. Go to https://aistudio.google.com/app/apikey
2. Click **Create API Key** → copy it
3. In `.env`: `REACT_APP_GEMINI_API_KEY=AIza...your_key`

### Google Maps Key — Map view
1. Go to https://console.cloud.google.com
2. Create a project → Enable **Maps JavaScript API**
3. Credentials → Create API Key → copy it
4. In `.env`: `REACT_APP_GOOGLE_MAPS_KEY=AIza...your_key`

> 💡 You can also enter keys inside the app under **Settings → API Keys** — no file editing needed.

---

## ☁️ Optional Firebase (Cross-Device Sync)

Without Firebase all data saves to your browser — fine for single-device use.

1. Go to https://console.firebase.google.com → Add project → Continue
2. Click **</>** (Web) → Register app → copy the `firebaseConfig` values
3. **Build → Firestore Database → Create → Test Mode → Enable**
4. Paste each value into `.env` (see `.env.example` for the full list)

---

## 👥 Demo Accounts

| Username | Password | Role |
|---|---|---|
| `demo` | `demo` | Household |
| `foodbank` | `fb123` | Food Bank |
| `store` | `store123` | Business |

---

## 🛠️ Troubleshooting

**npm install fails**
```bash
npm cache clean --force && npm install
```

**Port 3000 in use**
```bash
PORT=3001 npm start          # Mac / Linux
set PORT=3001 && npm start   # Windows CMD
```

**Delete and reinstall node_modules**
```bash
rm -rf node_modules && npm install
```

**"No Gemini API key" in the app**  
Go to **Settings → API Keys** inside the app and paste your key there.
