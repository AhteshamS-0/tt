import React, { useState, useEffect, useMemo } from 'react'
import { dbLoad, dbSave, dbDelete, dbSubscribe } from './db.js'
import { isFirebaseConfigured } from './firebase.js'
import {
  mealPlans as MEAL_PLANS_DATA,
  emojiMap as EMOJI_MAP,
  recRules as REC_RULES,
  defaultFbState as DEFAULT_FB_STATE
} from './data.js'

// ─────────────────────────────────────────────
// SECURITY: Remove any API keys previously stored by users in localStorage.
// Keys are now managed exclusively via the server-side .env file.
;['tt_gemini_key', 'tt_maps_key'].forEach(k => localStorage.removeItem(k))

// ─────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────
function isOpenNow(s) {
  const now = new Date(), h = now.getHours() + now.getMinutes() / 60
  return s.openDays.includes(now.getDay()) && h >= s.openHours[0] && h < s.openHours[1]
}

const PLAN_SCORING = {
  loseweight:     {lowcalorie:3,keto:2,cuttinglean:2,intermittentfasting:2,dash:1,fodmap:1},
  gainmuscle:     {highprotein:3,bulking:2,cuttinglean:1},
  bulkup:         {bulking:3,highprotein:2},
  heartHealth:    {hearthealth:3,dash:3,mediterranean:2,antiinflammatory:2,plantbased:1},
  energy:         {mediterranean:2,bulking:1,whole30:2,plantbased:1,intermittentfasting:1},
  guthealth:      {fodmap:3,whole30:2,plantbased:2,mediterranean:1},
  immunity:       {cancersurvivor:2,antiinflammatory:3,mediterranean:2,vegan:1},
  recovery:       {cancersurvivor:3,antiinflammatory:2,postpartum:2,mediterranean:1},
  pregnancy:      {prenatal:4,postpartum:1},
  managediabetes: {diabeticfriendly:4,lowcalorie:2,mediterranean:2,dash:1},
  vegetarian:     {vegan:2,plantbased:2,mediterranean:1,whole30:-1,paleo:-1},
  vegan:          {vegan:4,plantbased:3},
  glutenfree:     {glutenfree:4,paleo:2,whole30:2},
  dairyfree:      {vegan:2,paleo:2,whole30:2,glutenfree:1},
  lowcarb:        {keto:4,cuttinglean:2,diabeticfriendly:2,lowcalorie:1},
  lowsodium:      {dash:3,kidneyfriendly:3,hearthealth:2},
  lowfat:         {lowcalorie:2,dash:2,hearthealth:2,diabeticfriendly:1},
  halal:          {mediterranean:1,highprotein:1},
  kosher:         {mediterranean:1},
  nuts:           {keto:-1,paleo:-1,whole30:-1},
  peanuts:        {},
  shellfish:      {},
  fish:           {mediterranean:-2,antiinflammatory:-2,dash:-1,cancersurvivor:-1},
  eggs:           {keto:-1,bulking:-1,whole30:-1},
  soy:            {vegan:-1,plantbased:-1},
  dairy:          {keto:-2,bulking:-1,highprotein:-1},
  wheat:          {glutenfree:2,paleo:1,whole30:1},
}

function guessEmoji(name) {
  const lower = name.toLowerCase().trim()
  for (const entry of EMOJI_MAP) {
    if (entry.k.some(k => lower === k || lower.includes(k) || k.includes(lower))) return entry.e
  }
  return '🍽️'
}

function stockStatus(qty, cat) {
  const n = { Grain: 4, Protein: 6, Dairy: 4, Vegetable: 4, Fruit: 6, Snack: 4, Beverage: 6, Condiment: 3 }
  const max = n[cat] || 4, r = qty / max
  if (qty === 0)  return { label: 'Empty',    cls: 'critical' }
  if (r <= 0.20)  return { label: 'Critical', cls: 'critical' }
  if (r <= 0.40)  return { label: 'Low',      cls: 'low' }
  if (r <= 0.65)  return { label: 'Medium',   cls: 'medium' }
  if (r <= 1.0)   return { label: 'Good',     cls: 'good' }
  return               { label: 'Plenty',  cls: 'plenty' }
}

const catToGroup = { Grain: 'carbs', Protein: 'proteins', Dairy: 'dairy', Vegetable: 'vegetables', Fruit: 'fruits', Snack: 'snacks', Beverage: 'beverages', Condiment: 'condiments', Other: 'meals' }

function isRelatedExclusion(excludeWord, itemName) {
  const ex = excludeWord.toLowerCase().trim()
  const it = itemName.toLowerCase().trim()
  if (it.includes(ex) || ex.includes(it)) return true
  const families = [
    ['beef','steak','ground beef','beef mince'],
    ['pork','bacon','ham','sausage','salami'],
    ['chicken','chicken breast','chicken thigh'],
    ['fish','salmon','tuna','cod','tilapia','sardine'],
    ['dairy','milk','cheese','butter','cream','yogurt','greek yogurt','cottage cheese'],
    ['gluten','wheat','bread','pasta','flour','beer','barley','rye'],
    ['nuts','almond','almonds','walnut','walnuts','cashew','mixed nuts'],
    ['sugar','candy','cookie','cake','pastry','chocolate'],
    ['alcohol','wine','beer','spirits'],
    ['soy','tofu','tempeh','edamame'],
    ['eggs','egg'],
  ]
  for (const family of families) {
    const exIn = family.some(k => ex === k || ex.includes(k) || k.includes(ex))
    const itIn = family.some(k => it === k || it.includes(k) || k.includes(it))
    if (exIn && itIn) return true
  }
  return false
}

const greenOptions = []
const dairyOptions = []

// ─────────────────────────────────────────────
// THEMES
// ─────────────────────────────────────────────
const THEME_VARS = {
  'earthy-light': { '--clay':'#c4714a','--sage':'#6b8c6e','--honey':'#e8a83e','--cream':'#f5f0e8','--earth':'#3d2e1e','--muted':'#9a8e7e','--page-bg':'#f5f0e8','--card-bg':'#ffffff','--input-bg':'#ffffff','--nav-bg':'#3d2e1e','--shadow':'0 2px 20px rgba(61,46,30,.08)' },
  'ocean-light':  { '--clay':'#2a7fc1','--sage':'#27a98e','--honey':'#3ab5d9','--cream':'#e8f4fb','--earth':'#0d2b3e','--muted':'#6b90a8','--page-bg':'#e8f4fb','--card-bg':'#ffffff','--input-bg':'#ffffff','--nav-bg':'#0d2b3e','--shadow':'0 2px 20px rgba(13,43,62,.1)' },
  'forest-light': { '--clay':'#5a7a3a','--sage':'#4e8b5e','--honey':'#8ab04a','--cream':'#ecf4e8','--earth':'#1e3018','--muted':'#7a9070','--page-bg':'#ecf4e8','--card-bg':'#ffffff','--input-bg':'#ffffff','--nav-bg':'#1e3018','--shadow':'0 2px 20px rgba(30,48,24,.1)' },
  'berry-light':  { '--clay':'#9b4d8a','--sage':'#c75b9a','--honey':'#d45b80','--cream':'#f5eaf5','--earth':'#3a1240','--muted':'#9a7aaa','--page-bg':'#f5eaf5','--card-bg':'#ffffff','--input-bg':'#ffffff','--nav-bg':'#3a1240','--shadow':'0 2px 20px rgba(58,18,64,.1)' },
  'slate-light':  { '--clay':'#5070a0','--sage':'#6080b0','--honey':'#7090c8','--cream':'#eef0f5','--earth':'#1c2a40','--muted':'#7080a0','--page-bg':'#eef0f5','--card-bg':'#ffffff','--input-bg':'#ffffff','--nav-bg':'#1c2a40','--shadow':'0 2px 20px rgba(28,42,64,.1)' },
}

function applyTheme(id) {
  const lightId = id.endsWith('-dark') ? id.replace('-dark', '-light') : id
  const vars = THEME_VARS[lightId] || THEME_VARS['earthy-light']
  const root = document.documentElement
  Object.entries(vars).forEach(([k, v]) => root.style.setProperty(k, v))
  root.classList.remove('dark')
}



// ─────────────────────────────────────────────
// API HELPERS  (Gemini + Google Maps)
// ─────────────────────────────────────────────
function getGeminiKey() { return process.env.REACT_APP_GEMINI_API_KEY || '' }
function getMapsKey()   { return process.env.REACT_APP_GOOGLE_MAPS_KEY  || '' }

// Robustly extract a JSON value (object or array) from a Gemini response
// that may include markdown fences, preamble text, or trailing commentary.
function extractGeminiJSON(text) {
  // 1. Strip markdown fences
  let cleaned = text.replace(/```json\s*/gi, '').replace(/```\s*/g, '').trim()

  // 2. Extract outermost JSON structure
  const objStart = cleaned.indexOf('{')
  const arrStart = cleaned.indexOf('[')
  let start, endChar
  if (objStart !== -1 && (arrStart === -1 || objStart < arrStart)) {
    start = objStart; endChar = '}'
  } else if (arrStart !== -1) {
    start = arrStart; endChar = ']'
  }
  if (start !== undefined) {
    const end = cleaned.lastIndexOf(endChar)
    if (end > start) cleaned = cleaned.substring(start, end + 1)
  }

  // 3. Fix trailing commas before } or ]
  cleaned = cleaned.replace(/,\s*([}\]])/g, '$1')

  // 4. Remove control characters that break JSON parsers (keep \n \r \t)
  // eslint-disable-next-line no-control-regex
  cleaned = cleaned.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, '')

  // 5. Attempt direct parse
  try { return JSON.parse(cleaned) } catch (_) {}

  // 6. Fix unescaped newlines/tabs inside string values
  cleaned = cleaned.replace(/"(?:[^"\\]|\\.)*"/g, m =>
    m.replace(/\n/g, '\\n').replace(/\r/g, '\\r').replace(/\t/g, '\\t')
  )
  try { return JSON.parse(cleaned) } catch (_) {}

  // 7. Try to repair truncated JSON by closing open structures
  let depth = 0; let inStr = false; let escape = false
  for (const ch of cleaned) {
    if (escape) { escape = false; continue }
    if (ch === '\\') { escape = true; continue }
    if (ch === '"') { inStr = !inStr; continue }
    if (!inStr) {
      if (ch === '{' || ch === '[') depth++
      else if (ch === '}' || ch === ']') depth--
    }
  }
  // Close any unclosed structures
  const closers = []
  let tmp = cleaned.replace(/,\s*$/, '') // remove trailing comma before we close
  // Re-scan to figure out what needs closing
  const stack = []
  inStr = false; escape = false
  for (const ch of tmp) {
    if (escape) { escape = false; continue }
    if (ch === '\\') { escape = true; continue }
    if (ch === '"') { inStr = !inStr; continue }
    if (!inStr) {
      if (ch === '{') stack.push('}')
      else if (ch === '[') stack.push(']')
      else if (ch === '}' || ch === ']') stack.pop()
    }
  }
  // If still in a string, close it
  if (inStr) tmp += '"'
  // Remove trailing comma again after possible string close
  tmp = tmp.replace(/,\s*$/, '')
  // Close all open brackets
  while (stack.length) tmp += stack.pop()
  try { return JSON.parse(tmp) } catch (_) {}

  throw new Error('Could not parse Gemini JSON response')
}

// Returns a good emoji for a meal based on name/type — guards against Gemini returning text instead
function mealEmoji(meal) {
  const raw = (meal.emoji || '').trim()
  // If it looks like a real emoji (non-ASCII, short), use it
  if (raw && raw.length <= 4 && /\p{Emoji}/u.test(raw)) return raw

  // Derive from meal name + type
  const text = ((meal.name || '') + ' ' + (meal.type || '')).toLowerCase()
  if (/breakfast|oat|pancake|waffle|egg|toast|muffin|yogurt|smoothie|granola|cereal/.test(text)) return '🍳'
  if (/lunch|sandwich|wrap|salad|soup|bowl|pita|bento/.test(text)) return '🥗'
  if (/dinner|supper|steak|roast|grill|bbq/.test(text)) return '🍽️'
  if (/snack|bar|bite|cracker|nut|trail/.test(text)) return '🥜'
  if (/pasta|spaghetti|lasagna|noodle|macaroni|penne/.test(text)) return '🍝'
  if (/rice|fried rice|pilaf|risotto|stir.fry/.test(text)) return '🍚'
  if (/pizza/.test(text)) return '🍕'
  if (/burger|sandwich|wrap|taco|burrito/.test(text)) return '🌮'
  if (/soup|stew|chili|broth/.test(text)) return '🍲'
  if (/chicken|poultry|turkey/.test(text)) return '🍗'
  if (/beef|steak|meat|lamb|pork/.test(text)) return '🥩'
  if (/fish|salmon|tuna|shrimp|seafood|cod|tilapia/.test(text)) return '🐟'
  if (/salad|greens|kale|spinach|arugula/.test(text)) return '🥗'
  if (/fruit|berry|apple|banana|mango|pineapple/.test(text)) return '🍎'
  if (/veggie|vegetable|tofu|tempeh|vegan|plant/.test(text)) return '🥦'
  if (/leftover/.test(text)) return '♻️'
  if (/curry/.test(text)) return '🍛'
  if (/sushi/.test(text)) return '🍱'
  if (/bread|toast/.test(text)) return '🍞'
  if (/dessert|cake|cookie|sweet/.test(text)) return '🍰'
  if (/coffee|tea|drink|juice|shake/.test(text)) return '☕'
  // Fallback by meal type
  if (/breakfast/i.test(meal.type)) return '🍳'
  if (/lunch/i.test(meal.type)) return '🥗'
  if (/dinner/i.test(meal.type)) return '🍽️'
  if (/snack/i.test(meal.type)) return '🥨'
  return '🍽️'
}

// Shared Gemini fetch config
const GEMINI_GEN_CFG = { maxOutputTokens: 4096, temperature: 0.7 }

// Hardcoded to best available free model — skips probe call for faster startup
// Model fallback list — tries each in order until one works
const GEMINI_MODELS_FALLBACK = [
  'gemini-2.5-flash',
  'gemini-2.5-flash-lite-preview-06-17',
  'gemini-2.0-flash',
  'gemini-2.0-flash-lite',
]
let _resolvedModel = null

async function getWorkingModel(key) {
  if (_resolvedModel) return _resolvedModel
  for (const model of GEMINI_MODELS_FALLBACK) {
    try {
      const res = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`,
        { method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ contents: [{ parts: [{ text: 'hi' }] }], generationConfig: { maxOutputTokens: 4 } }) }
      )
      if (res.ok) { _resolvedModel = model; console.log('[Gemini] using:', model); return model }
    } catch { /* try next */ }
  }
  throw new Error('No working Gemini model found — check your API key at aistudio.google.com')
}

async function callGemini(prompt) {
  const key = getGeminiKey()
  if (!key) throw new Error('AI features unavailable — Gemini API key not configured')
  const res = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${await getWorkingModel(key)}:generateContent?key=${key}`,
    { method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({
        contents: [{ parts:[{ text: prompt }] }],
        generationConfig: GEMINI_GEN_CFG
      }) }
  )
  if (!res.ok) throw new Error(`Gemini error ${res.status}`)
  const data = await res.json()
  return data.candidates?.[0]?.content?.parts?.[0]?.text || ''
}

// ─────────────────────────────────────────────
// CLOUD VISION — Image food scan (replaces Gemini Vision)
// Requires REACT_APP_GOOGLE_VISION_KEY in .env
// Enable "Cloud Vision API" at: https://console.cloud.google.com
// ─────────────────────────────────────────────
// eslint-disable-next-line no-unused-vars
function getVisionKey() { return process.env.REACT_APP_GOOGLE_VISION_KEY || '' }

// Maps Vision API labels → food category
// eslint-disable-next-line no-unused-vars
const VISION_CATEGORY_MAP = {
  // Fruits
  apple:'Fruit', banana:'Fruit', orange:'Fruit', grape:'Fruit', strawberry:'Fruit',
  watermelon:'Fruit', mango:'Fruit', pineapple:'Fruit', lemon:'Fruit', lime:'Fruit',
  peach:'Fruit', pear:'Fruit', cherry:'Fruit', blueberry:'Fruit', raspberry:'Fruit',
  avocado:'Fruit', tomato:'Vegetable', melon:'Fruit', kiwi:'Fruit',
  // Vegetables
  carrot:'Vegetable', broccoli:'Vegetable', spinach:'Vegetable', lettuce:'Vegetable',
  onion:'Vegetable', garlic:'Vegetable', potato:'Vegetable', pepper:'Vegetable',
  cucumber:'Vegetable', celery:'Vegetable', cabbage:'Vegetable', corn:'Vegetable',
  zucchini:'Vegetable', mushroom:'Vegetable', eggplant:'Vegetable', asparagus:'Vegetable',
  // Proteins
  chicken:'Protein', beef:'Protein', pork:'Protein', fish:'Protein', salmon:'Protein',
  tuna:'Protein', shrimp:'Protein', egg:'Protein', tofu:'Protein', turkey:'Protein',
  lamb:'Protein', steak:'Protein', sausage:'Protein', bacon:'Protein',
  // Dairy
  milk:'Dairy', cheese:'Dairy', yogurt:'Dairy', butter:'Dairy', cream:'Dairy',
  // Grains
  bread:'Grain', rice:'Grain', pasta:'Grain', cereal:'Grain', oat:'Grain',
  flour:'Grain', tortilla:'Grain', cracker:'Grain', bagel:'Grain', noodle:'Grain',
  // Beverages
  juice:'Beverage', coffee:'Beverage', tea:'Beverage', soda:'Beverage', water:'Beverage',
  beer:'Beverage', wine:'Beverage', smoothie:'Beverage',
  // Snacks
  chip:'Snack', cookie:'Snack', chocolate:'Snack', candy:'Snack',
  popcorn:'Snack', nut:'Snack', almond:'Snack', cashew:'Snack',
  // Condiments
  sauce:'Condiment', ketchup:'Condiment', mustard:'Condiment', mayonnaise:'Condiment',
  vinegar:'Condiment', oil:'Condiment', dressing:'Condiment', salt:'Condiment',
  spice:'Condiment', herb:'Condiment',
}

// A small curated emoji map for Vision labels
// eslint-disable-next-line no-unused-vars
const VISION_EMOJI_MAP = {
  apple:'🍎', banana:'🍌', orange:'🍊', grape:'🍇', strawberry:'🍓',
  watermelon:'🍉', mango:'🥭', pineapple:'🍍', lemon:'🍋', avocado:'🥑',
  tomato:'🍅', carrot:'🥕', broccoli:'🥦', corn:'🌽', pepper:'🫑',
  potato:'🥔', onion:'🧅', garlic:'🧄', mushroom:'🍄', lettuce:'🥬',
  chicken:'🍗', beef:'🥩', egg:'🥚', fish:'🐟', salmon:'🐟', shrimp:'🦐',
  tuna:'🐟', tofu:'🫘', sausage:'🌭', bacon:'🥓',
  milk:'🥛', cheese:'🧀', yogurt:'🫙', butter:'🧈',
  bread:'🍞', rice:'🍚', pasta:'🍝', cereal:'🥣', oat:'🌾',
  juice:'🧃', coffee:'☕', tea:'🍵', wine:'🍷', beer:'🍺', water:'💧',
  chocolate:'🍫', cookie:'🍪', almond:'🥜', nut:'🥜',
  ketchup:'🍅', oil:'🫙', salt:'🧂',
}

// ─────────────────────────────────────────────────────────────
// IMAGE FOOD SCAN
// Primary:  Gemini 2.0 Flash Vision  (understands complex scenes)
// Fallback: Google Cloud Vision API  (fast, label-based)
// ─────────────────────────────────────────────────────────────

// Canonical food list — only actual edible consumables allowed through
const CONSUMABLE_MAP = {
  // Fruit
  apple:'🍎',banana:'🍌',orange:'🍊',grape:'🍇',strawberry:'🍓',
  watermelon:'🍉',mango:'🥭',pineapple:'🍍',lemon:'🍋',lime:'🍋',
  peach:'🍑',pear:'🍐',cherry:'🍒',blueberry:'🫐',raspberry:'🍓',
  avocado:'🥑',melon:'🍈',kiwi:'🥝',fig:'🍇',plum:'🍑',
  grapefruit:'🍊',apricot:'🍑',pomegranate:'🍎',nectarine:'🍑',
  // Vegetables
  tomato:'🍅',carrot:'🥕',broccoli:'🥦',spinach:'🥬',lettuce:'🥬',
  onion:'🧅',garlic:'🧄',potato:'🥔',pepper:'🫑',cucumber:'🥒',
  celery:'🥬',cabbage:'🥬',corn:'🌽',zucchini:'🥒',mushroom:'🍄',
  eggplant:'🍆',asparagus:'🥦',beetroot:'🥕',beet:'🥕',radish:'🥕',
  kale:'🥬',arugula:'🥬',chard:'🥬',leek:'🧅',shallot:'🧅',
  'sweet potato':'🥔',yam:'🥔',turnip:'🥕',parsnip:'🥕',artichoke:'🥦',
  cauliflower:'🥦',fennel:'🥬','bok choy':'🥬',peas:'🫛',
  'green bean':'🫛','snap pea':'🫛',bean:'🫘',lentil:'🫘',
  // Protein
  egg:'🥚',chicken:'🍗',beef:'🥩',pork:'🥓',fish:'🐟',
  salmon:'🐟',tuna:'🐟',shrimp:'🦐',tofu:'🫘',turkey:'🦃',
  lamb:'🥩',steak:'🥩',sausage:'🌭',bacon:'🥓',ham:'🥩',
  crab:'🦀',lobster:'🦞',scallop:'🦪',oyster:'🦪',prawn:'🦐',
  // Dairy
  milk:'🥛',cheese:'🧀',yogurt:'🥛',butter:'🧈',cream:'🥛',
  'cream cheese':'🧀','sour cream':'🥛',brie:'🧀',cheddar:'🧀',
  mozzarella:'🧀',parmesan:'🧀',feta:'🧀',gouda:'🧀',
  // Grain & Bread
  bread:'🍞',rice:'🍚',pasta:'🍝',cereal:'🥣',oat:'🌾',
  flour:'🌾',tortilla:'🫓',cracker:'🍘',bagel:'🥯',noodle:'🍜',
  quinoa:'🌾',couscous:'🌾',barley:'🌾',wheat:'🌾',oatmeal:'🥣',
  // Beverages
  juice:'🧃',coffee:'☕',tea:'🍵',soda:'🥤',water:'💧',
  beer:'🍺',wine:'🍷',smoothie:'🥤',kombucha:'🍵',
  'orange juice':'🧃','apple juice':'🧃','milk jug':'🥛',
  // Condiments & Oils
  ketchup:'🍅',mustard:'🟡',mayonnaise:'🫙',vinegar:'🫙',
  oil:'🫙','olive oil':'🫙','soy sauce':'🫙',sauce:'🫙',
  dressing:'🫙',salsa:'🫙',hummus:'🫙',pesto:'🫙',
  syrup:'🍯',honey:'🍯',jam:'🍓',jelly:'🍓',
  // Herbs & Spices
  salt:'🧂',cinnamon:'🌿',cumin:'🌿',paprika:'🌿',
  oregano:'🌿',basil:'🌿',thyme:'🌿',rosemary:'🌿',parsley:'🌿',
  ginger:'🫚',turmeric:'🌿',chili:'🌶️',
  // Snacks & Sweet
  chocolate:'🍫',cookie:'🍪',almond:'🥜',nut:'🥜',peanut:'🥜',
  cashew:'🥜',walnut:'🥜',chip:'🍟',popcorn:'🍿',candy:'🍬',
  granola:'🥣',pretzel:'🥨',
  // Canned / Packaged foods (the food inside, not the can)
  'canned tomato':'🍅','canned bean':'🫘','canned corn':'🌽',
  'tomato sauce':'🫙','pasta sauce':'🫙','coconut milk':'🥛',
  'peanut butter':'🥜','almond butter':'🥜','tahini':'🫙',
}

const CATEGORY_MAP = {
  apple:'Fruit',banana:'Fruit',orange:'Fruit',grape:'Fruit',strawberry:'Fruit',
  watermelon:'Fruit',mango:'Fruit',pineapple:'Fruit',lemon:'Fruit',lime:'Fruit',
  peach:'Fruit',pear:'Fruit',cherry:'Fruit',blueberry:'Fruit',raspberry:'Fruit',
  avocado:'Fruit',melon:'Fruit',kiwi:'Fruit',fig:'Fruit',plum:'Fruit',
  grapefruit:'Fruit',apricot:'Fruit',pomegranate:'Fruit',nectarine:'Fruit',
  tomato:'Vegetable',carrot:'Vegetable',broccoli:'Vegetable',spinach:'Vegetable',
  lettuce:'Vegetable',onion:'Vegetable',garlic:'Vegetable',potato:'Vegetable',
  pepper:'Vegetable',cucumber:'Vegetable',celery:'Vegetable',cabbage:'Vegetable',
  corn:'Vegetable',zucchini:'Vegetable',mushroom:'Vegetable',eggplant:'Vegetable',
  asparagus:'Vegetable',beetroot:'Vegetable',beet:'Vegetable',radish:'Vegetable',
  kale:'Vegetable',arugula:'Vegetable',chard:'Vegetable',leek:'Vegetable',
  shallot:'Vegetable',yam:'Vegetable',turnip:'Vegetable',parsnip:'Vegetable',
  artichoke:'Vegetable',cauliflower:'Vegetable',fennel:'Vegetable',peas:'Vegetable',
  egg:'Protein',chicken:'Protein',beef:'Protein',pork:'Protein',fish:'Protein',
  salmon:'Protein',tuna:'Protein',shrimp:'Protein',tofu:'Protein',turkey:'Protein',
  lamb:'Protein',steak:'Protein',sausage:'Protein',bacon:'Protein',ham:'Protein',
  milk:'Dairy',cheese:'Dairy',yogurt:'Dairy',butter:'Dairy',cream:'Dairy',
  bread:'Grain',rice:'Grain',pasta:'Grain',cereal:'Grain',oat:'Grain',
  flour:'Grain',tortilla:'Grain',cracker:'Grain',bagel:'Grain',noodle:'Grain',
  quinoa:'Grain',couscous:'Grain',barley:'Grain',wheat:'Grain',oatmeal:'Grain',
  juice:'Beverage',coffee:'Beverage',tea:'Beverage',soda:'Beverage',water:'Beverage',
  beer:'Beverage',wine:'Beverage',smoothie:'Beverage',kombucha:'Beverage',
  ketchup:'Condiment',mustard:'Condiment',mayonnaise:'Condiment',oil:'Condiment',
  sauce:'Condiment',honey:'Condiment',jam:'Condiment',vinegar:'Condiment',
  salt:'Condiment',chocolate:'Snack',cookie:'Snack',almond:'Snack',
  nut:'Snack',peanut:'Snack',cashew:'Snack',chip:'Snack',popcorn:'Snack',
}

// TRUE non-consumables — packaging, equipment, surfaces only
const NON_CONSUMABLES = new Set([
  'bottle','can','jar','box','bag','container','wrapper','packaging','package',
  'cup','bowl','plate','pan','pot','tray','utensil','spoon','fork','knife',
  'table','counter','shelf','wood','plastic','glass','metal','paper','cardboard',
  'refrigerator','fridge','freezer','oven','microwave','stove','appliance',
  'label','brand','logo','text','sign','tableware','serveware','drinkware','kitchenware',
  'still life','major appliance','home appliance','kitchen appliance',
])

function matchConsumable(label) {
  const lower = label.toLowerCase().trim()
  if ([...NON_CONSUMABLES].some(kw => lower === kw)) return null
  // Exact or substring match in CONSUMABLE_MAP
  for (const [key, emoji] of Object.entries(CONSUMABLE_MAP)) {
    if (lower.includes(key) || key.includes(lower)) {
      const name = key.split(' ').map(w => w[0].toUpperCase()+w.slice(1)).join(' ')
      const category = CATEGORY_MAP[key] || 'Other'
      return { name, emoji, category, qty:1 }
    }
  }
  return null
}

// ── PRIMARY: Gemini Vision scan (much better at complex scenes) ──
async function callGeminiVisionScan(base64Data, mimeType = 'image/jpeg') {
  const key = getGeminiKey()
  if (!key) return null // fall through to Vision API

  const prompt = `You are a food pantry assistant. Look at this image carefully and list ONLY the actual edible food and drink items you can see.

STRICT RULES:
- Only include items a person would eat or drink
- Do NOT include: containers, bottles, jars, cans, bags, packaging, bowls, plates, appliances, shelves, or any non-food objects
- Do NOT include brand names — just the food type (e.g. "orange juice" not "Tropicana")
- Be specific: "carrot" not "vegetable", "cheddar cheese" not "dairy"
- If you see a container whose food contents are visible or obvious (e.g. a juice carton), include the food (e.g. "orange juice")
- Estimate qty if multiples are clearly visible

Return ONLY a JSON array, no markdown, no explanation:
[{"name":"Carrots","emoji":"🥕","category":"Vegetable","qty":3},{"name":"Milk","emoji":"🥛","category":"Dairy","qty":1}]

Categories must be one of: Fruit, Vegetable, Protein, Dairy, Grain, Beverage, Condiment, Snack, Other
If no food is visible return: []`

  const model = await getWorkingModel(key)
  const res = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`,
    { method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ contents:[{ parts:[
        { inline_data:{ mime_type: mimeType, data: base64Data } },
        { text: prompt }
      ]}] })
    }
  )
  if (!res.ok) return null
  const data = await res.json()
  const text = (data.candidates?.[0]?.content?.parts?.[0]?.text || '').trim()
  const match = text.match(/\[[\s\S]*\]/)
  if (!match) return null
  try {
    const items = JSON.parse(match[0])
    // Post-process: strip any non-consumables that slipped through
    return items.filter(item => {
      const lower = item.name.toLowerCase()
      return ![...NON_CONSUMABLES].some(kw => lower === kw || lower.includes('container') || lower.includes('bottle') || lower.includes('jar') || lower.includes('can') || lower.includes('packaging'))
    }).map(item => ({
      name: item.name,
      emoji: item.emoji || matchConsumable(item.name)?.emoji || '🍽️',
      category: item.category || 'Other',
      qty: item.qty || 1
    }))
  } catch { return null }
}

// ── FALLBACK: Google Cloud Vision API ──
async function callCloudVisionFallback(base64Data) {
  const key = process.env.REACT_APP_GOOGLE_VISION_KEY || ''
  if (!key) return []
  const res = await fetch(
    `https://vision.googleapis.com/v1/images:annotate?key=${key}`,
    { method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ requests:[{ image:{ content: base64Data }, features:[
        { type:'LABEL_DETECTION', maxResults:40 },
        { type:'OBJECT_LOCALIZATION', maxResults:30 },
        { type:'WEB_DETECTION', maxResults:20 },
      ]}] })
    }
  )
  if (!res.ok) throw new Error(`Cloud Vision error ${res.status}`)
  const data = await res.json()
  const resp = data.responses?.[0]
  if (!resp) return []

  const candidates = new Map()
  const addCandidate = (label, score) => {
    const item = matchConsumable(label)
    if (!item) return
    const k = item.name.toLowerCase()
    if (!candidates.has(k) || candidates.get(k).score < score)
      candidates.set(k, { ...item, score })
  }

  ;(resp.labelAnnotations || []).forEach(l => addCandidate(l.description, l.score))
  ;(resp.localizedObjectAnnotations || []).forEach(o => addCandidate(o.name, o.score))
  ;(resp.webDetection?.webEntities || []).forEach(e => {
    if (e.description && e.score > 0.4) addCandidate(e.description, e.score)
  })

  return [...candidates.values()]
    .sort((a,b) => b.score - a.score)
    .slice(0, 20)
    .map(({ score, ...item }) => item)
}

// ── MAIN ENTRY: try Gemini first, fall back to Cloud Vision ──
async function callCloudVision(base64Data, mimeType = 'image/jpeg') {
  // Try Gemini Vision first (far superior for complex scenes)
  const geminiItems = await callGeminiVisionScan(base64Data, mimeType)
  if (geminiItems && geminiItems.length > 0) return geminiItems

  // Fallback to Cloud Vision if Gemini key missing or returned nothing
  const visionKey = process.env.REACT_APP_GOOGLE_VISION_KEY || ''
  if (!visionKey) throw new Error('Image scan unavailable — add REACT_APP_GEMINI_API_KEY or REACT_APP_GOOGLE_VISION_KEY to your .env file.')
  return callCloudVisionFallback(base64Data)
}

// Gemini AI Meal Plan generation
async function callGeminiMealPlan(planName, pantryItems, preferences = '') {
  const key = getGeminiKey()
  if (!key) throw new Error('AI features unavailable — Gemini API key not configured')
  const prompt = `You are a professional nutritionist and meal planner. Create a 7-day meal plan for the "${planName}" diet.${preferences ? ' Additional preferences: ' + preferences + '.' : ''} Return ONLY a raw JSON object — no markdown fences, no preamble, no trailing text: {"planName":"${planName}","days":[{"day":"Monday","meals":[{"type":"Breakfast","name":"Meal name","ingredients":["item1","item2"],"calories":350,"time":"10 min","emoji":"🍳"},{"type":"Lunch","name":"Meal name","ingredients":["item1"],"calories":450,"time":"15 min","emoji":"🥗"},{"type":"Dinner","name":"Meal name","ingredients":["item1","item2","item3"],"calories":600,"time":"30 min","emoji":"🍝"}]}],"shoppingList":[{"name":"Lean Proteins","emoji":"🥩","reason":"Essential for this diet"},{"name":"Fresh Vegetables","emoji":"🥦","reason":"Core of every meal"}],"weeklyCalories":14700,"tips":"One key dietary tip"} Important: shoppingList must have 10-15 grouped category items only (like "Lean Proteins", "Whole Grains") — never individual ingredients. Include all 7 days.`
  const model = await getWorkingModel(key)
  const res = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`,
    { method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({
        contents: [{ parts:[{ text: prompt }] }],
        generationConfig: { ...GEMINI_GEN_CFG, maxOutputTokens: 8192 }
      }) }
  )
  if (!res.ok) throw new Error(`Gemini error ${res.status}`)
  const data = await res.json()
  const text = data.candidates?.[0]?.content?.parts?.[0]?.text || '{}'
  return extractGeminiJSON(text)
}

// Gemini AI Store Suggestions
// eslint-disable-next-line no-unused-vars
async function callGeminiStoreSuggestions(pantryItems, activePlan, nearbyStores) {
  const key = getGeminiKey()
  if (!key) throw new Error('AI features unavailable — Gemini API key not configured')
  const pantryStr = pantryItems.map(f => `${f.name}(qty:${f.qty})`).join(', ')
  const storeStr = nearbyStores.map(s => s.name).join(', ')
  const prompt = `You are a smart grocery advisor. User's current pantry: ${pantryStr || 'empty'}. Active diet plan: ${activePlan || 'none'}. Nearby stores: ${storeStr || 'general grocery stores'}. Analyze what the user is low on or missing for their diet plan and give personalized store shopping suggestions. Return ONLY valid JSON: {"urgentItems":[{"name":"Eggs","emoji":"🥚","reason":"Low protein source, critical for your plan","store":"Whole Foods","estimatedPrice":"$4.99","priority":"high"}],"dealItems":[{"name":"Frozen Vegetables","emoji":"🥦","reason":"Budget-friendly, nutrient dense","store":"Costco","estimatedPrice":"$8.99","priority":"medium"}],"avoidItems":[{"name":"Sugary Cereals","emoji":"🥣","reason":"Conflicts with your ${activePlan} plan"}],"totalEstimate":"$45-60","tip":"Best shopping tip for this user"}`
  const model = await getWorkingModel(key)
  const res = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`,
    { method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({
        contents: [{ parts:[{ text: prompt }] }],
        generationConfig: GEMINI_GEN_CFG
      }) }
  )
  if (!res.ok) throw new Error(`Gemini error ${res.status}`)
  const data = await res.json()
  const text = data.candidates?.[0]?.content?.parts?.[0]?.text || '{}'
  return extractGeminiJSON(text)
}

let _mapsPromise = null
function loadGoogleMaps() {
  if (_mapsPromise) return _mapsPromise
  const key = getMapsKey()
  if (!key) return Promise.reject(new Error('no-key'))
  _mapsPromise = new Promise((resolve, reject) => {
    if (window.google?.maps) { resolve(); return }
    const s = document.createElement('script')
    s.src = `https://maps.googleapis.com/maps/api/js?key=${key}`
    s.async = true
    s.defer = true
    s.onload  = () => resolve()
    s.onerror = () => { _mapsPromise = null; reject(new Error('Maps load failed')) }
    document.head.appendChild(s)
  })
  return _mapsPromise
}

// Marker color by location type
const MARKER_COLORS = {
  foodbank:   { fill: '#c4714a', label: 'Food Bank' },
  grocery:    { fill: '#2a7fc1', label: 'Grocery' },
  restaurant: { fill: '#27a98e', label: 'Restaurant' },
  user:       { fill: '#e8a83e', label: 'Your Location' },
  default:    { fill: '#6b8c6e', label: 'Location' },
}

// GoogleMap component — renders a real Google Map with markers
function GoogleMap({ markers = [], height = 280, centerLat, centerLng }) {
  const ref = React.useRef(null)
  const mapRef = React.useRef(null)
  const markersRef = React.useRef([])
  const [status, setStatus] = React.useState('loading')

  // Compute center: explicit prop > average of markers > LA fallback
  const computedCenter = React.useMemo(() => {
    if (centerLat && centerLng) return { lat: centerLat, lng: centerLng }
    const valid = markers.filter(m => m.lat && m.lng)
    if (!valid.length) return { lat: 34.0522, lng: -118.2437 }
    return {
      lat: valid.reduce((s, m) => s + m.lat, 0) / valid.length,
      lng: valid.reduce((s, m) => s + m.lng, 0) / valid.length,
    }
  }, [centerLat, centerLng, markers])

  // Initialize map once
  useEffect(() => {
    let cancelled = false
    loadGoogleMaps()
      .then(() => {
        if (cancelled || !ref.current) return
        mapRef.current = new window.google.maps.Map(ref.current, {
          center: computedCenter, zoom: 13,
          styles: [
            { featureType:'all', elementType:'geometry', stylers:[{ saturation:-15 }] },
            { featureType:'road', elementType:'geometry', stylers:[{ lightness:10 }] },
            { featureType:'poi', elementType:'labels', stylers:[{ visibility:'off' }] },
          ],
          zoomControl: true, streetViewControl: false, mapTypeControl: false, fullscreenControl: false,
        })
        setStatus('ok')
      })
      .catch(e => { if (!cancelled) setStatus(e.message === 'no-key' ? 'no-key' : 'error') })
    return () => { cancelled = true }
  }, [])

  // Update markers whenever list changes
  useEffect(() => { // eslint-disable-line react-hooks/exhaustive-deps
    if (!mapRef.current || status !== 'ok') return
    // Remove old markers
    markersRef.current.forEach(m => m.setMap(null))
    markersRef.current = []

    const validMarkers = markers.filter(m => m.lat && m.lng)
    if (!validMarkers.length) return

    const bounds = new window.google.maps.LatLngBounds()
    validMarkers.forEach(m => {
      const isUser = m.type === 'user'
      const color = (MARKER_COLORS[m.type] || MARKER_COLORS.default).fill
      const marker = new window.google.maps.Marker({
        position: { lat: m.lat, lng: m.lng },
        map: mapRef.current,
        title: m.name,
        zIndex: isUser ? 999 : undefined,
        icon: {
          path: window.google.maps.SymbolPath.CIRCLE,
          scale: isUser ? 11 : 9,
          fillColor: color, fillOpacity: 1,
          strokeColor: 'white',
          strokeWeight: isUser ? 3 : 2.5
        }
      })
      const typeLabel = (MARKER_COLORS[m.type] || MARKER_COLORS.default).label
      const info = new window.google.maps.InfoWindow({
        content: `<div style="font-family:'DM Sans',sans-serif;padding:6px 4px;min-width:150px">
          <div style="font-size:.85rem;font-weight:700;margin-bottom:3px">${m.name}</div>
          <div style="font-size:.74rem;color:#888;margin-bottom:2px">${m.address || ''}</div>
          ${m.hours ? `<div style="font-size:.72rem;color:#aaa">${m.hours}</div>` : ''}
          <div style="margin-top:5px"><span style="font-size:.68rem;background:${color}22;color:${color};padding:2px 7px;border-radius:50px;font-weight:700">${typeLabel}</span></div>
        </div>`
      })
      marker.addListener('click', () => info.open(mapRef.current, marker))
      markersRef.current.push(marker)
      bounds.extend({ lat: m.lat, lng: m.lng })
    })

    // Auto-fit bounds if multiple markers, else just center
    if (validMarkers.length > 1) {
      mapRef.current.fitBounds(bounds, 60)
    } else {
      mapRef.current.setCenter({ lat: validMarkers[0].lat, lng: validMarkers[0].lng })
      mapRef.current.setZoom(14)
    }
  }, [markers, status])

  if (status === 'no-key') return (
    <div style={{height, borderRadius:16, background:'linear-gradient(135deg,#d6e8d7,#c5ddc9)', display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', gap:8, color:'#5a7c5d', boxShadow:'var(--shadow)', marginBottom:18}}>
      <span style={{fontSize:'2rem'}}>🗺️</span>
      <span style={{fontSize:'.85rem', fontWeight:600}}>Google Maps</span>
      <span style={{fontSize:'.75rem', color:'#7a9070', textAlign:'center', padding:'0 20px'}}>Maps key is set in .env — reload the page if the map isn't appearing</span>
    </div>
  )
  if (status === 'error') return (
    <div style={{height, borderRadius:16, background:'#fde8dc', display:'flex', alignItems:'center', justifyContent:'center', color:'var(--clay)', fontSize:'.85rem', boxShadow:'var(--shadow)', marginBottom:18}}>
      ⚠️ Map failed to load
    </div>
  )
  return (
    <div style={{position:'relative'}}>
      <div ref={ref} style={{height, borderRadius:16, overflow:'hidden', boxShadow:'var(--shadow)', marginBottom:18}} />
      {markers.filter(m=>m.lat&&m.lng).length === 0 && status === 'ok' && (
        <div style={{position:'absolute',inset:0,display:'flex',alignItems:'center',justifyContent:'center',pointerEvents:'none'}}>
          <div style={{background:'rgba(255,255,255,.88)',borderRadius:10,padding:'8px 16px',fontSize:'.8rem',color:'var(--muted)',fontWeight:500,boxShadow:'0 2px 8px rgba(0,0,0,.1)'}}>
            📍 Locations will appear here as users register
          </div>
        </div>
      )}
    </div>
  )
}

function directionUrl(address) {
  return `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(address)}`
}

// Haversine great-circle distance in miles
function haversineDistMi(lat1, lng1, lat2, lng2) {
  if (lat1 == null || lng1 == null || lat2 == null || lng2 == null) return null
  const R = 3958.8 // Earth radius in miles
  const dLat = (lat2 - lat1) * Math.PI / 180
  const dLng = (lng2 - lng1) * Math.PI / 180
  const a = Math.sin(dLat / 2) ** 2 +
            Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
            Math.sin(dLng / 2) ** 2
  return +(R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))).toFixed(1)
}

// Geocode an address string → { lat, lng } | null
async function geocodeAddress(address) {
  if (!address || !address.trim()) return null
  try {
    await loadGoogleMaps()
    return await new Promise((resolve) => {
      const geocoder = new window.google.maps.Geocoder()
      geocoder.geocode({ address }, (results, status) => {
        if (status === 'OK' && results[0]) {
          const loc = results[0].geometry.location
          resolve({ lat: loc.lat(), lng: loc.lng() })
        } else {
          resolve(null)
        }
      })
    })
  } catch {
    return null
  }
}


// ─────────────────────────────────────────────
// TOAST
// ─────────────────────────────────────────────
function Toast({ msg }) {
  return (
    <div style={{
      position: 'fixed', bottom: 24, left: '50%', transform: 'translateX(-50%)',
      background: 'var(--earth)', color: 'white', padding: '12px 22px',
      borderRadius: 50, fontFamily: '"DM Sans",sans-serif', fontSize: '.85rem',
      fontWeight: 500, zIndex: 9999, boxShadow: '0 4px 20px rgba(0,0,0,.3)',
      maxWidth: '90vw', textAlign: 'center', animation: 'fadeUp .3s ease'
    }}>{msg}</div>
  )
}

// ─────────────────────────────────────────────
// RECOMMENDATION ENGINE
// ─────────────────────────────────────────────
function getDynamicRecs(pantry, activePlan, mealPlans, historyBuyList, historyAvoidList) {
  const expiredNames  = new Set(historyAvoidList.map(a => a.name))
  const consumedNames = new Set(historyBuyList.map(b => b.name))

  function getPlanAvoidNames() {
    if (activePlan === 'none' || !mealPlans[activePlan]) return new Set()
    return new Set(mealPlans[activePlan].avoid.map(a => a.name))
  }
  function isBlockedByPlan(name) {
    if (activePlan === 'none' || !mealPlans[activePlan]) return false
    return mealPlans[activePlan].avoid.some(a => isRelatedExclusion(a.name, name))
  }

  const planAvoidNames = getPlanAvoidNames()
  const blocked = name => expiredNames.has(name) || planAvoidNames.has(name) || isBlockedByPlan(name)

  // Plan buy items
  const planItems = activePlan !== 'none' && mealPlans[activePlan]
    ? mealPlans[activePlan].buy.filter(f => !isBlockedByPlan(f.name)).map(f => ({ ...f, baseReason: f.reason, source: 'plan' }))
    : []

  // Consumed → buy again
  const consumedRecs = historyBuyList
    .filter(b => !pantry.find(f => f.name === b.name) && !blocked(b.name))
    .map(b => ({ ...b, baseReason: 'You finished this last time — time to restock!', priority: 'high', source: 'consumed', foodGroup: catToGroup[b.category] || 'meals' }))

  // Plan recs
  const planRecs = planItems
    .filter(r => !pantry.find(f => f.name === r.name) && !expiredNames.has(r.name) && !consumedNames.has(r.name))
    .map(r => ({ ...r, source: 'plan', foodGroup: r.foodGroup || 'meals' }))

  // Resolve dynamic names
  function pickSpecificGreen() {
    const inPantry = new Set(pantry.map(f => f.name.toLowerCase()))
    const unused = greenOptions.filter(g => !inPantry.has(g.name.toLowerCase()))
    return unused.length ? unused[0] : greenOptions[0]
  }
  function pickSpecificDairy() {
    const inPantry = new Set(pantry.map(f => f.name.toLowerCase()))
    const unused = dairyOptions.filter(d => !inPantry.has(d.name.toLowerCase()))
    return unused.length ? unused[0] : dairyOptions[0]
  }

  const ruleRecs = REC_RULES
    .filter(r => r.condition(pantry))
    .map(r => {
      if (r.name === '_SPECIFIC_GREEN') { const g = pickSpecificGreen(); return { ...r, ...g } }
      if (r.name === '_SPECIFIC_DAIRY') { const d = pickSpecificDairy(); return { ...r, ...d, baseReason: d.reason } }
      return r
    })
    .filter(r => !blocked(r.name) && !consumedNames.has(r.name))
    .map(r => ({ ...r, source: 'smart' }))

  const seen = new Set()
  return [...consumedRecs, ...planRecs, ...ruleRecs].filter(r => {
    if (seen.has(r.name)) return false
    seen.add(r.name); return true
  }).slice(0, 24)
}

function getDynamicAvoid(pantry, activePlan, mealPlans, historyAvoidList) {
  const avoid = [], seenNames = new Set()
  historyAvoidList.forEach(a => {
    if (!seenNames.has(a.name)) {
      avoid.push({ ...a, reason: 'You threw this out last time — watch shelf life.', badge: 'expired', badgeLabel: 'Expired Before' })
      seenNames.add(a.name)
    }
  })
  if (activePlan !== 'none' && mealPlans[activePlan]) {
    mealPlans[activePlan].avoid.forEach(a => {
      if (!seenNames.has(a.name)) { avoid.push({ ...a }); seenNames.add(a.name) }
    })
  }
  pantry.filter(f => f.qty >= 4).forEach(f => {
    const key = `More ${f.name}`
    if (!seenNames.has(key)) {
      avoid.push({ emoji: f.emoji, name: key, reason: `Already have ${f.qty} — wait until you run low.`, badge: 'overstock', badgeLabel: 'Overstocked' })
      seenNames.add(key)
    }
  })
  const grainQty = pantry.filter(f => f.category === 'Grain').reduce((s, f) => s + f.qty, 0)
  if (grainQty >= 4 && !seenNames.has('White Bread')) {
    avoid.push({ emoji: '🍞', name: 'White Bread', reason: `Grains covered (${grainQty} units stocked).`, badge: 'duplicate', badgeLabel: 'Redundant' })
    seenNames.add('White Bread')
  }
  ;[
    { emoji: '🥤', name: 'Soda',           reason: 'High sugar, no nutritional value.',      badge: 'unhealthy', badgeLabel: 'Unhealthy' },
    { emoji: '🍪', name: 'Cookies',         reason: 'High sugar & low nutritional value.',    badge: 'unhealthy', badgeLabel: 'Unhealthy' },
    { emoji: '🥓', name: 'Processed Bacon', reason: 'High sodium; protein already covered.',  badge: 'unhealthy', badgeLabel: 'Unhealthy' },
    { emoji: '🧃', name: 'Juice Boxes',     reason: 'High sugar; whole fruit is better.',     badge: 'unhealthy', badgeLabel: 'Unhealthy' },
  ].forEach(a => { if (!seenNames.has(a.name)) { avoid.push(a); seenNames.add(a.name) } })
  return avoid
}

// ─────────────────────────────────────────────
// INITIAL STATE
// ─────────────────────────────────────────────
const DEFAULT_PANTRY = []

const DEMO_ACCOUNTS = [
  { username: 'demo',     password: 'demo',     role: 'customer'  },
  { username: 'foodbank', password: 'fb123',    role: 'foodbank', fbName: 'Community Food Bank', fbAddress: '100 Main St, Los Angeles, CA', fbHours: 'Mon–Sat 9am–5pm' },
  { username: 'store',    password: 'store123', role: 'business',  bizType: 'both', regStoreName: 'Fresh Mart', regStoreAddr: '500 Broadway, Los Angeles, CA', regRestName: 'Green Kitchen', regRestAddr: '502 Broadway, Los Angeles, CA' },
]

// ── One-time data wipe ────────────────────────────────────
// Clears all food banks, stores, restaurants, and user accounts
// from localStorage and Firestore on first load after this reset.
const DATA_RESET_VERSION = 'tt_reset_v2'
if (localStorage.getItem(DATA_RESET_VERSION) !== 'done') {
  const KEYS_TO_CLEAR = ['tt_shelters', 'tt_stores', 'tt_restaurants', 'tt_donations', 'tt_current_user']
  KEYS_TO_CLEAR.forEach(k => { try { localStorage.removeItem(k) } catch {} })
  // Seed demo accounts if none exist
  const existing = (() => { try { return JSON.parse(localStorage.getItem('tt_accounts') || '[]') } catch { return [] } })()
  if (!existing.length) {
    localStorage.setItem('tt_accounts', JSON.stringify(DEMO_ACCOUNTS))
  }
  Promise.all(KEYS_TO_CLEAR.map(k => dbDelete(k))).catch(() => {})
  localStorage.setItem(DATA_RESET_VERSION, 'done')
}

function loadFromStorage(key, fallback) {
  try {
    const v = localStorage.getItem(key)
    return v ? JSON.parse(v) : fallback
  } catch { return fallback }
}

// ─────────────────────────────────────────────
// SHARED SETTINGS PANEL
// ─────────────────────────────────────────────
const PALETTES = [
  { id: 'earthy',  label: '🌿 Earthy',  bg: '#c4714a', fg: '#6b8c6e',
    authGrad: 'linear-gradient(135deg,#2d1f12 0%,#4a3020 40%,#1e2e1a 100%)' },
  { id: 'ocean',   label: '🌊 Ocean',   bg: '#2a7fc1', fg: '#27a98e',
    authGrad: 'linear-gradient(135deg,#061824 0%,#0d2b3e 45%,#072220 100%)' },
  { id: 'forest',  label: '🌲 Forest',  bg: '#5a7a3a', fg: '#4e8b5e',
    authGrad: 'linear-gradient(135deg,#0d1a0a 0%,#1e3018 45%,#0a1e10 100%)' },
  { id: 'berry',   label: '🍇 Berry',   bg: '#9b4d8a', fg: '#c75b9a',
    authGrad: 'linear-gradient(135deg,#1a0824 0%,#3a1240 45%,#240c30 100%)' },
  { id: 'slate',   label: '🪨 Slate',   bg: '#5070a0', fg: '#6080b0',
    authGrad: 'linear-gradient(135deg,#08101e 0%,#1c2a40 45%,#0e1830 100%)' },
]

function SettingsPanel({ theme, onThemeChange, user, onLogout, onClearData, onExportData, locationSection = null }) {
  const [fontSize, setFontSizeState] = useState(() => localStorage.getItem('tt_font') || 'medium')
  const [units, setUnitsState] = useState(() => localStorage.getItem('tt_units') || 'metric')
  const [toggles, setToggles] = useState(() =>
    JSON.parse(localStorage.getItem('tt_toggles') || '{"notif_expiry":true,"notif_surplus":true,"notif_donate":false,"notif_shop":true,"privacy_analytics":true,"privacy_loc":true}')
  )

  const currentPalette = (theme || 'earthy-light').replace(/-light$|-dark$/, '')

  function setPalette(p) { onThemeChange(p + '-light') }
  function setFontSize(size) {
    setFontSizeState(size)
    localStorage.setItem('tt_font', size)
    document.documentElement.setAttribute('data-font', size)
  }
  function setUnits(u) {
    setUnitsState(u)
    localStorage.setItem('tt_units', u)
  }
  function toggleKey(key) {
    const next = { ...toggles, [key]: !toggles[key] }
    setToggles(next)
    localStorage.setItem('tt_toggles', JSON.stringify(next))
  }

  return (
    <div className="settings-wrap">
      <h1 className="view-title">⚙️ Settings</h1>
      <p className="view-sub" style={{ marginBottom: 20 }}>Personalise your TogetherTableAI experience.</p>

      {/* Appearance */}
      <div className="settings-section">
        <div className="settings-section-title">🎨 Appearance</div>
        <div className="settings-row settings-row-col">
          <div className="settings-row-info">
            <div className="settings-row-label">Colour Palette</div>
            <div className="settings-row-sub">Pick your favourite colour scheme</div>
          </div>
          <div className="settings-palette-grid">
            {PALETTES.map(p => (
              <button key={p.id} className={`palette-opt ${currentPalette === p.id ? 'selected' : ''}`} onClick={() => setPalette(p.id)}>
                <div className="palette-swatch" style={{ background: p.bg }}>
                  <div style={{ position: 'absolute', right: 0, top: 0, bottom: 0, width: '50%', background: p.fg }}></div>
                </div>
                <span className="palette-label">{p.label}</span>
              </button>
            ))}
          </div>
        </div>
        <div className="settings-row settings-row-col">
          <div className="settings-row-info">
            <div className="settings-row-label">Text Size</div>
            <div className="settings-row-sub">Adjust the app's base font size</div>
          </div>
          <div className="settings-seg">
            {['small','medium','large'].map(s => (
              <button key={s} className={`seg-btn ${fontSize === s ? 'active' : ''}`} onClick={() => setFontSize(s)}>
                {s.charAt(0).toUpperCase() + s.slice(1)}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Units */}
      <div className="settings-section">
        <div className="settings-section-title">📏 Units</div>
        <div className="settings-row settings-row-col">
          <div className="settings-row-info">
            <div className="settings-row-label">Measurement System</div>
            <div className="settings-row-sub">Measurement system for quantities</div>
          </div>
          <div className="settings-seg">
            <button className={`seg-btn ${units === 'metric' ? 'active' : ''}`} onClick={() => setUnits('metric')}>Metric</button>
            <button className={`seg-btn ${units === 'imperial' ? 'active' : ''}`} onClick={() => setUnits('imperial')}>Imperial</button>
          </div>
        </div>
      </div>

      {/* Notifications */}
      <div className="settings-section">
        <div className="settings-section-title">🔔 Notifications</div>
        {[
          ['notif_expiry',   'Expiry Reminders',     'Alert when pantry items are about to expire'],
          ['notif_surplus',  'Free Food Alerts',      'Notify when nearby surplus food is posted'],
          ['notif_donate',   'Donation Reminders',    'Remind you to drop off tagged donations'],
          ['notif_shop',     'Shopping Suggestions',  'Weekly AI-powered restocking ideas'],
        ].map(([key, label, sub]) => (
          <div key={key} className="settings-row">
            <div className="settings-row-info">
              <div className="settings-row-label">{label}</div>
              <div className="settings-row-sub">{sub}</div>
            </div>
            <button className={`settings-toggle ${toggles[key] ? 'on' : ''}`} onClick={() => toggleKey(key)} aria-label={`Toggle ${label}`}>
              <span className="toggle-knob"></span>
            </button>
          </div>
        ))}
      </div>

      {/* Privacy & Data */}
      <div className="settings-section">
        <div className="settings-section-title">🔒 Privacy &amp; Data</div>
        {[
          ['privacy_analytics', 'Share Anonymous Usage',  'Help improve the app with anonymous analytics'],
          ['privacy_loc',       'Location History',        'Save recent search locations'],
        ].map(([key, label, sub]) => (
          <div key={key} className="settings-row">
            <div className="settings-row-info">
              <div className="settings-row-label">{label}</div>
              <div className="settings-row-sub">{sub}</div>
            </div>
            <button className={`settings-toggle ${toggles[key] ? 'on' : ''}`} onClick={() => toggleKey(key)} aria-label={`Toggle ${label}`}>
              <span className="toggle-knob"></span>
            </button>
          </div>
        ))}
        {onClearData && (
          <button className="settings-action-btn" onClick={onClearData}>
            <span>🗑️</span>
            <div>
              <div className="settings-row-label">Clear Pantry Data</div>
              <div className="settings-row-sub">Remove all pantry items permanently</div>
            </div>
            <span className="settings-chevron">›</span>
          </button>
        )}
        {onExportData && (
          <button className="settings-action-btn" onClick={onExportData}>
            <span>📤</span>
            <div>
              <div className="settings-row-label">Export My Data</div>
              <div className="settings-row-sub">Download all your data as JSON</div>
            </div>
            <span className="settings-chevron">›</span>
          </button>
        )}
      </div>

      {/* Account */}
      <div className="settings-section">
        <div className="settings-section-title">👤 Account</div>
        <div className="settings-row">
          <div className="settings-row-info">
            <div className="settings-row-label">Username</div>
            <div className="settings-row-sub">@{user?.username || '—'}</div>
          </div>
        </div>
        <div className="settings-row">
          <div className="settings-row-info">
            <div className="settings-row-label">Account Type</div>
            <div className="settings-row-sub">
              {user?.role === 'foodbank' ? '🏛️ Food Bank' : user?.role === 'business' ? '💼 Business' : '🛒 Customer'}
            </div>
          </div>
        </div>
        <button className="settings-action-btn settings-action-danger" onClick={onLogout}>
          <span>🚪</span>
          <div>
            <div className="settings-row-label">Sign Out</div>
            <div className="settings-row-sub">You can sign back in at any time</div>
          </div>
          <span className="settings-chevron">›</span>
        </button>
      </div>

      {/* API Keys managed server-side via .env — not user-configurable */}

      {/* Firebase Setup */}
      <div className="settings-section">
        <div className="settings-section-title">🔥 Firebase Setup</div>
        <div className="settings-row settings-row-col">
          <div className="settings-row-info">
            <div className="settings-row-label" style={{ display:'flex', alignItems:'center', gap:8 }}>
              Database Status &nbsp;
              {isFirebaseConfigured
                ? <span style={{ fontSize:'.7rem', background:'#dff0e1', color:'var(--sage)', padding:'2px 8px', borderRadius:50, fontWeight:700 }}>✓ Connected</span>
                : <span style={{ fontSize:'.7rem', background:'#fde8dc', color:'var(--clay)', padding:'2px 8px', borderRadius:50, fontWeight:700 }}>Not configured</span>
              }
            </div>
            <div className="settings-row-sub">
              {isFirebaseConfigured
                ? 'Data syncs across all devices in real time via Firestore.'
                : <>Open <code style={{ fontSize:'.75rem', background:'var(--cream)', padding:'1px 5px', borderRadius:4 }}>src/firebase.js</code> and paste your Firebase project config to enable cloud sync. <a href="https://console.firebase.google.com" target="_blank" rel="noreferrer" style={{ color:'var(--clay)' }}>Open Firebase Console →</a></>
              }
            </div>
          </div>
        </div>
        {isFirebaseConfigured && (
          <div className="settings-row">
            <div className="settings-row-info">
              <div className="settings-row-label">Data stored in Firestore</div>
              <div className="settings-row-sub">Accounts · Donations · Food Banks · Stores · Your pantry / inventory</div>
            </div>
            <span style={{ fontSize:'.75rem', color:'var(--sage)', fontWeight:600 }}>🔄 Live</span>
          </div>
        )}
      </div>

      {/* Location — injected per app */}
      {locationSection && (
        <div className="settings-section">
          <div className="settings-section-title">📍 Location</div>
          {locationSection}
        </div>
      )}

      {/* About */}
      <div className="settings-section">
        <div className="settings-section-title">ℹ️ About</div>
        <div className="settings-about-card">
          <div className="settings-about-logo">Together<span>TableAI</span></div>
          <div className="settings-about-version">Version 18.0.0</div>
        <div style={{ display:'flex', alignItems:'center', justifyContent:'center', gap:6, marginBottom:8 }}>
          {isFirebaseConfigured
            ? <span style={{ fontSize:'.72rem', background:'#dff0e1', color:'var(--sage)', padding:'3px 10px', borderRadius:50, fontWeight:600 }}>🔥 Firebase Connected</span>
            : <span style={{ fontSize:'.72rem', background:'#fff8dc', color:'#b8860b', padding:'3px 10px', borderRadius:50, fontWeight:600 }}>⚠️ Local only — see Firebase Setup below</span>
          }
        </div>
          <p className="settings-about-desc">Reducing food waste and connecting communities — one meal at a time.</p>
        </div>
      </div>
    </div>
  )
}

// ─────────────────────────────────────────────
// AUTH SCREEN
// ─────────────────────────────────────────────

// =============================================================================
// LANDING PAGE  (v20 — redesigned)
// =============================================================================
function LandingPage({ onShowAuth }) {
  const [navScrolled, setNavScrolled] = React.useState(false)
  const [activeFeature, setActiveFeature] = React.useState(0)

  React.useEffect(() => {
    const onScroll = () => setNavScrolled(window.scrollY > 40)
    window.addEventListener('scroll', onScroll, { passive: true })

    // Reliable animation: use IntersectionObserver but also fallback after 300ms
    const obs = new IntersectionObserver(
      entries => entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('lp-vis') }),
      { threshold: 0.05, rootMargin: '0px 0px -40px 0px' }
    )
    const animEls = document.querySelectorAll('.lp-anim')
    animEls.forEach(el => obs.observe(el))
    // Fallback: anything still invisible after 500ms becomes visible
    const fallback = setTimeout(() => {
      document.querySelectorAll('.lp-anim:not(.lp-vis)').forEach(el => el.classList.add('lp-vis'))
    }, 500)

    return () => {
      window.removeEventListener('scroll', onScroll)
      obs.disconnect()
      clearTimeout(fallback)
    }
  }, [])

  const features = [
    {
      icon: '🧠', label: 'AI MEAL PLANS',
      title: 'A full week of meals, built around your pantry',
      desc: 'Pick any of 20+ diets or build your own. Gemini generates breakfast, lunch, and dinner for 7 days — with calorie counts and a shopping list for what you\'re missing.',
      tags: ['7-day plans', 'Recipe ideas', 'Calorie tracking'],
      accent: '#e66f3d', bg: '#fdf0e8',
    },
    {
      icon: '📸', label: 'FOOD SCANNING',
      title: 'Photograph your groceries. Done.',
      desc: 'Open your fridge or dump your shopping bag. Google Cloud Vision identifies every item instantly and populates your pantry — no typing, no guessing.',
      tags: ['Cloud Vision', 'Batch import', 'Instant detection'],
      accent: '#2a7fc1', bg: '#e8f2fd',
    },
    {
      icon: '✏️', label: 'CUSTOM PLAN BUILDER',
      title: 'Diet quiz meets nutrition science',
      desc: 'Answer a few questions about your goals, restrictions, and allergies. We match and score every plan against your profile, then let you layer in your own foods.',
      tags: ['Goal matching', 'Allergy-aware', 'Fully customisable'],
      accent: '#9b4d8a', bg: '#f5e8f5',
    },
    {
      icon: '🤝', label: 'FOOD BANK NETWORK',
      title: 'Donate surplus in one tap',
      desc: 'Live map of nearby food banks and shelters. Schedule a drop-off time, donate surplus items, and track your community impact in real time.',
      tags: ['Live map', 'Slot scheduling', 'Real-time sync'],
      accent: '#27a98e', bg: '#e0f5f0',
    },
  ]

  return (
    <div id="lp-root">
      <style>{`
        /* ─── RESET & BASE ─────────────────────────── */
        @import url('https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,700;0,9..144,800;0,9..144,900;1,9..144,700;1,9..144,800&family=DM+Sans:wght@400;500;600;700&display=swap');

        #lp-root {
          font-family: 'DM Sans', sans-serif;
          background: #0f0d0b;
          color: #f5f0e8;
          overflow-x: hidden;
          -webkit-font-smoothing: antialiased;
          min-height: 100vh;
          position: relative;
        }
        #lp-root *, #lp-root *::before, #lp-root *::after {
          box-sizing: border-box; margin: 0; padding: 0;
        }
        #lp-root a { text-decoration: none; color: inherit; }
        body:has(#lp-root) { background: #0f0d0b; overflow-y: scroll; }

        /* ─── SCROLL ANIMATIONS ─────────────────────── */
        .lp-anim {
          opacity: 0;
          transform: translateY(22px);
          transition: opacity .7s cubic-bezier(.22,1,.36,1), transform .7s cubic-bezier(.22,1,.36,1);
        }
        .lp-anim.lp-vis { opacity: 1; transform: none; }

        /* ─── AMBIENT TEXTURE ───────────────────────── */
        #lp-root::before {
          content: '';
          position: fixed; inset: 0;
          background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='.035'/%3E%3C/svg%3E");
          background-size: 200px;
          pointer-events: none;
          z-index: 0;
          opacity: .6;
        }
        #lp-root > * { position: relative; z-index: 1; }

        /* ─── NAV ───────────────────────────────────── */
        #lp-nav {
          position: fixed; top: 0; left: 0; right: 0; z-index: 300;
          padding: 0 clamp(20px, 5vw, 72px);
          height: 68px;
          display: flex; align-items: center; justify-content: space-between;
          transition: background .3s, border-color .3s;
          border-bottom: 1px solid transparent;
        }
        #lp-nav.scrolled {
          background: rgba(15,13,11,.88);
          backdrop-filter: blur(24px) saturate(1.4);
          -webkit-backdrop-filter: blur(24px) saturate(1.4);
          border-bottom-color: rgba(255,255,255,.07);
        }
        .lp-logo {
          font-family: 'Fraunces', serif;
          font-size: 20px; font-weight: 800;
          letter-spacing: -.3px;
          color: #f5f0e8;
          cursor: pointer;
          display: flex; align-items: center; gap: 8px;
        }
        .lp-logo-dot {
          width: 8px; height: 8px; border-radius: 50%;
          background: #e66f3d;
          flex-shrink: 0;
        }
        .lp-nav-center {
          display: flex; gap: 6px;
          background: rgba(255,255,255,.06);
          padding: 5px 6px; border-radius: 50px;
          border: 1px solid rgba(255,255,255,.09);
        }
        .lp-nav-link {
          background: none; border: none; cursor: pointer;
          color: rgba(245,240,232,.5);
          font-family: 'DM Sans', sans-serif;
          font-size: 13.5px; font-weight: 500;
          padding: 6px 16px; border-radius: 50px;
          transition: color .15s, background .15s;
        }
        .lp-nav-link:hover {
          color: #f5f0e8;
          background: rgba(255,255,255,.07);
        }
        .lp-nav-right { display: flex; align-items: center; gap: 10px; }
        .lp-nav-login {
          background: transparent; border: 1px solid rgba(245,240,232,.18);
          padding: 8px 20px; border-radius: 50px;
          font-family: 'DM Sans', sans-serif;
          font-size: 13.5px; font-weight: 500;
          cursor: pointer; color: rgba(245,240,232,.75);
          transition: all .15s;
        }
        .lp-nav-login:hover {
          border-color: rgba(245,240,232,.4);
          color: #f5f0e8;
        }
        .lp-nav-cta {
          background: #e66f3d; color: #fff;
          border: none; padding: 9px 22px; border-radius: 50px;
          font-family: 'DM Sans', sans-serif;
          font-size: 13.5px; font-weight: 600;
          cursor: pointer;
          transition: background .15s, transform .15s;
        }
        .lp-nav-cta:hover { background: #d05e2c; transform: translateY(-1px); }

        /* ─── HERO ──────────────────────────────────── */
        #lp-hero {
          min-height: 100vh;
          display: flex; flex-direction: column;
          align-items: center; justify-content: center;
          padding: 140px clamp(24px,5vw,72px) 100px;
          text-align: center;
          position: relative;
          overflow: hidden;
        }

        /* Radial glow behind hero text */
        #lp-hero::after {
          content: '';
          position: absolute;
          top: 50%; left: 50%;
          transform: translate(-50%, -55%);
          width: min(900px, 120vw);
          height: min(900px, 120vw);
          background: radial-gradient(circle, rgba(230,111,61,.14) 0%, rgba(232,168,62,.06) 40%, transparent 70%);
          pointer-events: none;
        }

        .lp-hero-eyebrow {
          display: inline-flex; align-items: center; gap: 8px;
          background: rgba(230,111,61,.12);
          border: 1px solid rgba(230,111,61,.28);
          color: #e8a83e;
          padding: 6px 16px; border-radius: 50px;
          font-size: 11px; font-weight: 700; letter-spacing: .1em;
          text-transform: uppercase;
          margin-bottom: 36px;
        }
        .lp-eyebrow-dot {
          width: 5px; height: 5px; border-radius: 50%;
          background: #e66f3d;
          animation: lp-pulse 2s ease-in-out infinite;
        }
        @keyframes lp-pulse { 0%,100%{opacity:1;} 50%{opacity:.3;} }

        .lp-hero-h1 {
          font-family: 'Fraunces', serif;
          font-size: clamp(52px, 7.5vw, 96px);
          line-height: 1.0;
          font-weight: 900;
          letter-spacing: -3px;
          color: #f5f0e8;
          margin-bottom: 28px;
          max-width: 900px;
        }
        .lp-hero-h1 em {
          font-style: italic;
          color: #e66f3d;
          font-weight: 800;
        }
        .lp-hero-h1 span {
          display: inline-block;
          position: relative;
        }
        .lp-hero-h1 span::after {
          content: '';
          position: absolute;
          bottom: 4px; left: 0; right: 0;
          height: 3px;
          background: linear-gradient(90deg, #e66f3d, #e8a83e);
          border-radius: 2px;
          opacity: .6;
        }

        .lp-hero-p {
          font-size: clamp(15px, 1.6vw, 18px);
          color: rgba(245,240,232,.55);
          line-height: 1.7;
          margin-bottom: 48px;
          max-width: 540px;
        }

        .lp-hero-btns {
          display: flex; gap: 12px; justify-content: center;
          flex-wrap: wrap;
          margin-bottom: 60px;
        }
        .lp-btn-primary {
          background: #e66f3d; color: #fff;
          padding: 16px 36px; border-radius: 50px;
          font-family: 'DM Sans', sans-serif;
          font-size: 15px; font-weight: 600;
          border: none; cursor: pointer;
          display: inline-flex; align-items: center; gap: 8px;
          transition: background .15s, transform .2s, box-shadow .2s;
          box-shadow: 0 0 0 0 rgba(230,111,61,0);
        }
        .lp-btn-primary:hover {
          background: #d05e2c;
          transform: translateY(-2px);
          box-shadow: 0 8px 32px rgba(230,111,61,.4);
        }
        .lp-btn-secondary {
          background: rgba(255,255,255,.06);
          border: 1px solid rgba(255,255,255,.14);
          padding: 16px 36px; border-radius: 50px;
          font-family: 'DM Sans', sans-serif;
          font-size: 15px; font-weight: 500;
          cursor: pointer; color: rgba(245,240,232,.8);
          display: inline-flex; align-items: center; gap: 8px;
          transition: background .15s, border-color .15s, transform .2s;
        }
        .lp-btn-secondary:hover {
          background: rgba(255,255,255,.1);
          border-color: rgba(255,255,255,.25);
          transform: translateY(-2px);
        }

        .lp-hero-trust {
          display: flex; gap: 28px; justify-content: center;
          font-size: 12.5px; color: rgba(245,240,232,.3);
          font-weight: 500; flex-wrap: wrap;
        }
        .lp-trust-item { display: flex; align-items: center; gap: 6px; }

        /* ─── HERO MOCKUP CARD ──────────────────────── */
        .lp-mockup-wrap {
          width: 100%;
          max-width: 640px;
          margin: 80px auto 0;
          position: relative;
        }
        .lp-mockup-card {
          background: linear-gradient(160deg, rgba(255,255,255,.07) 0%, rgba(255,255,255,.03) 100%);
          border: 1px solid rgba(255,255,255,.1);
          border-radius: 28px;
          padding: 24px;
          backdrop-filter: blur(20px);
          box-shadow:
            0 0 0 1px rgba(255,255,255,.05) inset,
            0 40px 80px rgba(0,0,0,.6),
            0 0 60px rgba(230,111,61,.08);
        }
        .lp-mc-header {
          display: flex; align-items: center; justify-content: space-between;
          margin-bottom: 20px;
          padding-bottom: 16px;
          border-bottom: 1px solid rgba(255,255,255,.07);
        }
        .lp-mc-logo {
          font-family: 'Fraunces', serif;
          font-size: 16px; font-weight: 800;
          color: #f5f0e8;
        }
        .lp-mc-logo em { font-style: normal; color: #e66f3d; }
        .lp-mc-badge {
          display: flex; align-items: center; gap: 6px;
          background: rgba(230,111,61,.15);
          border: 1px solid rgba(230,111,61,.25);
          padding: 5px 12px; border-radius: 50px;
          font-size: 11px; font-weight: 700; color: #e8a83e;
          letter-spacing: .05em;
        }
        .lp-mc-rows {
          display: flex; flex-direction: column; gap: 0;
          margin-bottom: 18px;
        }
        .lp-mc-row {
          display: flex; align-items: center;
          padding: 11px 0;
          border-bottom: 1px solid rgba(255,255,255,.05);
          gap: 12px;
        }
        .lp-mc-row:last-child { border-bottom: none; }
        .lp-mc-emoji { font-size: 20px; width: 32px; text-align: center; flex-shrink: 0; }
        .lp-mc-info { flex: 1; min-width: 0; }
        .lp-mc-name { font-size: 13.5px; font-weight: 600; color: #f5f0e8; }
        .lp-mc-sub { font-size: 11px; color: rgba(245,240,232,.35); margin-top: 1px; }
        .lp-mc-chip {
          font-size: 10px; font-weight: 700; letter-spacing: .04em;
          padding: 3px 10px; border-radius: 50px; flex-shrink: 0;
        }
        .lp-mc-good { background: rgba(107,140,110,.2); color: #8ec892; border: 1px solid rgba(107,140,110,.2); }
        .lp-mc-low { background: rgba(230,111,61,.15); color: #e8a83e; border: 1px solid rgba(230,111,61,.2); }
        .lp-mc-mid { background: rgba(232,168,62,.12); color: #e8a83e; border: 1px solid rgba(232,168,62,.15); }

        .lp-mc-ai-bar {
          background: linear-gradient(135deg, rgba(230,111,61,.18), rgba(232,168,62,.12));
          border: 1px solid rgba(230,111,61,.2);
          border-radius: 16px;
          padding: 14px 18px;
          display: flex; align-items: center; gap: 14px;
        }
        .lp-mc-ai-icon { font-size: 24px; flex-shrink: 0; }
        .lp-mc-ai-text { font-size: 13px; font-weight: 700; color: #f5f0e8; }
        .lp-mc-ai-sub { font-size: 11px; color: rgba(245,240,232,.4); margin-top: 2px; }
        .lp-mc-ai-arrow {
          margin-left: auto; color: #e66f3d;
          font-size: 16px; flex-shrink: 0;
        }

        /* Floating stat chips on mockup */
        .lp-float-chips {
          position: absolute;
          top: -16px; right: -8px;
          display: flex; flex-direction: column; gap: 10px;
          pointer-events: none;
        }
        .lp-fchip {
          background: rgba(15,13,11,.85);
          border: 1px solid rgba(255,255,255,.1);
          backdrop-filter: blur(12px);
          padding: 10px 16px; border-radius: 14px;
          box-shadow: 0 8px 24px rgba(0,0,0,.4);
          white-space: nowrap;
          animation: lp-chip-float 4s ease-in-out infinite;
        }
        .lp-fchip:nth-child(2) { animation-delay: 1.5s; }
        @keyframes lp-chip-float {
          0%,100% { transform: translateY(0); }
          50% { transform: translateY(-6px); }
        }
        .lp-fchip-label { font-size: 11px; font-weight: 700; color: #f5f0e8; }
        .lp-fchip-sub { font-size: 10px; color: rgba(245,240,232,.4); margin-top: 1px; }

        /* ─── STATS STRIP ───────────────────────────── */
        #lp-stats {
          padding: 0 clamp(24px,5vw,72px);
          margin-top: 80px;
        }
        .lp-stats-inner {
          max-width: 1000px; margin: 0 auto;
          display: grid; grid-template-columns: repeat(4,1fr);
          background: rgba(255,255,255,.04);
          border: 1px solid rgba(255,255,255,.07);
          border-radius: 20px;
          overflow: hidden;
        }
        .lp-stat-cell {
          padding: 28px 20px;
          text-align: center;
          border-right: 1px solid rgba(255,255,255,.07);
          transition: background .2s;
        }
        .lp-stat-cell:last-child { border-right: none; }
        .lp-stat-cell:hover { background: rgba(255,255,255,.03); }
        .lp-stat-n {
          font-family: 'Fraunces', serif;
          font-size: 2.4rem; font-weight: 800;
          font-style: italic;
          color: #e66f3d; line-height: 1;
          margin-bottom: 6px;
        }
        .lp-stat-l { font-size: .72rem; color: rgba(245,240,232,.3); line-height: 1.6; }

        /* ─── SECTION UTILITIES ─────────────────────── */
        .lp-section {
          padding: clamp(80px,10vw,120px) clamp(24px,5vw,72px);
        }
        .lp-sec-inner { max-width: 1100px; margin: 0 auto; }
        .lp-eyebrow {
          font-size: .66rem; font-weight: 800;
          text-transform: uppercase; letter-spacing: .14em;
          color: #e66f3d; margin-bottom: 14px; display: block;
        }
        .lp-h2 {
          font-family: 'Fraunces', serif;
          font-size: clamp(2rem, 3.5vw, 3rem);
          font-weight: 800; line-height: 1.05;
          letter-spacing: -.04em;
          color: #f5f0e8;
          margin-bottom: 14px;
        }
        .lp-h2 em {
          font-style: italic;
          color: #e66f3d;
        }
        .lp-sec-p {
          font-size: .9rem; line-height: 1.8;
          color: rgba(245,240,232,.4);
          max-width: 480px; margin-bottom: 56px;
        }

        /* ─── FEATURES ──────────────────────────────── */
        #lp-features { background: #0f0d0b; }
        .lp-feat-tabs {
          display: flex; gap: 8px;
          margin-bottom: 36px;
          flex-wrap: wrap;
        }
        .lp-feat-tab {
          display: flex; align-items: center; gap: 8px;
          padding: 10px 20px; border-radius: 50px;
          font-family: 'DM Sans', sans-serif;
          font-size: 13px; font-weight: 600;
          cursor: pointer; border: 1px solid rgba(255,255,255,.1);
          background: rgba(255,255,255,.04);
          color: rgba(245,240,232,.45);
          transition: all .2s;
        }
        .lp-feat-tab:hover {
          background: rgba(255,255,255,.07);
          color: rgba(245,240,232,.75);
        }
        .lp-feat-tab.active {
          border-color: rgba(230,111,61,.4);
          background: rgba(230,111,61,.1);
          color: #f5f0e8;
        }
        .lp-feat-tab-icon { font-size: 16px; }

        .lp-feat-main {
          display: grid; grid-template-columns: 1fr 1fr;
          gap: 2px;
          border-radius: 24px;
          overflow: hidden;
          background: rgba(255,255,255,.04);
          border: 1px solid rgba(255,255,255,.07);
        }
        .lp-feat-info {
          padding: 48px 44px;
          display: flex; flex-direction: column; justify-content: center;
        }
        .lp-feat-label {
          font-size: .65rem; font-weight: 800;
          letter-spacing: .12em; text-transform: uppercase;
          color: #e66f3d; margin-bottom: 16px;
          display: flex; align-items: center; gap: 8px;
        }
        .lp-feat-label::before {
          content: '';
          width: 20px; height: 2px;
          background: #e66f3d;
          display: inline-block;
          border-radius: 1px;
        }
        .lp-feat-h3 {
          font-family: 'Fraunces', serif;
          font-size: clamp(1.4rem, 2.2vw, 1.9rem);
          font-weight: 800; line-height: 1.15;
          letter-spacing: -.03em;
          color: #f5f0e8;
          margin-bottom: 16px;
        }
        .lp-feat-p {
          font-size: .87rem; line-height: 1.75;
          color: rgba(245,240,232,.45);
          margin-bottom: 24px;
        }
        .lp-feat-tags {
          display: flex; flex-wrap: wrap; gap: 6px;
        }
        .lp-feat-tag {
          font-size: .64rem; font-weight: 700;
          text-transform: uppercase; letter-spacing: .06em;
          padding: 4px 12px; border-radius: 50px;
          background: rgba(255,255,255,.06);
          border: 1px solid rgba(255,255,255,.09);
          color: rgba(245,240,232,.45);
        }

        .lp-feat-visual {
          padding: 36px;
          display: flex; align-items: center; justify-content: center;
          min-height: 280px;
          background: rgba(255,255,255,.015);
          position: relative; overflow: hidden;
        }
        .lp-feat-icon-bg {
          font-size: 7rem;
          opacity: .12;
          position: absolute;
          bottom: -10px; right: -10px;
          transform: rotate(-10deg);
          filter: grayscale(1);
          pointer-events: none;
        }
        .lp-feat-icon-main {
          font-size: 4.5rem;
          position: relative; z-index: 1;
          filter: drop-shadow(0 12px 40px rgba(0,0,0,.5));
        }
        .lp-feat-mini-card {
          background: rgba(255,255,255,.06);
          border: 1px solid rgba(255,255,255,.1);
          border-radius: 16px;
          padding: 18px 20px;
          position: relative; z-index: 1;
          display: flex; flex-direction: column; gap: 10px;
          min-width: 200px;
        }
        .lp-mini-row {
          display: flex; align-items: center; gap: 10px;
          font-size: 12.5px; color: rgba(245,240,232,.7);
        }
        .lp-mini-row .dot {
          width: 7px; height: 7px; border-radius: 50%;
          flex-shrink: 0;
        }

        /* ─── AI SPOTLIGHT ──────────────────────────── */
        #lp-ai {
          background: linear-gradient(180deg, #0f0d0b 0%, #160f08 50%, #0f0d0b 100%);
          position: relative; overflow: hidden;
        }
        #lp-ai::before {
          content: '';
          position: absolute; inset: 0;
          background: radial-gradient(ellipse 80% 60% at 50% 50%, rgba(230,111,61,.07) 0%, transparent 65%);
          pointer-events: none;
        }
        .lp-ai-cards {
          display: grid; grid-template-columns: repeat(3,1fr);
          gap: 16px; margin-top: 48px;
        }
        .lp-ai-card {
          background: rgba(255,255,255,.03);
          border: 1px solid rgba(255,255,255,.07);
          border-radius: 22px; padding: 32px 28px;
          transition: background .25s, border-color .25s, transform .25s;
          cursor: default;
        }
        .lp-ai-card:hover {
          background: rgba(255,255,255,.06);
          border-color: rgba(230,111,61,.25);
          transform: translateY(-4px);
        }
        .lp-ai-card-num {
          font-family: 'Fraunces', serif;
          font-size: 3rem; font-weight: 800; font-style: italic;
          color: rgba(230,111,61,.2);
          line-height: 1; margin-bottom: 14px;
        }
        .lp-ai-card-icon { font-size: 1.8rem; margin-bottom: 12px; }
        .lp-ai-card-h3 {
          font-size: 1rem; font-weight: 700;
          color: #f5f0e8; margin-bottom: 10px;
          letter-spacing: -.02em;
        }
        .lp-ai-card-p {
          font-size: .82rem; line-height: 1.7;
          color: rgba(245,240,232,.38);
        }

        /* ─── HOW IT WORKS ──────────────────────────── */
        #lp-how { background: #0f0d0b; }
        .lp-steps {
          display: grid; grid-template-columns: repeat(4,1fr);
          gap: 0;
          margin-top: 56px;
          position: relative;
        }
        .lp-steps::before {
          content: '';
          position: absolute;
          top: 24px; left: 12.5%; right: 12.5%;
          height: 1px;
          background: linear-gradient(90deg, transparent, rgba(230,111,61,.3) 20%, rgba(230,111,61,.3) 80%, transparent);
          pointer-events: none;
          z-index: 0;
        }
        .lp-step {
          display: flex; flex-direction: column; align-items: center;
          text-align: center; padding: 0 20px;
          position: relative; z-index: 1;
        }
        .lp-step-num-wrap {
          width: 48px; height: 48px; border-radius: 50%;
          background: rgba(230,111,61,.12);
          border: 1px solid rgba(230,111,61,.25);
          display: flex; align-items: center; justify-content: center;
          margin-bottom: 20px;
          font-size: 1.3rem;
        }
        .lp-step-n {
          font-family: 'Fraunces', serif;
          font-size: .85rem; font-weight: 800; font-style: italic;
          color: #e66f3d;
        }
        .lp-step-h3 {
          font-size: .92rem; font-weight: 700;
          color: #f5f0e8; margin-bottom: 8px;
          letter-spacing: -.01em;
        }
        .lp-step-p {
          font-size: .78rem; line-height: 1.7;
          color: rgba(245,240,232,.35);
        }

        /* ─── WHO IT'S FOR ──────────────────────────── */
        #lp-for { background: #0f0d0b; }
        .lp-for-cards {
          display: grid; grid-template-columns: repeat(3, 1fr);
          gap: 16px; margin-top: 48px;
        }
        .lp-for-card {
          border-radius: 24px; padding: 36px 30px;
          border: 1px solid rgba(255,255,255,.07);
          background: rgba(255,255,255,.025);
          transition: transform .25s, box-shadow .25s, border-color .25s;
        }
        .lp-for-card:hover {
          transform: translateY(-6px);
          box-shadow: 0 20px 60px rgba(0,0,0,.3);
          border-color: rgba(255,255,255,.12);
        }
        .lp-for-card-accent {
          width: 36px; height: 4px; border-radius: 2px;
          margin-bottom: 24px;
        }
        .lp-for-icon { font-size: 2rem; margin-bottom: 12px; display: block; }
        .lp-for-role {
          font-size: .62rem; font-weight: 800;
          letter-spacing: .12em; text-transform: uppercase;
          margin-bottom: 8px;
        }
        .lp-for-h3 {
          font-family: 'Fraunces', serif;
          font-size: 1.2rem; font-weight: 800;
          color: #f5f0e8; margin-bottom: 10px;
          letter-spacing: -.03em;
        }
        .lp-for-p {
          font-size: .82rem; line-height: 1.75;
          color: rgba(245,240,232,.38);
          margin-bottom: 22px;
        }
        .lp-for-feats { display: flex; flex-direction: column; gap: 10px; }
        .lp-for-feat {
          font-size: .8rem; color: rgba(245,240,232,.5);
          display: flex; align-items: flex-start; gap: 10px;
        }
        .lp-for-check {
          width: 16px; height: 16px; border-radius: 50%;
          background: rgba(255,255,255,.08);
          display: flex; align-items: center; justify-content: center;
          flex-shrink: 0; margin-top: 1px;
          font-size: 9px;
        }

        /* ─── CTA ────────────────────────────────────── */
        #lp-cta {
          padding: clamp(100px,12vw,140px) clamp(24px,5vw,72px);
          text-align: center;
          background: #0f0d0b;
          position: relative; overflow: hidden;
        }
        #lp-cta::before {
          content: '';
          position: absolute; inset: 0;
          background: radial-gradient(ellipse 70% 80% at 50% 50%, rgba(230,111,61,.06) 0%, transparent 65%);
          pointer-events: none;
        }
        .lp-cta-inner {
          max-width: 600px; margin: 0 auto;
          position: relative; z-index: 1;
        }
        .lp-cta-h2 {
          font-family: 'Fraunces', serif;
          font-size: clamp(2.2rem, 4.5vw, 3.5rem);
          font-weight: 900; line-height: 1.05;
          letter-spacing: -.04em;
          color: #f5f0e8;
          margin-bottom: 18px;
        }
        .lp-cta-h2 em { font-style: italic; color: #e66f3d; }
        .lp-cta-p {
          font-size: .92rem; line-height: 1.75;
          color: rgba(245,240,232,.38);
          margin-bottom: 40px;
        }
        .lp-cta-btn {
          background: #e66f3d; color: #fff;
          padding: 18px 52px; border-radius: 50px;
          font-family: 'DM Sans', sans-serif;
          font-size: 1rem; font-weight: 700;
          border: none; cursor: pointer;
          display: inline-flex; align-items: center; gap: 10px;
          transition: background .15s, transform .2s, box-shadow .2s;
          box-shadow: 0 8px 40px rgba(230,111,61,.3);
          letter-spacing: -.01em;
        }
        .lp-cta-btn:hover {
          background: #d05e2c;
          transform: translateY(-3px);
          box-shadow: 0 14px 50px rgba(230,111,61,.4);
        }
        .lp-cta-note { font-size: .72rem; color: rgba(245,240,232,.2); margin-top: 18px; }

        /* ─── FOOTER ─────────────────────────────────── */
        #lp-footer {
          background: rgba(255,255,255,.02);
          border-top: 1px solid rgba(255,255,255,.06);
          padding: 28px clamp(24px,5vw,72px);
          display: flex; align-items: center; justify-content: space-between;
          flex-wrap: wrap; gap: 12px;
        }
        .lp-foot-logo {
          font-family: 'Fraunces', serif;
          font-size: 1rem; font-weight: 800;
          color: rgba(245,240,232,.6);
          display: flex; align-items: center; gap: 6px;
        }
        .lp-foot-logo em { font-style: normal; color: #e66f3d; }
        .lp-foot-copy { font-size: .7rem; color: rgba(245,240,232,.18); }
        .lp-foot-links { display: flex; gap: 20px; }
        .lp-foot-link {
          font-size: .72rem; color: rgba(245,240,232,.25);
          cursor: pointer; transition: color .15s;
        }
        .lp-foot-link:hover { color: rgba(245,240,232,.6); }

        /* ─── RESPONSIVE ─────────────────────────────── */
        @media (max-width: 1024px) {
          .lp-feat-main { grid-template-columns: 1fr; }
          .lp-feat-visual { min-height: 200px; }
          .lp-ai-cards { grid-template-columns: repeat(2,1fr); }
          .lp-steps { grid-template-columns: repeat(2,1fr); gap: 36px; }
          .lp-steps::before { display: none; }
          .lp-for-cards { grid-template-columns: repeat(2,1fr); }
          .lp-stats-inner { grid-template-columns: repeat(2,1fr); }
          .lp-stat-cell:nth-child(2) { border-right: none; }
          .lp-stat-cell:nth-child(3) { border-top: 1px solid rgba(255,255,255,.07); }
          .lp-stat-cell:nth-child(4) { border-top: 1px solid rgba(255,255,255,.07); }
        }
        @media (max-width: 640px) {
          #lp-nav { height: 60px; padding: 0 20px; }
          .lp-nav-center { display: none; }
          .lp-nav-right { gap: 8px; }
          #lp-hero { padding: 100px 20px 80px; }
          .lp-hero-h1 { font-size: 44px; letter-spacing: -2px; }
          .lp-hero-p { font-size: 15px; }
          .lp-mockup-wrap { margin-top: 56px; }
          .lp-float-chips { display: none; }
          .lp-ai-cards { grid-template-columns: 1fr; }
          .lp-steps { grid-template-columns: 1fr; gap: 32px; }
          .lp-for-cards { grid-template-columns: 1fr; }
          .lp-feat-tabs { gap: 6px; }
          .lp-feat-info { padding: 32px 24px; }
          .lp-feat-tab { font-size: 12px; padding: 8px 14px; }
          #lp-footer { justify-content: center; text-align: center; flex-direction: column; }
          .lp-foot-links { display: none; }
          .lp-stats-inner { grid-template-columns: repeat(2,1fr); }
        }
      `}</style>

      {/* NAV */}
      <nav id="lp-nav" className={navScrolled ? 'scrolled' : ''}>
        <div className="lp-logo">
          <span className="lp-logo-dot"></span>
          Together<em style={{fontStyle:'normal',color:'#e66f3d'}}>TableAI</em>
        </div>
        <div className="lp-nav-center">
          <button className="lp-nav-link" onClick={() => document.getElementById('lp-features')?.scrollIntoView({behavior:'smooth'})}>Features</button>
          <button className="lp-nav-link" onClick={() => document.getElementById('lp-how')?.scrollIntoView({behavior:'smooth'})}>How it works</button>
          <button className="lp-nav-link" onClick={() => document.getElementById('lp-for')?.scrollIntoView({behavior:'smooth'})}>Who it's for</button>
        </div>
        <div className="lp-nav-right">
          <button className="lp-nav-login" onClick={() => onShowAuth('login')}>Log in</button>
          <button className="lp-nav-cta" onClick={() => onShowAuth('signup')}>Get started</button>
        </div>
      </nav>

      {/* HERO */}
      <section id="lp-hero">
        <div className="lp-hero-eyebrow lp-anim">
          <span className="lp-eyebrow-dot"></span>
          Powered by Gemini AI
        </div>
        <h1 className="lp-hero-h1 lp-anim" style={{transitionDelay:'60ms'}}>
          Eat smarter.<br/>
          Waste <em>nothing.</em><br/>
          <span>Feed everyone.</span>
        </h1>
        <p className="lp-hero-p lp-anim" style={{transitionDelay:'120ms'}}>
          TogetherTableAI turns your pantry into a personalized nutrition hub — with AI meal plans, smart food scanning, and a live food bank network.
        </p>
        <div className="lp-hero-btns lp-anim" style={{transitionDelay:'180ms'}}>
          <button className="lp-btn-primary" onClick={() => onShowAuth('signup')}>
            Start for free →
          </button>
          <button className="lp-btn-secondary" onClick={() => document.getElementById('lp-how')?.scrollIntoView({behavior:'smooth'})}>
            <span>▶</span> See how it works
          </button>
        </div>
        <div className="lp-hero-trust lp-anim" style={{transitionDelay:'240ms'}}>
          <span className="lp-trust-item">🗂 No credit card</span>
          <span className="lp-trust-item">⏱ Setup in 60 seconds</span>
          <span className="lp-trust-item">🌱 Free forever plan</span>
        </div>

        {/* App mockup */}
        <div className="lp-mockup-wrap lp-anim" style={{transitionDelay:'320ms'}}>
          <div className="lp-float-chips">
            <div className="lp-fchip">
              <div className="lp-fchip-label">✅ 7-day plan ready</div>
              <div className="lp-fchip-sub">Mediterranean · generated by AI</div>
            </div>
            <div className="lp-fchip">
              <div className="lp-fchip-label">📷 12 items scanned</div>
              <div className="lp-fchip-sub">Added to pantry instantly</div>
            </div>
          </div>
          <div className="lp-mockup-card">
            <div className="lp-mc-header">
              <div className="lp-mc-logo">Together<em>TableAI</em></div>
              <div className="lp-mc-badge">🧠 AI Active</div>
            </div>
            <div className="lp-mc-rows">
              {[
                ['🥑','Avocados','Fruit · qty 4','good','GOOD'],
                ['🥚','Free-range Eggs','Protein · qty 6','good','GOOD'],
                ['🥛','Oat Milk','Beverage · qty 1','low','LOW'],
                ['🍅','Tomatoes','Vegetable · qty 3','mid','MED'],
              ].map(([em, name, sub, cls, label]) => (
                <div className="lp-mc-row" key={name}>
                  <span className="lp-mc-emoji">{em}</span>
                  <div className="lp-mc-info">
                    <div className="lp-mc-name">{name}</div>
                    <div className="lp-mc-sub">{sub}</div>
                  </div>
                  <span className={`lp-mc-chip lp-mc-${cls}`}>{label}</span>
                </div>
              ))}
            </div>
            <div className="lp-mc-ai-bar">
              <span className="lp-mc-ai-icon">🧠</span>
              <div>
                <div className="lp-mc-ai-text">AI Meal Plan Active</div>
                <div className="lp-mc-ai-sub">Mediterranean · 7-day plan · 2,100 kcal/day</div>
              </div>
              <span className="lp-mc-ai-arrow">→</span>
            </div>
          </div>
        </div>
      </section>

      {/* STATS */}
      <div id="lp-stats">
        <div className="lp-stats-inner">
          {[
            ['3','User types — household, food bank, business'],
            ['20+','Diet plans with AI conflict checking'],
            ['Gemini','Vision-powered food scanning & plans'],
            ['Live','Real-time donations & food bank network'],
          ].map(([n,l],i) => (
            <div className="lp-stat-cell lp-anim" key={i} style={{transitionDelay:`${i*80}ms`}}>
              <div className="lp-stat-n">{n}</div>
              <div className="lp-stat-l">{l}</div>
            </div>
          ))}
        </div>
      </div>

      {/* FEATURES */}
      <section id="lp-features" className="lp-section">
        <div className="lp-sec-inner">
          <span className="lp-eyebrow lp-anim">What you get</span>
          <h2 className="lp-h2 lp-anim" style={{transitionDelay:'80ms'}}>
            Everything your kitchen<br/><em>and community</em> needs
          </h2>
          <p className="lp-sec-p lp-anim" style={{transitionDelay:'160ms'}}>
            Four AI-powered pillars that transform how you eat, shop, and share food.
          </p>

          {/* Feature tabs */}
          <div className="lp-feat-tabs lp-anim" style={{transitionDelay:'220ms'}}>
            {features.map((f, i) => (
              <button
                key={f.label}
                className={`lp-feat-tab ${activeFeature===i?'active':''}`}
                onClick={() => setActiveFeature(i)}
              >
                <span className="lp-feat-tab-icon">{f.icon}</span>
                {f.label}
              </button>
            ))}
          </div>

          <div className="lp-feat-main lp-anim" style={{transitionDelay:'280ms'}}>
            <div className="lp-feat-info">
              <div className="lp-feat-label">{features[activeFeature].label}</div>
              <h3 className="lp-feat-h3">{features[activeFeature].title}</h3>
              <p className="lp-feat-p">{features[activeFeature].desc}</p>
              <div className="lp-feat-tags">
                {features[activeFeature].tags.map(t => (
                  <span className="lp-feat-tag" key={t}>{t}</span>
                ))}
              </div>
            </div>
            <div className="lp-feat-visual">
              <span className="lp-feat-icon-bg">{features[activeFeature].icon}</span>
              <div className="lp-feat-mini-card">
                {activeFeature === 0 && <>
                  <div style={{fontSize:'.72rem',fontWeight:700,color:'#e66f3d',marginBottom:4}}>MONDAY</div>
                  {[['🍳','Avocado Toast','Breakfast','350 kcal'],['🥗','Chickpea Salad','Lunch','420 kcal'],['🍝','Salmon Pasta','Dinner','580 kcal']].map(([ic,n,t,c])=>(
                    <div className="lp-mini-row" key={n}>
                      <span className="dot" style={{background:'#e66f3d'}}></span>
                      <span>{ic} {n}</span>
                      <span style={{marginLeft:'auto',fontSize:11,color:'rgba(245,240,232,.3)'}}>{c}</span>
                    </div>
                  ))}
                </>}
                {activeFeature === 1 && <>
                  <div style={{fontSize:'.72rem',fontWeight:700,color:'#2a7fc1',marginBottom:4}}>DETECTED</div>
                  {[['🥑','Avocado','3 detected'],['🥚','Eggs','6 detected'],['🥛','Oat Milk','1 detected'],['🍅','Tomatoes','4 detected']].map(([ic,n,q])=>(
                    <div className="lp-mini-row" key={n}>
                      <span className="dot" style={{background:'#2a7fc1'}}></span>
                      <span>{ic} {n}</span>
                      <span style={{marginLeft:'auto',fontSize:11,color:'rgba(245,240,232,.3)'}}>{q}</span>
                    </div>
                  ))}
                </>}
                {activeFeature === 2 && <>
                  <div style={{fontSize:'.72rem',fontWeight:700,color:'#9b4d8a',marginBottom:4}}>BEST MATCH</div>
                  {[['Mediterranean','98% match'],['DASH Diet','91% match'],['Plant-Based','87% match']].map(([n,s])=>(
                    <div className="lp-mini-row" key={n}>
                      <span className="dot" style={{background:'#9b4d8a'}}></span>
                      <span>{n}</span>
                      <span style={{marginLeft:'auto',fontSize:11,color:'rgba(245,240,232,.3)'}}>{s}</span>
                    </div>
                  ))}
                </>}
                {activeFeature === 3 && <>
                  <div style={{fontSize:'.72rem',fontWeight:700,color:'#27a98e',marginBottom:4}}>NEARBY</div>
                  {[['City Food Bank','0.4 mi · Open'],['Community Kitchen','1.1 mi · Open'],['Hope Food Bank','2.3 mi · Open']].map(([n,s])=>(
                    <div className="lp-mini-row" key={n}>
                      <span className="dot" style={{background:'#27a98e'}}></span>
                      <span>{n}</span>
                      <span style={{marginLeft:'auto',fontSize:11,color:'rgba(245,240,232,.3)'}}>{s}</span>
                    </div>
                  ))}
                </>}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* AI SPOTLIGHT */}
      <section id="lp-ai" className="lp-section">
        <div className="lp-sec-inner">
          <span className="lp-eyebrow lp-anim">Powered by Gemini</span>
          <h2 className="lp-h2 lp-anim" style={{transitionDelay:'80ms'}}>
            Three ways <em>AI changes</em><br/>how you eat
          </h2>
          <div className="lp-ai-cards">
            {[
              { n:'01', icon:'📸', h:'Image Food Scanning', p:'Upload any photo of food — a grocery bag, open fridge, or market haul. Google Cloud Vision identifies every item and adds them to your pantry in seconds.' },
              { n:'02', icon:'🧠', h:'Personalised Meal Plans', p:'Choose from 20+ diet plans or build your own. Gemini generates a full 7-day plan with breakfast, lunch, and dinner recipes, calorie estimates, and a shopping list.' },
              { n:'03', icon:'✏️', h:'Build Your Own Plan', p:'Answer a few questions about your goals, restrictions, and allergies. We score every plan against your profile and let you layer in custom foods on top.' },
            ].map(({ n, icon, h, p }, i) => (
              <div className="lp-ai-card lp-anim" key={h} style={{transitionDelay:`${i*100}ms`}}>
                <div className="lp-ai-card-num">{n}</div>
                <div className="lp-ai-card-icon">{icon}</div>
                <h3 className="lp-ai-card-h3">{h}</h3>
                <p className="lp-ai-card-p">{p}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section id="lp-how" className="lp-section">
        <div className="lp-sec-inner">
          <span className="lp-eyebrow lp-anim">Simple to start</span>
          <h2 className="lp-h2 lp-anim" style={{transitionDelay:'80ms'}}>
            Up and running in <em>four steps</em>
          </h2>
          <p className="lp-sec-p lp-anim" style={{transitionDelay:'160ms'}}>
            No complicated setup. Just sign up, scan, plan, and give.
          </p>
          <div className="lp-steps">
            {[
              { n:'01', icon:'📝', title:'Create your profile', desc:'Sign up as a household, food bank, or business in under a minute. No credit card needed.' },
              { n:'02', icon:'📸', title:'Scan or add your food', desc:'Upload a photo and let Gemini Vision populate your pantry instantly, or add items manually.' },
              { n:'03', icon:'🧠', title:'Get your AI meal plan', desc:'Pick a diet or build your own. Gemini generates a 7-day plan based on what you already have.' },
              { n:'04', icon:'🌍', title:'Shop smart, give back', desc:'Get smart shopping suggestions and donate surplus food to nearby food banks in one tap.' },
            ].map(({ n, icon, title, desc }, i) => (
              <div className="lp-step lp-anim" key={n} style={{transitionDelay:`${i*100}ms`}}>
                <div className="lp-step-num-wrap">
                  <span className="lp-step-n">{n}</span>
                </div>
                <h3 className="lp-step-h3">{title}</h3>
                <p className="lp-step-p">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* WHO IT'S FOR */}
      <section id="lp-for" className="lp-section">
        <div className="lp-sec-inner">
          <span className="lp-eyebrow lp-anim">Built for everyone</span>
          <h2 className="lp-h2 lp-anim" style={{transitionDelay:'80ms'}}>
            One app, <em>three roles</em>
          </h2>
          <p className="lp-sec-p lp-anim" style={{transitionDelay:'160ms'}}>
            Whether you're feeding a family, running a food bank, or managing a store — there's a profile built exactly for you.
          </p>
          <div className="lp-for-cards">
            {[
              {
                accent:'#e66f3d', icon:'🏠', role:'Household', h:'Smart home cooking',
                p:'For individuals and families who want to eat better, waste less, and connect with their local food community.',
                feats:['AI-powered image food scanning','7-day AI meal plans with recipes','Build your own custom plan','Donate surplus to local food banks'],
                roleColor:'#e66f3d',
              },
              {
                accent:'#27a98e', icon:'🏛️', role:'Food Bank', h:'Efficient food relief',
                p:'For food banks and shelters managing incoming donations, tracking inventory, and coordinating volunteers in real time.',
                feats:['Live inventory & capacity dashboard','Receive donations from households','Volunteer & staff management','Post public food requests'],
                roleColor:'#27a98e',
              },
              {
                accent:'#e8a83e', icon:'🏪', role:'Business', h:'Reduce waste, give back',
                p:'For grocery stores and restaurants cutting food waste, managing multi-location inventory, and donating surplus easily.',
                feats:['Multi-location inventory management','Low-stock alerts & sales tracking','One-tap food bank donations','Kitchen & store inventory tools'],
                roleColor:'#e8a83e',
              },
            ].map(({ accent, icon, role, h, p, feats, roleColor }, i) => (
              <div className="lp-for-card lp-anim" key={role} style={{transitionDelay:`${i*120}ms`}}>
                <div className="lp-for-card-accent" style={{background:accent}}></div>
                <span className="lp-for-icon">{icon}</span>
                <div className="lp-for-role" style={{color:roleColor}}>{role}</div>
                <h3 className="lp-for-h3">{h}</h3>
                <p className="lp-for-p">{p}</p>
                <div className="lp-for-feats">
                  {feats.map(f => (
                    <span className="lp-for-feat" key={f}>
                      <span className="lp-for-check" style={{color:accent}}>✓</span>
                      {f}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section id="lp-cta">
        <div className="lp-cta-inner lp-anim">
          <h2 className="lp-cta-h2">
            Ready to eat smarter<br/>and waste <em>nothing?</em>
          </h2>
          <p className="lp-cta-p">
            Join households, food banks, and businesses already using TogetherTableAI to track, plan, and give back — powered by Gemini AI.
          </p>
          <button className="lp-cta-btn" onClick={() => onShowAuth('signup')}>
            <span>🚀</span> Get started free
          </button>
          <p className="lp-cta-note">No credit card required · Free forever plan · Set up in 60 seconds</p>
        </div>
      </section>

      {/* FOOTER */}
      <footer id="lp-footer">
        <div className="lp-foot-logo">
          <span style={{color:'#e66f3d'}}>●</span>
          Together<em>TableAI</em>
        </div>
        <div className="lp-foot-links">
          <span className="lp-foot-link">Privacy</span>
          <span className="lp-foot-link">Terms</span>
          <span className="lp-foot-link">Contact</span>
        </div>
        <div className="lp-foot-copy">© 2025 TogetherTableAI · Built for communities</div>
      </footer>
    </div>
  )
}





// ─────────────────────────────────────────────
// LOCATION SETTINGS ROW — used inside SettingsPanel
// ─────────────────────────────────────────────
function LocationSettingsRow({ label, sub, address, input, setInput, loading, error, onSubmit, onGPS, onClear }) {
  return (
    <div>
      {/* Current address display */}
      {address ? (
        <div className="settings-row" style={{ alignItems: 'flex-start', flexDirection: 'column', gap: 8 }}>
          <div className="settings-row-info">
            <div className="settings-row-label">{label}</div>
            <div className="settings-row-sub">{sub}</div>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, width: '100%',
            background: 'var(--cream)', borderRadius: 10, padding: '9px 13px',
            border: '1.5px solid rgba(196,113,74,.2)' }}>
            <span style={{ fontSize: '1rem' }}>📍</span>
            <span style={{ flex: 1, fontSize: '.84rem', fontWeight: 500, color: 'var(--earth)',
              overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{address}</span>
            <span style={{ fontSize: '.67rem', fontWeight: 700, background: 'var(--clay)', color: 'white',
              padding: '2px 8px', borderRadius: 50, flexShrink: 0 }}>SET</span>
            {onClear && (
              <button onClick={onClear} style={{ background: 'none', border: 'none', cursor: 'pointer',
                fontSize: '.72rem', color: 'var(--muted)', textDecoration: 'underline', padding: 0, flexShrink: 0 }}>
                Clear
              </button>
            )}
          </div>
        </div>
      ) : (
        <div className="settings-row settings-row-col">
          <div className="settings-row-info">
            <div className="settings-row-label">{label}</div>
            <div className="settings-row-sub">{sub}</div>
          </div>
        </div>
      )}

      {/* Input row */}
      <div style={{ display: 'flex', gap: 7, marginTop: 10 }}>
        <input
          className="search-input"
          style={{ flex: 1, fontSize: '.84rem', padding: '9px 14px', borderRadius: 50,
            background: 'white', border: '1.5px solid rgba(61,46,30,.15)' }}
          type="text" value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && onSubmit(input)}
          placeholder={address ? 'Update address…' : 'Enter address or zip code…'}
          disabled={loading}
        />
        <button className="add-btn"
          style={{ padding: '9px 18px', borderRadius: 50, fontSize: '.82rem', whiteSpace: 'nowrap', opacity: loading ? .5 : 1 }}
          onClick={() => onSubmit(input)} disabled={loading || !input.trim()}>
          {loading ? '…' : address ? 'Update' : 'Set'}
        </button>
        <button title="Use my GPS location" className="add-btn"
          style={{ padding: '9px 13px', borderRadius: 50, background: 'var(--earth)', fontSize: '.9rem', opacity: loading ? .5 : 1 }}
          onClick={onGPS} disabled={loading}>
          🎯
        </button>
      </div>
      {error && <p style={{ fontSize: '.75rem', color: '#c0392b', marginTop: 6, marginLeft: 2 }}>⚠️ {error}</p>}
    </div>
  )
}

// ─────────────────────────────────────────────
// CUSTOMER APP
// ─────────────────────────────────────────────
function CustomerApp({ user, onLogout, shelters, setShelters, groceryStores, sharedRestaurants = [], onDonationUpdate, theme, onThemeChange }) {
  const storageKey = `tt_user_${user.username}`

  function loadUserData() {
    const saved = loadFromStorage(storageKey, null)
    if (saved) return saved
    return { pantry: DEFAULT_PANTRY, activePlan: 'none', historyBuyList: [], historyAvoidList: [], incomingDonations: [], nextId: 1, mealPlansCustom: null }
  }

  const [userData, setUserData] = useState(loadUserData)
  const { pantry, activePlan, historyBuyList, historyAvoidList, nextId } = userData

  // mealPlans including custom
  const [mealPlans, setMealPlans] = useState(() => {
    const base = { ...MEAL_PLANS_DATA }
    if (userData.mealPlansCustom) base.custom = userData.mealPlansCustom
    return base
  })

  function saveUserData(updates) {
    const newData = { ...userData, ...updates }
    setUserData(newData)
    const toSave = { ...newData, mealPlansCustom: mealPlans.custom || null }
    localStorage.setItem(storageKey, JSON.stringify(toSave))
    dbSave(storageKey, toSave)
  }

  function saveMealPlans(newPlans) {
    setMealPlans(newPlans)
    const toSave = { ...userData, mealPlansCustom: newPlans.custom || null }
    localStorage.setItem(storageKey, JSON.stringify(toSave))
    dbSave(storageKey, toSave)
  }

  const [view, setView] = useState('pantry')
  const [search, setSearch] = useState('')
  const [toast, setToast] = useState('')
  const [nearbyTab, setNearbyTab] = useState('grocery')
  const [shelterSort, setShelterSort] = useState('closest')
  const [mapTab, setMapTab] = useState('banks')
  const myDonationHistory = (() => {
    try { return (JSON.parse(localStorage.getItem('tt_donations') || '[]')).filter(d => d.donor === user.username) } catch { return [] }
  })()
  const [nearbySort, setNearbySort] = useState('closest')
  const [recFilter, setRecFilter] = useState('all')
  const [shoppingTab, setShoppingTab] = useState('buy')

  // User location
  const [userAddress, setUserAddress] = useState(() => { try { return JSON.parse(localStorage.getItem('tt_user_loc_' + user.username) || '""') || '' } catch { return '' } })
  const [userCoords, setUserCoords] = useState(null)
  const [userLocInput, setUserLocInput] = useState('')
  const [userLocLoading, setUserLocLoading] = useState(false)
  const [userLocError, setUserLocError] = useState('')

  async function applyUserLocation(addr) {
    if (!addr.trim()) return
    setUserLocLoading(true); setUserLocError('')
    try {
      const coords = await geocodeAddress(addr)
      if (coords) {
        setUserCoords(coords); setUserAddress(addr); setUserLocInput('')
        localStorage.setItem('tt_user_loc_' + user.username, JSON.stringify(addr))
        showToast('\u{1F4CD} Your location is set!')
      } else {
        setUserLocError('Address not found — try a more specific address.')
      }
    } catch { setUserLocError('Could not geocode address. Check your Maps API key.') }
    setUserLocLoading(false)
  }

  function useGPS() {
    if (!navigator.geolocation) { setUserLocError('Geolocation not supported by your browser.'); return }
    setUserLocLoading(true); setUserLocError('')
    navigator.geolocation.getCurrentPosition(
      async pos => {
        const { latitude: lat, longitude: lng } = pos.coords
        setUserCoords({ lat, lng })
        try {
          await loadGoogleMaps()
          const geocoder = new window.google.maps.Geocoder()
          geocoder.geocode({ location: { lat, lng } }, (results, status) => {
            const label = (status === 'OK' && results[0]) ? results[0].formatted_address : lat.toFixed(4) + ', ' + lng.toFixed(4)
            setUserAddress(label)
            localStorage.setItem('tt_user_loc_' + user.username, JSON.stringify(label))
            showToast('\u{1F4CD} Location detected!'); setUserLocLoading(false)
          })
        } catch {
          setUserAddress(lat.toFixed(4) + ', ' + lng.toFixed(4)); setUserLocLoading(false); showToast('\u{1F4CD} Location detected!')
        }
      },
      () => { setUserLocError('Could not get GPS location. Try typing your address.'); setUserLocLoading(false) },
      { timeout: 10000 }
    )
  }

  React.useEffect(() => {
    if (userAddress && !userCoords) {
      geocodeAddress(userAddress).then(c => { if (c) setUserCoords(c) }).catch(() => {})
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const userMarker = userCoords
    ? [{ name: 'Your Location', address: userAddress, lat: userCoords.lat, lng: userCoords.lng, type: 'user' }]
    : []

  // Modals
  const [addModal, setAddModal] = useState(false)
  const [addInput, setAddInput] = useState('')
  const [addItems, setAddItems] = useState([])
  const [reasonModal, setReasonModal] = useState(null) // {id, name, emoji}
  const [selectionMode, setSelectionMode] = useState(false)
  const [selectedItems, setSelectedItems] = useState(new Set())
  const [donateModal, setDonateModal] = useState(false)
  const [donateItems, setDonateItems] = useState([])
  const [selectedShelter, setSelectedShelter] = useState(null)
  const [selectedTimeSlot, setSelectedTimeSlot] = useState(null)
  const [aiResultModal, setAiResultModal] = useState(false)
  const [aiResult, setAiResult] = useState(null)
  // Image scan modal
  const [imageScanModal, setImageScanModal] = useState(false)
  const [imageScanLoading, setImageScanLoading] = useState(false)
  const [imageScanItems, setImageScanItems] = useState([])
  const [imageScanPreview, setImageScanPreview] = useState(null)
  // AI Meal Plan modal
  const [aiMealPlanLoading, setAiMealPlanLoading] = useState(false)
  const [aiMealPlanResult, setAiMealPlanResult] = useState(() => userData.aiMealPlanResult || null)
  const [aiMealPlanDay, setAiMealPlanDay] = useState(() => userData.aiMealPlanDay || 0)
  const [aiMealPlanPrefs, setAiMealPlanPrefs] = useState('')
  const [shoppingConfirm, setShoppingConfirm] = useState(false)
  // ── AI Meal Plan modal
  const [buildPlanModal, setBuildPlanModal] = useState(false)
  const [cpStep, setCpStep] = useState(1)
  const [cpGoals, setCpGoals] = useState([])
  const [cpRestrictions, setCpRestrictions] = useState([])
  const [cpAllergies, setCpAllergies] = useState([])
  const [cpIncludeFoods, setCpIncludeFoods] = useState([])
  const [cpExcludeFoods, setCpExcludeFoods] = useState([])
  const [cpIncludeInput, setCpIncludeInput] = useState('')
  const [cpExcludeInput, setCpExcludeInput] = useState('')
  // eslint-disable-next-line no-unused-vars
  const [cpMatches, setCpMatches] = useState([])
  const [cpSelectedMatch, setCpSelectedMatch] = useState(null)
  const [cpAiLoading, setCpAiLoading] = useState(false)
  const [cpAiResult, setCpAiResult] = useState(null)
  const [cpAiDay, setCpAiDay] = useState(0)
  const [cpDays, setCpDays] = useState(7)
  const [swipeModal, setSwipeModal] = useState(false)
  const [swipeQueue, setSwipeQueue] = useState([])
  const [swipeIndex, setSwipeIndex] = useState(0)
  const [swipeWillFinish, setSwipeWillFinish] = useState([])
  const [swipeMayNot, setSwipeMayNot] = useState([])
  const [swipeDone, setSwipeDone] = useState(false)
  const [swipeDragX, setSwipeDragX] = useState(0)
  const [swipeDragging, setSwipeDragging] = useState(false)
  const [swipeAnimating, setSwipeAnimating] = useState(null) // 'left' | 'right' | null
  const swipeDragStart = React.useRef(null)
  const swipeCardRef = React.useRef(null)
  const [aiLoading, setAiLoading] = useState(false)
  const [storeModal, setStoreModal] = useState(null) // {name, emoji}
  const [dietConflicts, setDietConflicts] = useState({}) // { itemId: reason }
  const [conflictChecking, setConflictChecking] = useState(false)

  function showToast(msg) { setToast(msg); setTimeout(() => setToast(''), 4000) }

  // Arrow key scrolling
  useEffect(() => {
    const handleKey = (e) => {
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.tagName === 'SELECT') return
      if (e.key === 'ArrowDown') { e.preventDefault(); window.scrollBy({ top: 220, behavior: 'smooth' }) }
      if (e.key === 'ArrowUp') { e.preventDefault(); window.scrollBy({ top: -220, behavior: 'smooth' }) }
    }
    window.addEventListener('keydown', handleKey)
    return () => window.removeEventListener('keydown', handleKey)
  }, [])
  function changeQty(id, delta) {
    const item = pantry.find(f => f.id === id)
    if (!item) return
    if (item.qty + delta <= 0) { setReasonModal({ id, name: item.name, emoji: item.emoji }); return }
    const newPantry = pantry.map(f => f.id === id ? { ...f, qty: f.qty + delta } : f)
    saveUserData({ pantry: newPantry })
  }

  function confirmRemoval(reason) {
    const item = pantry.find(f => f.id === reasonModal.id)
    if (!item) { setReasonModal(null); return }
    let newBuyList = historyBuyList, newAvoidList = historyAvoidList
    if (reason === 'consumed') newBuyList = [...historyBuyList.filter(b => b.name !== item.name), { ...item }]
    if (reason === 'expired')  newAvoidList = [...historyAvoidList.filter(a => a.name !== item.name), { ...item }]
    const newPantry = pantry.filter(f => f.id !== reasonModal.id)
    saveUserData({ pantry: newPantry, historyBuyList: newBuyList, historyAvoidList: newAvoidList })
    setReasonModal(null)
    showToast(reason === 'consumed' ? '🍽️ Marked as consumed — added to Buy Again list!' : reason === 'expired' ? '🗑️ Removed — added to Don\'t Buy list.' : reason === 'donated' ? '🤝 Removed from pantry.' : '🗑️ Item removed.')
  }

  function addMultiItem() {
    if (!addInput.trim()) return
    const names = addInput.split(',').map(s => s.trim()).filter(Boolean)
    const newItems = names.map(name => ({ name, emoji: guessEmoji(name), category: 'Other', qty: 1 }))
    setAddItems(prev => [...prev, ...newItems])
    setAddInput('')
  }

  function confirmMultiAdd() {
    let id = nextId
    const newItems = addItems.map(item => {
      const existing = pantry.find(f => f.name.toLowerCase() === item.name.toLowerCase())
      if (existing) return null
      return { ...item, id: id++ }
    }).filter(Boolean)
    const merged = [...pantry, ...newItems]
    saveUserData({ pantry: merged, nextId: id })
    setAddModal(false)
    setAddItems([])
    setAddInput('')
    showToast(`✅ Added ${newItems.length} item${newItems.length !== 1 ? 's' : ''} to pantry`)
  }

  function updateAddItemField(idx, field, value) {
    setAddItems(prev => prev.map((it, i) => i === idx ? { ...it, [field]: value } : it))
  }

  function removeAddItem(idx) {
    setAddItems(prev => prev.filter((_, i) => i !== idx))
  }

  function addFromRec(name, emoji, category) {
    const existing = pantry.find(f => f.name === name)
    let newPantry
    if (existing) newPantry = pantry.map(f => f.name === name ? { ...f, qty: f.qty + 1 } : f)
    else newPantry = [...pantry, { id: nextId, name, emoji, category: category || 'Other', qty: 1 }]
    const newBuyList = historyBuyList.filter(b => b.name !== name)
    saveUserData({ pantry: newPantry, historyBuyList: newBuyList, nextId: existing ? nextId : nextId + 1 })
    setView('pantry')
    showToast(`✅ ${name} added to pantry!`)
  }

  function removeFromBuyNext(name) {
    // Remove from historyBuyList (consumed/history recs)
    const newBuyList = historyBuyList.filter(b => b.name !== name)
    // Remove from active plan's buy array too
    const newPlans = { ...mealPlans }
    Object.keys(newPlans).forEach(k => {
      if (newPlans[k]?.buy) newPlans[k] = { ...newPlans[k], buy: newPlans[k].buy.filter(b => b.name !== name) }
    })
    saveMealPlans(newPlans)
    saveUserData({ historyBuyList: newBuyList })
    showToast(`🗑️ ${name} removed from Buy Next`)
  }

  // ── Meal plan + Diet conflict check (v16 changes) ──
  async function checkDietConflicts(itemsList, plan) {
    if (!plan || plan === 'none' || !itemsList.length) { setDietConflicts({}); return }
    setConflictChecking(true)
    showToast('🔍 Checking pantry against your diet…')
    try {
      const prompt = `You are a strict dietary expert. For each food item, check if it conflicts with the "${plan}" diet. Items: ${JSON.stringify(itemsList.map(f => f.name))}. Return ONLY valid JSON array, no markdown, no explanation: [{"name":"item name","conflicts":true,"reason":"under 8 words"} or {"name":"item name","conflicts":false,"reason":null}]`
      const text = await callGemini(prompt)
      const results = extractGeminiJSON(text)
      const map = {}
      itemsList.forEach(f => {
        const match = Array.isArray(results) && results.find(r => r.name.toLowerCase() === f.name.toLowerCase())
        if (match && match.conflicts) map[f.id] = match.reason || 'Conflicts with your meal plan'
      })
      setDietConflicts(map)
      const count = Object.keys(map).length
      showToast(count > 0 ? `⚠️ ${count} item${count !== 1 ? 's' : ''} conflict with this plan` : '✅ No conflicts with your plan!')
    } catch (e) {
      console.error('Diet check failed', e)
      showToast(e.message.includes('API key') ? '🔑 AI features are not available' : '⚠️ Could not check conflicts')
    }
    setConflictChecking(false)
  }

  function setActivePlan(val) {
    saveUserData({ activePlan: val })
    if (val === 'none') { setDietConflicts({}); return }
    checkDietConflicts(pantry, val)
  }


  // ── Build Your Own Plan ──
  function openBuildPlanModal() {
    setCpStep(1)
    setCpGoals([])
    setCpRestrictions([])
    setCpAllergies([])
    setCpIncludeFoods([])
    setCpExcludeFoods([])
    setCpIncludeInput('')
    setCpExcludeInput('')
    setCpMatches([])
    setCpSelectedMatch(null)
    setCpAiLoading(false)
    setCpAiResult(null)
    setCpAiDay(0)
    setCpDays(5)
    setBuildPlanModal(true)
  }

  async function cpGenerateAIPlan() {
    const key = getGeminiKey()
    if (!key) { showToast('🔑 AI features are not available'); return }

    setCpAiLoading(true)
    setCpAiResult(null)

    const goalsStr = cpGoals.join(', ') || 'general healthy eating'
    const restrictStr = cpRestrictions.filter(r => r !== 'none').join(', ') || 'none'
    const allergyStr = cpAllergies.filter(a => a !== 'none').join(', ') || 'none'
    const includeStr = cpIncludeFoods.join(', ') || 'none'
    const excludeStr = cpExcludeFoods.join(', ') || 'none'
    const pantryStr = pantry.map(f => f.name).join(', ') || 'general pantry'

    const prompt = `You are a professional nutritionist AI. Create a ${cpDays}-day personalized meal plan and shopping guide.
Goals: ${goalsStr}
Dietary restrictions: ${restrictStr}
Allergies: ${allergyStr}
Foods to always include: ${includeStr}
Foods to always avoid: ${excludeStr}
Current pantry: ${pantryStr}

Return ONLY valid JSON, no markdown fences. Schema:
{"planName":"Descriptive plan name","days":[{"day":"Monday","meals":[{"type":"Breakfast","name":"Meal name","ingredients":["item1"],"calories":350,"time":"10 min","emoji":"emoji"},{"type":"Lunch","name":"Meal name","ingredients":["item1"],"calories":450,"time":"15 min","emoji":"emoji"},{"type":"Dinner","name":"Meal name","ingredients":["item1"],"calories":600,"time":"30 min","emoji":"emoji"}]}],"buyList":[{"name":"Food item","emoji":"emoji","reason":"Why this supports the goals","priority":"high","foodGroup":"vegetables"}],"avoidList":[{"name":"Food item","emoji":"emoji","reason":"Why to avoid given goals/restrictions","badge":"off-plan","badgeLabel":"Avoid"}],"weeklyCalories":14700,"tips":"One personalized tip"}

Rules: buyList = 8-15 foods not in pantry that support the goals. avoidList = 5-10 foods to skip. foodGroup must be one of: carbs, proteins, dairy, fruits, vegetables, snacks, meals, beverages, condiments, frozen, canned, bakery, legumes. priority: high/med/low. Every day needs breakfast, lunch, dinner.`

    try {
      const model = await getWorkingModel(key)
      const res = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`,
        { method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }], generationConfig: GEMINI_GEN_CFG }) }
      )
      if (!res.ok) throw new Error(`Gemini error ${res.status}`)
      const data = await res.json()
      const text = data.candidates?.[0]?.content?.parts?.[0]?.text || '{}'
      const result = extractGeminiJSON(text)
      setCpAiResult(result)
      setCpAiDay(0)
    } catch(e) {
      showToast(e.message.includes('API key') ? '🔑 AI features unavailable' : '⚠️ Generation failed: ' + e.message)
    }
    setCpAiLoading(false)
  }

  function cpApplyAndGoToMeals() {
    // Build mealPlans.custom from AI-generated buyList + avoidList
    const aiPlan = cpAiResult
    const customPlan = {
      name: aiPlan.planName || 'My AI Plan',
      emoji: '✨',
      pillClass: 'custom',
      desc: `AI-generated plan based on your goals: ${cpGoals.join(', ') || 'healthy eating'}`,
      buy: (aiPlan.buyList || aiPlan.shoppingList?.map(name => ({
        name, emoji: guessEmoji(name), reason: 'Recommended by your AI meal plan.', priority: 'high', foodGroup: 'meals'
      })) || []).map(item => ({
        emoji: item.emoji || guessEmoji(item.name || item),
        name: item.name || item,
        reason: item.reason || 'Recommended by your AI meal plan.',
        priority: item.priority || 'high',
        foodGroup: item.foodGroup || 'meals',
        source: 'plan'
      })),
      avoid: (aiPlan.avoidList || []).map(item => ({
        emoji: item.emoji || guessEmoji(item.name || item),
        name: item.name || item,
        reason: item.reason || 'Flagged by your AI meal plan.',
        badge: item.badge || 'off-plan',
        badgeLabel: item.badgeLabel || 'Avoid'
      })),
    }
    // Also add any manually excluded foods
    cpExcludeFoods.forEach(f => {
      if (!customPlan.avoid.some(a => a.name.toLowerCase() === f.toLowerCase())) {
        customPlan.avoid.push({ emoji: guessEmoji(f), name: f, reason: 'You chose to avoid this food.', badge: 'off-plan', badgeLabel: 'Your Choice' })
      }
    })
    // Save as custom plan and activate it
    const newPlans = { ...mealPlans, custom: customPlan }
    saveMealPlans(newPlans)
    setActivePlan('custom')
    // Show the AI weekly schedule in the meal plan tab
    setAiMealPlanResult(aiPlan)
    setAiMealPlanDay(0)
    setView('meals')
    setBuildPlanModal(false)
    showToast('✨ Your AI plan is live — shopping list updated!')
  }

  function cpToggle(list, setList, val) {
    setList(list.includes(val) ? list.filter(v => v !== val) : [...list, val])
  }

  function cpAddFood(type) {
    const raw = (type === 'include' ? cpIncludeInput : cpExcludeInput).trim()
    if (!raw) return
    raw.split(',').map(s => s.trim()).filter(Boolean).forEach(name => {
      if (type === 'include') {
        setCpIncludeFoods(prev => prev.includes(name) ? prev : [...prev, name])
        setCpIncludeInput('')
      } else {
        setCpExcludeFoods(prev => prev.includes(name) ? prev : [...prev, name])
        setCpExcludeInput('')
      }
    })
  }

  // eslint-disable-next-line no-unused-vars
  function cpComputeMatches() {
    const allTags = [...cpGoals, ...cpRestrictions, ...cpAllergies]
    const planKeys = Object.keys(mealPlans).filter(k => k !== 'none' && k !== 'custom')
    const scores = {}
    planKeys.forEach(k => scores[k] = 0)
    allTags.forEach(tag => {
      const mapping = PLAN_SCORING[tag] || {}
      Object.entries(mapping).forEach(([plan, pts]) => { if (scores[plan] !== undefined) scores[plan] += pts })
    })
    const ranked = planKeys.map(k => ({ key: k, score: scores[k] }))
      .sort((a, b) => b.score - a.score).filter(x => x.score > 0).slice(0, 4)
    setCpMatches(ranked)
    setCpSelectedMatch(ranked.length > 0 ? ranked[0].key : (cpIncludeFoods.length > 0 || cpExcludeFoods.length > 0 ? '_custom_only' : null))
    setCpStep(5)
  }

  // eslint-disable-next-line no-unused-vars
  function cpApplyPlan() {
    const hasCustomFoods = cpIncludeFoods.length > 0 || cpExcludeFoods.length > 0
    let newPlans = { ...mealPlans }

    if (cpSelectedMatch === '_custom_only') {
      newPlans.custom = {
        name: 'Your Custom Plan', emoji: '✨', pillClass: 'custom',
        desc: 'A personalised plan built from your own food preferences.',
        buy: cpIncludeFoods.map(f => ({ emoji: guessEmoji(f), name: f, reason: 'Added by you as a preferred food.', priority: 'high', foodGroup: 'meals' })),
        avoid: cpExcludeFoods.map(f => ({ emoji: guessEmoji(f), name: f, reason: 'Added by you as a food to avoid.', badge: 'off-plan', badgeLabel: 'Your Choice' })),
      }
      saveMealPlans(newPlans)
      setActivePlan('custom')
    } else if (hasCustomFoods && cpSelectedMatch) {
      const base = mealPlans[cpSelectedMatch]
      const existingBuyNames = new Set(base.buy.map(f => f.name.toLowerCase()))
      const existingAvoidNames = new Set(base.avoid.map(f => f.name.toLowerCase()))
      newPlans.custom = {
        name: base.name + ' (Custom)', emoji: base.emoji, pillClass: 'custom', desc: base.desc,
        buy: [...base.buy, ...cpIncludeFoods.filter(f => !existingBuyNames.has(f.toLowerCase())).map(f => ({ emoji: guessEmoji(f), name: f, reason: 'Added by you as a preferred food.', priority: 'high', foodGroup: 'meals' }))],
        avoid: [...base.avoid, ...cpExcludeFoods.filter(f => !existingAvoidNames.has(f.toLowerCase())).map(f => ({ emoji: guessEmoji(f), name: f, reason: 'Added by you as a food to avoid.', badge: 'off-plan', badgeLabel: 'Your Choice' }))],
      }
      saveMealPlans(newPlans)
      setActivePlan('custom')
    } else if (cpSelectedMatch) {
      setActivePlan(cpSelectedMatch)
    }
    setBuildPlanModal(false)
  }

  // ── Swipe sort ──
  function openSwipeModal() {
    setSwipeQueue([...pantry])
    setSwipeIndex(0)
    setSwipeWillFinish([])
    setSwipeMayNot([])
    setSwipeDone(false)
    setSwipeModal(true)
  }

  function swipeCard(dir) {
    if (swipeAnimating) return
    const item = swipeQueue[swipeIndex]
    if (!item) return
    setSwipeAnimating(dir)
    setSwipeDragX(0)
    setSwipeDragging(false)
    swipeDragStart.current = null
    setTimeout(() => {
      if (dir === 'right') setSwipeWillFinish(prev => [...prev, item])
      else setSwipeMayNot(prev => [...prev, item])
      const next = swipeIndex + 1
      setSwipeIndex(next)
      setSwipeAnimating(null)
      if (next >= swipeQueue.length) { setSwipeDone(true); setTimeout(() => runAISort(), 600) }
    }, 400)
  }

  function onDragStart(clientX) {
    swipeDragStart.current = clientX
    setSwipeDragging(true)
  }
  function onDragMove(clientX) {
    if (!swipeDragging || swipeDragStart.current === null) return
    setSwipeDragX(clientX - swipeDragStart.current)
  }
  function onDragEnd() {
    if (!swipeDragging) return
    setSwipeDragging(false)
    if (swipeDragX > 80) swipeCard('right')
    else if (swipeDragX < -80) swipeCard('left')
    else setSwipeDragX(0)
    swipeDragStart.current = null
  }

  async function runAISort() {
    setAiLoading(true)
    setSwipeModal(false)
    setAiResultModal(true)
    const willStr = swipeWillFinish.map(f => `${f.name} (qty:${f.qty})`).join(', ')
    const mayStr  = swipeMayNot.map(f => `${f.name} (qty:${f.qty})`).join(', ')
    try {
      const prompt = `Pantry sort assistant. WILL FINISH: ${willStr || 'none'}. MAY NOT FINISH: ${mayStr || 'none'}. Respond ONLY in JSON, no markdown: {"donate":[{"emoji":"🍎","name":"Apple","reason":"Short reason"}],"buyNext":[{"emoji":"🥛","name":"Milk","reason":"Short reason"}]}`
      const text   = await callGemini(prompt)
      const parsed = extractGeminiJSON(text)
      setAiResult(parsed)
    } catch (e) {
      const fallbackMsg = e.message.includes('API key') ? 'AI features unavailable.' : 'AI unavailable — showing smart defaults.'
      showToast('⚠️ ' + fallbackMsg)
      setAiResult({
        donate:  swipeMayNot.filter((_, i) => i % 2 === 0).map(f => ({ emoji:f.emoji, name:f.name, reason:'Unlikely to finish — consider donating.' })),
        buyNext: [...swipeWillFinish, ...swipeMayNot.filter((_, i) => i % 2 !== 0)].map(f => ({ emoji:f.emoji, name:f.name, reason:"You'll use this — restock when low." }))
      })
    }
    setAiLoading(false)
  }

  // ── Swipe keyboard support ──
  useEffect(() => {
    if (!swipeModal || swipeDone) return
    const handler = (e) => {
      if (e.key === 'ArrowLeft')  { e.preventDefault(); swipeCard('left') }
      if (e.key === 'ArrowRight') { e.preventDefault(); swipeCard('right') }
    }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [swipeModal, swipeDone, swipeIndex, swipeAnimating])

  // ── Image Scan (Google Cloud Vision) ──
  async function handleImageScan(file) {
    if (!file) return
    setImageScanLoading(true)
    setImageScanItems([])
    const reader = new FileReader()
    reader.onload = (e) => setImageScanPreview(e.target.result)
    reader.readAsDataURL(file)
    try {
      const base64 = await new Promise((res, rej) => {
        const r = new FileReader()
        r.onload = () => res(r.result.split(',')[1])
        r.onerror = () => rej(new Error('Read failed'))
        r.readAsDataURL(file)
      })
      const items = await callCloudVision(base64)
      if (!Array.isArray(items) || items.length === 0) {
        showToast('🤔 No food items detected in this image.')
        setImageScanLoading(false)
        return
      }
      const enriched = items.map(item => ({ ...item, emoji: item.emoji || guessEmoji(item.name), qty: item.qty || 1, category: item.category || 'Other' }))
      setImageScanItems(groupScanItems(enriched))
    } catch(e) {
      showToast(e.message.includes('not configured') ? '🔑 Vision key not set — add REACT_APP_GOOGLE_VISION_KEY to .env' : '⚠️ Scan failed: ' + e.message)
    }
    setImageScanLoading(false)
  }
  // ── Group/merge scanned items: apple+apples→Apple, but red grapes≠green grapes ──
  function groupScanItems(items) {
    if (!items || items.length === 0) return items
    const GENERIC_MODS = new Set([
      'red','green','yellow','orange','purple','white','black','brown','pink',
      'golden','fresh','ripe','raw','large','small','medium','big','little',
      'whole','sliced','chopped','diced','frozen','dried','organic','baby',
    ])
    const VARIETY_WORDS = new Set([
      'grape','grapes','pepper','peppers','onion','onions','cabbage','lettuce',
      'bean','beans','lentil','lentils','potato','potatoes','tomato','tomatoes',
    ])
    function baseKey(name) {
      const words = name.toLowerCase().trim().split(/\s+/)
      const meaningful = words.filter(w => !GENERIC_MODS.has(w))
      const base = meaningful.join(' ')
      return base.endsWith('s') ? base.slice(0, -1) : base
    }
    function shouldMerge(a, b) {
      if (baseKey(a.name) !== baseKey(b.name)) return false
      const aFull = a.name.toLowerCase()
      const bFull = b.name.toLowerCase()
      for (const vw of VARIETY_WORDS) {
        if (aFull.includes(vw) && bFull.includes(vw)) {
          const aMod = aFull.split(/\s+/).find(w => !GENERIC_MODS.has(w) && w !== vw)
          const bMod = bFull.split(/\s+/).find(w => !GENERIC_MODS.has(w) && w !== vw)
          if (aMod && bMod && aMod !== bMod) return false
        }
      }
      return true
    }
    function canonicalName(a, b) {
      const aWords = a.name.toLowerCase().split(/\s+/).filter(w => !GENERIC_MODS.has(w))
      const bWords = b.name.toLowerCase().split(/\s+/).filter(w => !GENERIC_MODS.has(w))
      const chosen = aWords.length <= bWords.length ? a.name : b.name
      return chosen.replace(/\b\w/g, c => c.toUpperCase())
    }
    const merged = []; const used = new Set()
    for (let i = 0; i < items.length; i++) {
      if (used.has(i)) continue
      let cur = { ...items[i] }
      for (let j = i + 1; j < items.length; j++) {
        if (used.has(j)) continue
        if (shouldMerge(cur, items[j])) {
          cur = { ...cur, name: canonicalName(cur, items[j]), qty: (cur.qty || 1) + (items[j].qty || 1) }
          used.add(j)
        }
      }
      merged.push(cur)
    }
    return merged
  }

  function confirmImageScanAdd() {
    const norm = name => name.toLowerCase().replace(/s$/, '')
    let id = nextId
    const newItems = []
    let added = 0, bumped = 0
    const updatedPantry = pantry.map(f => {
      const match = imageScanItems.find(item => norm(item.name) === norm(f.name))
      if (match) { bumped++; return { ...f, qty: (f.qty || 1) + (match.qty || 1) } }
      return f
    })
    imageScanItems.forEach(item => {
      const exists = pantry.find(f => norm(item.name) === norm(f.name))
      if (!exists) { newItems.push({ ...item, id: id++ }); added++ }
    })
    saveUserData({ pantry: [...updatedPantry, ...newItems], nextId: id })
    setImageScanModal(false); setImageScanPreview(null); setImageScanItems([])
    const parts = []
    if (added) parts.push(`${added} item${added !== 1 ? 's' : ''} added`)
    if (bumped) parts.push(`${bumped} updated`)
    showToast(`✅ ${parts.join(', ')} from photo!`)
  }
  function updateScanItem(idx, field, value) { setImageScanItems(prev => prev.map((it,i) => i===idx ? {...it,[field]:value} : it)) }
  function removeScanItem(idx) { setImageScanItems(prev => prev.filter((_,i) => i!==idx)) }

  // ── AI Meal Plan ──
  async function generateAIMealPlan() {
    let plan = activePlan
    if (plan === 'none') {
      plan = 'mediterranean'
      saveUserData({ activePlan: plan })
    }
    setAiMealPlanLoading(true); setAiMealPlanResult(null); setShoppingConfirm(false)
    saveUserData({ aiMealPlanResult: null, aiMealPlanDay: 0 })
    showToast('🧠 Gemini is crafting your 7-day meal plan…')
    try {
      const result = await callGeminiMealPlan(plan, pantry, aiMealPlanPrefs)
      setAiMealPlanResult(result); setAiMealPlanDay(0)
      saveUserData({ aiMealPlanResult: result, aiMealPlanDay: 0 })
    } catch(e) {
      console.error('[MealPlan] generation error:', e)
      showToast('⚠️ Meal plan failed: ' + e.message)
    }
    setAiMealPlanLoading(false)
  }

  // ── Donation ──
  function openDonateFromAI() {
    const items = aiResult?.donate || []
    setDonateItems(items)
    setSelectedShelter(null)
    setSelectedTimeSlot(null)
    setAiResultModal(false)
    setDonateModal(true)
  }

  const DROP_TIMES = ['9:00 AM', '10:30 AM', '12:00 PM', '1:30 PM', '3:00 PM', '4:30 PM']

  function confirmDonation() {
    if (!selectedShelter || !selectedTimeSlot) return
    const today = new Date()
    const dateStr = today.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })
    const donation = {
      donor: user.username,
      donorType: 'customer',
      shelter: selectedShelter.name,
      items: donateItems.map(f => ({ emoji: f.emoji, name: f.name, qty: f.qty || 1 })),
      time: selectedTimeSlot,
      date: dateStr,
      status: 'confirmed',
      id: Date.now()
    }

    // Remove donated items from pantry
    const donatedNames = new Set(donateItems.map(f => f.name.toLowerCase()))
    const newPantry = pantry.filter(p => !donatedNames.has(p.name.toLowerCase()))
    saveUserData({ pantry: newPantry })

    // Write to global tt_donations so food bank sees it
    onDonationUpdate(donation)

    // Update shelter inventory live
    setShelters(prev => prev.map(s => {
      if (s.name !== selectedShelter.name) return s
      const newInventory = [...(s.inventory || [])]
      donateItems.forEach(f => {
        const existing = newInventory.find(i => i.name.toLowerCase() === f.name.toLowerCase())
        if (existing) existing.qty = Math.min(existing.qty + (f.qty || 1), existing.cap || 999)
        else newInventory.push({ emoji: f.emoji || '📦', name: f.name, category: f.category || 'Donated', qty: f.qty || 1, cap: Math.max((f.qty || 1) * 3, 20) })
      })
      return { ...s, inventory: newInventory }
    }))

    setDonateModal(false)
    showToast(`✅ Donation confirmed for ${selectedShelter.name} at ${selectedTimeSlot}!`)
  }

  function toggleSelectionMode() {
    setSelectionMode(prev => !prev)
    setSelectedItems(new Set())
  }

  function toggleItemSelect(id) {
    setSelectedItems(prev => {
      const next = new Set(prev)
      next.has(id) ? next.delete(id) : next.add(id)
      return next
    })
  }

  function selectAll() {
    setSelectedItems(new Set(filteredPantry.map(f => f.id)))
  }

  function removeSelected() {
    if (selectedItems.size === 0) return
    if (!window.confirm(`Remove ${selectedItems.size} item${selectedItems.size !== 1 ? 's' : ''} from your pantry?`)) return
    const newPantry = pantry.filter(f => !selectedItems.has(f.id))
    saveUserData({ pantry: newPantry })
    setSelectedItems(new Set())
    setSelectionMode(false)
    showToast(`🗑️ ${selectedItems.size} item${selectedItems.size !== 1 ? 's' : ''} removed.`)
  }

  function donateSelected() {
    if (selectedItems.size === 0) return
    const items = pantry.filter(f => selectedItems.has(f.id))
    setDonateItems(items)
    setSelectedShelter(null)
    setSelectedTimeSlot(null)
    setSelectionMode(false)
    setSelectedItems(new Set())
    setDonateModal(true)
  }

  // ── Recs ──
  const recs = useMemo(() => getDynamicRecs(pantry, activePlan, mealPlans, historyBuyList, historyAvoidList), [pantry, activePlan, mealPlans, historyBuyList, historyAvoidList])
  const avoidList = useMemo(() => getDynamicAvoid(pantry, activePlan, mealPlans, historyAvoidList), [pantry, activePlan, mealPlans, historyAvoidList])

  const filteredRecs = recFilter === 'all' ? recs : recs.filter(r => (r.foodGroup || catToGroup[r.category] || 'meals') === recFilter)
  const filteredPantry = pantry.filter(f => f.name.toLowerCase().includes(search.toLowerCase()))

  const currentPlan = mealPlans[activePlan]

  // Inject real distances from userCoords into each list
  const sheltsDist = useMemo(() =>
    shelters.map(s => ({
      ...s,
      distanceMi: userCoords && s.lat && s.lng
        ? haversineDistMi(userCoords.lat, userCoords.lng, s.lat, s.lng)
        : s.distanceMi ?? '—'
    })),
  [shelters, userCoords])

  const storesDist = useMemo(() =>
    groceryStores.map(s => ({
      ...s,
      distanceMi: userCoords && s.lat && s.lng
        ? haversineDistMi(userCoords.lat, userCoords.lng, s.lat, s.lng)
        : s.distanceMi ?? '—'
    })),
  [groceryStores, userCoords])

  const restsDist = useMemo(() =>
    sharedRestaurants.map(r => ({
      ...r,
      distanceMi: userCoords && r.lat && r.lng
        ? haversineDistMi(userCoords.lat, userCoords.lng, r.lat, r.lng)
        : r.distanceMi ?? '—'
    })),
  [sharedRestaurants, userCoords])

  const sortedShelters = useMemo(() => {
    const list = [...sheltsDist]
    if (shelterSort === 'closest') list.sort((a, b) => (parseFloat(a.distanceMi) || 999) - (parseFloat(b.distanceMi) || 999))
    if (shelterSort === 'need')    list.sort((a, b) => b.peopleNeeded - a.peopleNeeded)
    if (shelterSort === 'open')    list.sort((a, b) => (isOpenNow(b) ? 1 : 0) - (isOpenNow(a) ? 1 : 0))
    return list
  }, [sheltsDist, shelterSort])

  const nearbyList = useMemo(() => {
    const data = [...(nearbyTab === 'grocery' ? storesDist : restsDist)]
    if (nearbySort === 'closest') data.sort((a, b) => (parseFloat(a.distanceMi) || 999) - (parseFloat(b.distanceMi) || 999))
    if (nearbySort === 'open')    data.sort((a, b) => (isOpenNow(b) ? 1 : 0) - (isOpenNow(a) ? 1 : 0))
    if (nearbySort === 'rating')  data.sort((a, b) => b.rating - a.rating)
    return data
  }, [nearbyTab, nearbySort, storesDist, restsDist])

  // All markers for the combined map views
  const allShelterMarkers = sortedShelters.filter(s => s.lat && s.lng).map(s => ({ name: s.name, address: s.address, hours: s.hours, lat: s.lat, lng: s.lng, type: 'foodbank' }))
  const allStoreMarkers   = storesDist.filter(s => s.lat && s.lng).map(s => ({ name: s.name, address: s.address, hours: s.hours, lat: s.lat, lng: s.lng, type: 'grocery' }))
  const allRestMarkers    = restsDist.filter(r => r.lat && r.lng).map(r => ({ name: r.name, address: r.address, hours: r.hours, lat: r.lat, lng: r.lng, type: 'restaurant' }))

  const storeCarrying = storeModal
    ? storesDist.filter(s => s.stocks && s.stocks.includes(storeModal.name)).sort((a, b) => (parseFloat(a.distanceMi) || 999) - (parseFloat(b.distanceMi) || 999))
    : []

  const planOptions = [
    { value: 'none', label: '🍽️ No Meal Plan' },
    { value: 'mediterranean', label: '🫒 Mediterranean' },
    { value: 'keto', label: '🥑 Keto / Low-Carb' },
    { value: 'vegan', label: '🌱 Vegan' },
    { value: 'highprotein', label: '💪 High Protein' },
    { value: 'lowcalorie', label: '🥗 Low Calorie' },
    { value: 'paleo', label: '🦴 Paleo' },
    { value: 'bulking', label: '🏋️ Bulking' },
    { value: 'cuttinglean', label: '✂️ Cutting / Lean' },
    { value: 'intermittentfasting', label: '⏱️ Intermittent Fasting' },
    { value: 'whole30', label: '🌿 Whole30' },
    { value: 'plantbased', label: '🌾 Plant-Based' },
    { value: 'dash', label: '💙 DASH' },
    { value: 'antiinflammatory', label: '🔥 Anti-Inflammatory' },
    { value: 'glutenfree', label: '🌾 Gluten-Free' },
    { value: 'diabeticfriendly', label: '🩺 Diabetic-Friendly' },
    { value: 'hearthealth', label: '❤️ Heart-Healthy' },
    { value: 'kidneyfriendly', label: '🫘 Kidney-Friendly' },
    { value: 'fodmap', label: '🥦 Low-FODMAP' },
    { value: 'prenatal', label: '🤰 Prenatal' },
    { value: 'postpartum', label: '🍼 Postpartum' },
    { value: 'cancersurvivor', label: '🎗️ Cancer Survivor' },
    ...(mealPlans.custom ? [{ value: 'custom', label: `✨ ${mealPlans.custom.name || 'My AI Plan'}` }] : [])
  ]

  return (
    <div id="customer-app">
      <header>
        <div className="logo">Together<span>TableAI</span></div>
        <div className="nav-btns">
          {[['pantry','🥫 My Pantry'],['meals','🧠 AI Meal Plan'],['map','📍 Food Banks'],['nearby','🏬 Nearby'],['recs','🛒 Shopping'],['settings','⚙️ Settings']].map(([v,label]) => (
            <button key={v} className={`nav-btn ${view === v ? 'active' : ''}`} onClick={() => setView(v)}>{label}</button>
          ))}
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div className="user-pill"><span className="u-name">{user.username}</span><span className="u-role">Customer</span></div>
          <button className="logout-btn" onClick={onLogout}>Sign Out</button>
        </div>
      </header>

      {/* ── PANTRY ── */}
      {view === 'pantry' && (
        <div className="view active">
          <h1 className="view-title">My Pantry</h1>
          <p className="view-sub">Track what you have at home.</p>
          <div className="plan-bar">
            <div className="plan-bar-label">
              Active Meal Plan &nbsp;
              {activePlan === 'none' || !currentPlan
                ? <span className="plan-pill none">None selected</span>
                : <span className={`plan-pill ${currentPlan.pillClass}`}>{currentPlan.emoji} {currentPlan.name}</span>
              }
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
              <select className="custom-select" value={activePlan} onChange={e => setActivePlan(e.target.value)}>
                {planOptions.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
              </select>
              <button className="create-plan-btn" onClick={openBuildPlanModal}>✨ AI Plan Builder</button>
              {conflictChecking && (
                <span className="conflict-checking">🔍 Checking…</span>
              )}
              {!conflictChecking && activePlan !== 'none' && (
                Object.keys(dietConflicts).length > 0
                  ? <span className="conflict-summary">⚠️ {Object.keys(dietConflicts).length} conflict{Object.keys(dietConflicts).length !== 1 ? 's' : ''}</span>
                  : <span className="conflict-summary none">✅ No conflicts</span>
              )}
            </div>
          </div>
          <div className="pantry-controls">
            <input className="search-input" type="text" value={search} onChange={e => setSearch(e.target.value)} placeholder="Search foods…" />
            <button className="add-btn" onClick={() => { setAddModal(true); setAddItems([]); setAddInput('') }}>+ Add Food</button>
            <button className="add-btn" style={{ background: 'var(--sage)' }} onClick={openSwipeModal}>🔀 Sort Pantry</button>
            <button className="add-btn" style={{ background: 'var(--honey)', color: '#2d2118' }} onClick={() => { setImageScanModal(true); setImageScanPreview(null); setImageScanItems([]) }}>📸 Scan with AI</button>
            <button className="add-btn" style={{ background: selectionMode ? 'var(--earth)' : '#7a6a5a' }} onClick={toggleSelectionMode}>{selectionMode ? '✕ Cancel' : '☑️ Select'}</button>
          </div>
          {selectionMode && (
            <div className="selection-action-bar">
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <span className="sel-count">{selectedItems.size} selected</span>
                <button className="sel-all-btn" onClick={selectAll}>Select All</button>
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <button
                  className="sel-remove-btn"
                  disabled={selectedItems.size === 0}
                  onClick={removeSelected}
                >🗑️ Remove</button>
                <button
                  className="sel-donate-btn"
                  disabled={selectedItems.size === 0}
                  onClick={donateSelected}
                >🤝 Donate All</button>
              </div>
            </div>
          )}
          {filteredPantry.length === 0
            ? <p style={{ color: 'var(--muted)', fontStyle: 'italic' }}>{pantry.length === 0 ? 'Your pantry is empty. Add some foods!' : 'No items match your search.'}</p>
            : (
              <div className="pantry-grid">
                {filteredPantry.map(f => {
                  const st = stockStatus(f.qty, f.category)
                  const conflictReason = dietConflicts[f.id]
                  const isSelected = selectedItems.has(f.id)
                  return (
                    <div
                      key={f.id}
                      className={`food-card${conflictReason ? ' has-conflict' : ''}${isSelected ? ' is-selected' : ''}`}
                      onClick={selectionMode ? () => toggleItemSelect(f.id) : undefined}
                      style={selectionMode ? { cursor: 'pointer' } : {}}
                    >
                      {selectionMode ? (
                        <div className={`food-card-checkbox ${isSelected ? 'checked' : ''}`}>
                          {isSelected ? '✓' : ''}
                        </div>
                      ) : (
                        <button className="delete-btn" onClick={() => { setReasonModal({ id: f.id, name: f.name, emoji: f.emoji }) }}>✕</button>
                      )}
                      <div className="food-emoji">{f.emoji}</div>
                      <div className="food-name">{f.name}</div>
                      <div className="food-meta">{f.category}</div>
                      <div className="qty-row">
                        <button className="qty-btn" onClick={selectionMode ? e => e.stopPropagation() : () => changeQty(f.id, -1)}>−</button>
                        <span className="qty-num">{f.qty}</span>
                        <button className="qty-btn" onClick={selectionMode ? e => e.stopPropagation() : () => changeQty(f.id, 1)}>+</button>
                      </div>
                      <span className={`tag ${st.cls}`}>{st.label}</span>
                      {conflictReason && (
                        <span className="diet-conflict-badge">
                          ⚠️ Diet Conflict
                          <span className="conflict-tooltip">{conflictReason}</span>
                        </span>
                      )}
                    </div>
                  )
                })}
              </div>
            )
          }
        </div>
      )}

      {/* ── FOOD BANKS ── */}
      {view === 'map' && (
        <div className="view active">
          <h1 className="view-title">Food Banks</h1>
          <p className="view-sub">Nearest locations to donate or receive support.</p>
          {/* Sub-tabs */}
          <div style={{ display:'flex', gap:8, marginBottom:18 }}>
            <button onClick={() => setMapTab('banks')} style={{ flex:1, padding:'9px 0', borderRadius:50, border:'none', fontWeight:700, fontSize:'.83rem', cursor:'pointer', background: mapTab==='banks' ? 'var(--earth)' : 'var(--card-bg)', color: mapTab==='banks' ? 'white' : 'var(--muted)', boxShadow: mapTab==='banks' ? 'var(--shadow)' : 'none' }}>🏛️ Find Banks</button>
            <button onClick={() => setMapTab('history')} style={{ flex:1, padding:'9px 0', borderRadius:50, border:'none', fontWeight:700, fontSize:'.83rem', cursor:'pointer', background: mapTab==='history' ? 'var(--earth)' : 'var(--card-bg)', color: mapTab==='history' ? 'white' : 'var(--muted)', boxShadow: mapTab==='history' ? 'var(--shadow)' : 'none' }}>📋 Donation History {myDonationHistory.length > 0 && <span style={{ background:'rgba(255,255,255,.3)', borderRadius:50, padding:'1px 7px', marginLeft:4, fontSize:'.75rem' }}>{myDonationHistory.length}</span>}</button>
          </div>
          {mapTab === 'banks' && (<>
          {!userCoords && (
            <div style={{ display:'flex', alignItems:'center', gap:10, background:'var(--cream)', borderRadius:12, padding:'10px 14px', marginBottom:14, fontSize:'.8rem', color:'var(--earth)', border:'1.5px solid rgba(196,113,74,.18)' }}>
              <span style={{ fontSize:'1.1rem' }}>📍</span>
              <span>Set your location in <strong>Settings</strong> to see real distances and centre the map on you.</span>
            </div>
          )}
          <GoogleMap
            height={300}
            markers={[...userMarker, ...allShelterMarkers, ...allStoreMarkers, ...allRestMarkers]}
            centerLat={userCoords ? userCoords.lat : undefined} centerLng={userCoords ? userCoords.lng : undefined}
          />
          {/* Map legend */}
          <div style={{ display:'flex', gap:12, flexWrap:'wrap', padding:'4px 2px 10px', fontSize:'.72rem', color:'var(--muted)' }}>
            {[['#e8a83e','You'],['#c4714a','Food Bank'],['#2a7fc1','Grocery'],['#27a98e','Restaurant']].map(([c,l]) => (
              <span key={l} style={{ display:'flex', alignItems:'center', gap:5 }}>
                <span style={{ width:9,height:9,borderRadius:'50%',background:c,display:'inline-block',flexShrink:0 }}></span>{l}
              </span>
            ))}
          </div>
          <div className="loc-controls">
            <span className="loc-count">{sortedShelters.length} food banks</span>
            <select className="custom-select" value={shelterSort} onChange={e => setShelterSort(e.target.value)}>
              <option value="closest">📍 Closest</option>
              <option value="need">🍽️ Most Food Needed</option>
              <option value="open">🟢 Open Now</option>
            </select>
          </div>
          <div className="card-list">
            {sortedShelters.map((s, i) => {
              const pct = Math.round(s.peopleNeeded / s.maxPeople * 100)
              const open = isOpenNow(s)
              return (
                <div key={i} className="loc-card">
                  <div className="loc-info">
                    <h3>{s.name} &nbsp;{open ? <span className="open-pill">● Open</span> : <span className="closed-pill">Closed</span>}</h3>
                    <p>{s.address}{s.distanceMi !== '—' ? ` — ${s.distanceMi} mi away` : ''}</p>
                    <p>{s.hours}</p>
                    <div className="people-row">
                      <span className="people-label">People needing food:</span>
                      <div className="people-bar-wrap"><div className={`people-bar ${s.needLevel}`} style={{ width: `${pct}%` }}></div></div>
                      <span className={`people-count ${s.needLevel}`}>{s.peopleNeeded.toLocaleString()} people</span>
                    </div>
                  </div>
                  <div className="loc-actions">
                    <span className="badge foodbank">Food Bank</span>
                    <a className="dir-btn" href={directionUrl(s.address)} target="_blank" rel="noreferrer">Directions ↗</a>
                  </div>
                </div>
              )
            })}
          </div>
          </>)}

          {mapTab === 'history' && (
            <div>
              {myDonationHistory.length === 0 ? (
                <div style={{ textAlign:'center', padding:'60px 20px', color:'var(--muted)' }}>
                  <div style={{ fontSize:'3rem', marginBottom:14 }}>🤝</div>
                  <div style={{ fontFamily:'Fraunces, serif', fontSize:'1.2rem', fontWeight:700, color:'var(--earth)', marginBottom:8 }}>No donations yet</div>
                  <div style={{ fontSize:'.88rem' }}>When you donate food to a local food bank, your history will appear here.</div>
                </div>
              ) : (
                <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
                  {[...myDonationHistory].reverse().map((d, i) => (
                    <div key={i} style={{ background:'var(--card-bg)', borderRadius:16, padding:'16px 18px', boxShadow:'var(--shadow)' }}>
                      <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', marginBottom:10 }}>
                        <div>
                          <div style={{ fontWeight:700, fontSize:'.95rem', color:'var(--earth)' }}>🏛️ {d.shelter}</div>
                          <div style={{ fontSize:'.78rem', color:'var(--muted)', marginTop:3 }}>📅 {d.date} &nbsp;·&nbsp; ⏰ {d.time}</div>
                        </div>
                        <span style={{ background:'#e8f5ea', color:'var(--sage)', borderRadius:50, padding:'3px 11px', fontSize:'.72rem', fontWeight:700, whiteSpace:'nowrap' }}>✅ Confirmed</span>
                      </div>
                      <div style={{ fontSize:'.78rem', fontWeight:700, color:'var(--muted)', textTransform:'uppercase', letterSpacing:'.06em', marginBottom:7 }}>Items Donated</div>
                      <div style={{ display:'flex', flexWrap:'wrap', gap:6 }}>
                        {d.items.map((item, j) => (
                          <span key={j} style={{ display:'flex', alignItems:'center', gap:5, background:'var(--bg)', borderRadius:50, padding:'4px 11px', fontSize:'.8rem', fontWeight:600 }}>
                            <span>{item.emoji}</span> {item.name} {item.qty > 1 && <span style={{ color:'var(--muted)', fontSize:'.72rem' }}>×{item.qty}</span>}
                          </span>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* ── NEARBY STORES ── */}
      {view === 'nearby' && (
        <div className="view active">
          <h1 className="view-title">Nearby Stores</h1>
          <p className="view-sub">Grocery stores and restaurants close to you.</p>
          {!userCoords && (
            <div style={{ display:'flex', alignItems:'center', gap:10, background:'var(--cream)', borderRadius:12, padding:'10px 14px', marginBottom:14, fontSize:'.8rem', color:'var(--earth)', border:'1.5px solid rgba(196,113,74,.18)' }}>
              <span style={{ fontSize:'1.1rem' }}>📍</span>
              <span>Set your location in <strong>Settings</strong> to see real distances and centre the map on you.</span>
            </div>
          )}
          <div className="nearby-sub-tabs">
            <button className={`nearby-sub-tab ${nearbyTab === 'grocery' ? 'active' : ''}`} onClick={() => setNearbyTab('grocery')}>🛒 Grocery Stores</button>
            <button className={`nearby-sub-tab ${nearbyTab === 'restaurant' ? 'active' : ''}`} onClick={() => setNearbyTab('restaurant')}>🍴 Restaurants</button>
          </div>
          <GoogleMap
            height={280}
            markers={[...userMarker, ...allStoreMarkers, ...allRestMarkers, ...allShelterMarkers]}
            centerLat={userCoords?.lat} centerLng={userCoords?.lng}
          />
          {/* Map legend */}
          <div style={{ display:'flex', gap:12, flexWrap:'wrap', padding:'4px 2px 10px', fontSize:'.72rem', color:'var(--muted)' }}>
            {[['#e8a83e','You'],['#2a7fc1','Grocery'],['#27a98e','Restaurant'],['#c4714a','Food Bank']].map(([c,l]) => (
              <span key={l} style={{ display:'flex', alignItems:'center', gap:5 }}>
                <span style={{ width:9,height:9,borderRadius:'50%',background:c,display:'inline-block',flexShrink:0 }}></span>{l}
              </span>
            ))}
          </div>
          <div className="loc-controls">
            <span className="loc-count">{nearbyList.length} {nearbyTab === 'grocery' ? 'grocery stores' : 'restaurants'} nearby</span>
            <select className="custom-select" value={nearbySort} onChange={e => setNearbySort(e.target.value)}>
              <option value="closest">📍 Closest</option>
              <option value="open">🟢 Open Now</option>
              <option value="rating">⭐ Best Rated</option>
            </select>
          </div>
          <div className="card-list">
            {nearbyList.map((s, i) => {
              const open = isOpenNow(s)
              return (
                <div key={i} className="loc-card">
                  <div className="loc-info">
                    <h3>{s.name} &nbsp;{open ? <span className="open-pill">● Open</span> : <span className="closed-pill">Closed</span>}</h3>
                    <p>{s.address}{s.distanceMi !== '—' ? ` — ${s.distanceMi} mi away` : ''}</p>
                    <p>{s.hours} &nbsp;·&nbsp; ⭐ {s.rating}</p>
                  </div>
                  <div className="loc-actions">
                    <span className={`badge ${nearbyTab === 'grocery' ? 'grocery' : 'restaurant'}`}>{nearbyTab === 'grocery' ? 'Grocery Store' : 'Restaurant'}</span>
                    <a className="dir-btn" href={directionUrl(s.address)} target="_blank" rel="noreferrer">Directions ↗</a>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      )}

      {/* ── SHOPPING LIST ── */}
      {view === 'recs' && (
        <div className="view active">
          <h1 className="view-title">Shopping List</h1>
          <p className="view-sub">What to grab — and what to skip — on your next trip.</p>
          <div className="sub-tabs">
            <button className={`sub-tab ${shoppingTab === 'buy' ? 'active' : ''}`} onClick={() => setShoppingTab('buy')}>🛒 Buy Next</button>
            <button className={`sub-tab avoid ${shoppingTab === 'avoid' ? 'active' : ''}`} onClick={() => setShoppingTab('avoid')}>🚫 Don't Buy</button>
          </div>

          {shoppingTab === 'buy' && (
            <div>
              <div className="rec-controls">
                <span className="rec-count">{filteredRecs.length} items</span>
                <select className="custom-select" value={recFilter} onChange={e => setRecFilter(e.target.value)}>
                  <option value="all">🍽️ All Categories</option>
                  <option value="carbs">🍞 Carbs &amp; Grains</option>
                  <option value="proteins">🥩 Proteins</option>
                  <option value="dairy">🥛 Dairy</option>
                  <option value="fruits">🍎 Fruits</option>
                  <option value="vegetables">🥦 Vegetables</option>
                  <option value="snacks">🍿 Snacks</option>
                  <option value="meals">🥘 Meal Ingredients</option>
                  <option value="beverages">☕ Beverages</option>
                  <option value="condiments">🧂 Condiments &amp; Spices</option>
                  <option value="frozen">❄️ Frozen Foods</option>
                  <option value="canned">🥫 Canned &amp; Packaged</option>
                  <option value="bakery">🥐 Bakery &amp; Bread</option>
                  <option value="legumes">🫘 Legumes &amp; Pulses</option>
                </select>
              </div>
              {filteredRecs.length === 0
                ? <p style={{ color: 'var(--muted)', fontStyle: 'italic' }}>Your pantry looks well-stocked! No recommendations right now. 🎉</p>
                : (
                  <div className="rec-grid">
                    {filteredRecs.map((r, i) => (
                      <div key={i} className={`rec-card ${r.source === 'consumed' ? 'consumed-rec' : r.source === 'plan' ? 'plan-rec' : ''}`}>
                        <span className={`rec-source-tag ${r.source === 'consumed' ? 'consumed' : r.source === 'plan' ? 'plan' : 'smart'}`}>
                          {r.source === 'consumed' ? '♻️ Buy Again' : r.source === 'plan' ? '🥗 Your Plan' : '💡 Suggested'}
                        </span>
                        <div className="food-emoji">{r.emoji}</div>
                        <div className="food-name">{r.name}</div>
                        <div className="rec-reason">{r.baseReason}</div>
                        <span className={`rec-priority ${r.priority}`}>{r.priority === 'high' ? '🔴 High Priority' : '🟡 Nice to Have'}</span>
                        <button className="add-to-pantry-btn" onClick={() => addFromRec(r.name, r.emoji, r.category || 'Other')}>+ Add to Pantry</button>
                        <button className="find-btn" onClick={() => setStoreModal({ name: r.name, emoji: r.emoji })}>🏪 Find at Store</button>
                        <button onClick={() => removeFromBuyNext(r.name)} style={{ marginTop:6, width:'100%', background:'none', border:'1.5px solid #e0d6cc', borderRadius:8, padding:'5px 0', fontSize:'.75rem', color:'var(--muted)', cursor:'pointer', fontWeight:600 }}>✕ Remove</button>
                      </div>
                    ))}
                  </div>
                )
              }
            </div>
          )}

          {shoppingTab === 'avoid' && (
            <div className="avoid-grid">
              {avoidList.map((a, i) => (
                <div key={i} className="avoid-card">
                  <div className="avoid-x">🚫</div>
                  <div className="food-emoji">{a.emoji}</div>
                  <div className="food-name">{a.name}</div>
                  <div className="avoid-reason">{a.reason}</div>
                  <span className={`avoid-badge ${a.badge}`}>{a.badgeLabel}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ── MODALS ── */}
      {/* Image Scan Modal */}
      {imageScanModal && (
        <div className="modal-overlay open" onClick={e => e.target === e.currentTarget && setImageScanModal(false)}>
          <div className="multi-add-modal" style={{ maxWidth: 560, maxHeight: '90vh', overflowY: 'auto' }}>
            <h2>📸 Scan Food with AI</h2>
            <p className="sub-note">Upload a photo of food, your fridge, or a grocery haul. Google Cloud Vision will identify every item.</p>

            {/* Upload area */}
            {!imageScanPreview && (
              <label style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10, padding: '36px 20px', border: '2px dashed rgba(61,46,30,.2)', borderRadius: 16, cursor: 'pointer', marginBottom: 16, background: 'var(--cream)', transition: 'border-color .2s' }}
                onDragOver={e => e.preventDefault()}
                onDrop={e => { e.preventDefault(); const f = e.dataTransfer.files[0]; if (f) handleImageScan(f) }}>
                <span style={{ fontSize: '3rem' }}>📷</span>
                <span style={{ fontWeight: 700, color: 'var(--earth)', fontSize: '.95rem' }}>Click to upload or drag & drop</span>
                <span style={{ fontSize: '.8rem', color: 'var(--muted)' }}>JPG, PNG, WEBP, HEIC supported</span>
                <input type="file" accept="image/*" style={{ display: 'none' }} onChange={e => { const f = e.target.files[0]; if (f) handleImageScan(f) }} />
              </label>
            )}

            {imageScanPreview && (
              <div style={{ marginBottom: 16 }}>
                <img src={imageScanPreview} alt="Preview" style={{ width: '100%', maxHeight: 220, objectFit: 'cover', borderRadius: 14, marginBottom: 12 }} />
                {!imageScanLoading && (
                  <label style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: '.82rem', fontWeight: 600, color: 'var(--clay)', cursor: 'pointer', padding: '6px 14px', border: '1.5px solid rgba(196,113,74,.3)', borderRadius: 8 }}>
                    🔄 Try a different photo
                    <input type="file" accept="image/*" style={{ display: 'none' }} onChange={e => { const f = e.target.files[0]; if (f) handleImageScan(f) }} />
                  </label>
                )}
              </div>
            )}

            {imageScanLoading && (
              <div style={{ textAlign: 'center', padding: '24px 0' }}>
                <div className="ai-loading"><div className="ai-loading-dots"><span></span><span></span><span></span></div></div>
                <p style={{ color: 'var(--muted)', marginTop: 12, fontSize: '.88rem' }}>Cloud Vision is scanning your food…</p>
              </div>
            )}

            {imageScanItems.length > 0 && !imageScanLoading && (
              <div style={{ display:'flex', alignItems:'center', gap:7, background:'rgba(232,168,62,.12)', border:'1.5px solid rgba(232,168,62,.3)', borderRadius:10, padding:'8px 13px', fontSize:'.75rem', color:'var(--earth)', marginBottom:10 }}>
                <span style={{ fontSize:'1rem', flexShrink:0 }}>⚠️</span>
                <span><strong>AI makes mistakes</strong> — please make sure the output is relevant to you.</span>
              </div>
            )}
            {imageScanItems.length > 0 && !imageScanLoading && (
              <div>
                <div style={{ fontWeight: 700, fontSize: '.82rem', textTransform: 'uppercase', letterSpacing: '.07em', color: 'var(--sage)', marginBottom: 10 }}>✅ {imageScanItems.length} items detected</div>
                <div style={{ maxHeight: 300, overflowY: 'auto' }}>
                  {imageScanItems.map((item, i) => (
                    <div key={i} className="multi-add-item-row">
                      <span style={{ fontSize: '1.5rem' }}>{item.emoji}</span>
                      <span style={{ flex: 1, fontWeight: 600, fontSize: '.88rem' }}>{item.name}</span>
                      <input type="number" min="1" value={item.qty} onChange={e => updateScanItem(i, 'qty', parseInt(e.target.value) || 1)} style={{ width: 52, fontSize: '.82rem', padding: '4px 6px', borderRadius: 6, border: '1.5px solid rgba(61,46,30,.18)', textAlign: 'center' }} />
                      <select value={item.category} onChange={e => updateScanItem(i, 'category', e.target.value)} style={{ fontSize: '.78rem', padding: '4px 8px', borderRadius: 6, border: '1.5px solid rgba(61,46,30,.18)' }}>
                        {['Grain','Protein','Dairy','Vegetable','Fruit','Snack','Beverage','Condiment','Other'].map(c => <option key={c} value={c}>{c}</option>)}
                      </select>
                      <button onClick={() => removeScanItem(i)} style={{ background: 'none', border: 'none', color: 'var(--muted)', cursor: 'pointer', fontSize: '1rem' }}>✕</button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="multi-bottom-row">
              <button className="multi-cancel-btn" onClick={() => { setImageScanModal(false); setImageScanPreview(null); setImageScanItems([]) }}>Cancel</button>
              <button className="multi-confirm-btn" onClick={confirmImageScanAdd} disabled={imageScanItems.length === 0}>
                Add {imageScanItems.length > 0 ? imageScanItems.length + ' items' : 'to'} Pantry ✓
              </button>
            </div>
          </div>
        </div>
      )}


      {/* ── Build Your Own Plan Modal ── */}
      {buildPlanModal && (
        <div className="modal-overlay open" onClick={e => e.target === e.currentTarget && setBuildPlanModal(false)}>
          <div className="custom-plan-modal">
            <h2>✨ Build Your AI Plan</h2>
            <p className="sub-note">Answer a few questions and Gemini will create a personalised weekly meal plan — complete with what to buy and avoid.</p>
            <div className="step-indicator">
              {[1,2,3,4,5].map(i => (
                <div key={i} className={`step-dot ${i < cpStep ? 'done' : i === cpStep ? 'active' : ''}`} />
              ))}
            </div>

            {/* Step 1: Goals */}
            {cpStep === 1 && (
              <div className="cp-step active">
                <div className="cp-section">
                  <div className="cp-section-title">What are your main goals? (pick all that apply)</div>
                  <div className="cp-chips">
                    {[['loseweight','🔻 Lose Weight'],['gainmuscle','💪 Gain Muscle'],['bulkup','🏋️ Bulk Up'],['heartHealth','❤️ Heart Health'],['energy','⚡ More Energy'],['guthealth','🌿 Gut Health'],['immunity','🛡️ Boost Immunity'],['recovery','🎗️ Recovery / Healing'],['pregnancy','🤰 Pregnancy Support'],['managediabetes','🩺 Manage Diabetes']].map(([val, label]) => (
                      <button key={val} className={`cp-chip${cpGoals.includes(val) ? ' selected' : ''}`} onClick={() => cpToggle(cpGoals, setCpGoals, val)}>{label}</button>
                    ))}
                  </div>
                </div>
                <div className="cp-btns">
                  <button className="cp-cancel" onClick={() => setBuildPlanModal(false)}>Cancel</button>
                  <button className="cp-confirm" onClick={() => setCpStep(2)}>Next →</button>
                </div>
              </div>
            )}

            {/* Step 2: Dietary restrictions */}
            {cpStep === 2 && (
              <div className="cp-step active">
                <div className="cp-section">
                  <div className="cp-section-title">Dietary restrictions</div>
                  <div className="cp-chips">
                    {[['vegetarian','🥦 Vegetarian'],['vegan','🌱 Vegan'],['glutenfree','🌾 Gluten-Free'],['dairyfree','🥛 Dairy-Free'],['lowcarb','🍞 Low-Carb'],['lowsodium','🧂 Low-Sodium'],['lowfat','🧈 Low-Fat'],['halal','☪️ Halal'],['kosher','✡️ Kosher'],['none','✅ No restrictions']].map(([val, label]) => (
                      <button key={val} className={`cp-chip${cpRestrictions.includes(val) ? ' selected' : ''}`} onClick={() => cpToggle(cpRestrictions, setCpRestrictions, val)}>{label}</button>
                    ))}
                  </div>
                </div>
                <div className="cp-btns">
                  <button className="cp-cancel" onClick={() => setCpStep(1)}>← Back</button>
                  <button className="cp-confirm" onClick={() => setCpStep(3)}>Next →</button>
                </div>
              </div>
            )}

            {/* Step 3: Allergies */}
            {cpStep === 3 && (
              <div className="cp-step active">
                <div className="cp-section">
                  <div className="cp-section-title">Allergies (pick all that apply)</div>
                  <div className="cp-chips">
                    {[['nuts','🥜 Tree Nuts'],['peanuts','🫙 Peanuts'],['shellfish','🦐 Shellfish'],['fish','🐟 Fish'],['eggs','🥚 Eggs'],['soy','🫘 Soy'],['dairy','🧀 Dairy'],['wheat','🍞 Wheat'],['none','✅ No allergies']].map(([val, label]) => (
                      <button key={val} className={`cp-chip${cpAllergies.includes(val) ? ' selected' : ''}`} onClick={() => cpToggle(cpAllergies, setCpAllergies, val)}>{label}</button>
                    ))}
                  </div>
                </div>
                <div className="cp-btns">
                  <button className="cp-cancel" onClick={() => setCpStep(2)}>← Back</button>
                  <button className="cp-confirm" onClick={() => setCpStep(4)}>Next →</button>
                </div>
              </div>
            )}

            {/* Step 4: Custom foods */}
            {cpStep === 4 && (
              <div className="cp-step active">
                <div className="cp-section">
                  <div className="cp-section-title">✅ Foods you want to include</div>
                  <div className="cp-food-input-row">
                    <input type="text" value={cpIncludeInput} onChange={e => setCpIncludeInput(e.target.value)} placeholder="e.g. Avocado, Oats, Salmon…" onKeyDown={e => e.key === 'Enter' && cpAddFood('include')} />
                    <button className="cp-add-include" onClick={() => cpAddFood('include')}>+ Add</button>
                  </div>
                  <div className="cp-food-tags">
                    {cpIncludeFoods.length === 0
                      ? <span className="cp-food-empty">No foods added yet</span>
                      : cpIncludeFoods.map(f => (
                          <span key={f} className="cp-food-tag include">✅ {f}<button onClick={() => setCpIncludeFoods(prev => prev.filter(x => x !== f))}>✕</button></span>
                        ))
                    }
                  </div>
                </div>
                <hr className="cp-divider" />
                <div className="cp-section">
                  <div className="cp-section-title">🚫 Foods you want to avoid</div>
                  <div className="cp-food-input-row">
                    <input type="text" value={cpExcludeInput} onChange={e => setCpExcludeInput(e.target.value)} placeholder="e.g. Dairy, Gluten, Shellfish…" onKeyDown={e => e.key === 'Enter' && cpAddFood('exclude')} />
                    <button className="cp-add-exclude" onClick={() => cpAddFood('exclude')}>+ Add</button>
                  </div>
                  <div className="cp-food-tags">
                    {cpExcludeFoods.length === 0
                      ? <span className="cp-food-empty">No foods added yet</span>
                      : cpExcludeFoods.map(f => (
                          <span key={f} className="cp-food-tag exclude">🚫 {f}<button onClick={() => setCpExcludeFoods(prev => prev.filter(x => x !== f))}>✕</button></span>
                        ))
                    }
                  </div>
                </div>
                <div className="cp-btns">
                  <button className="cp-cancel" onClick={() => setCpStep(3)}>← Back</button>
                  <button className="cp-confirm" onClick={() => setCpStep(5)}>Generate My AI Plan ✨</button>
                </div>
              </div>
            )}

            {/* Step 5: AI Plan Generation */}
            {cpStep === 5 && (
              <div className="cp-step active">
                <div className="cp-section">
                  <div className="cp-ai-label">✨ AI Meal Planner</div>
                  <div className="cp-section-title" style={{ fontSize: '.95rem', textTransform: 'none', letterSpacing: 0, marginBottom: 14 }}>Gemini will build a {cpDays}-day plan tailored to your goals</div>

                  {/* Day selector */}
                  <div style={{ marginBottom: 16 }}>
                    <div style={{ fontSize: '.72rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.06em', color: 'var(--muted)', marginBottom: 8 }}>How many days?</div>
                    <div style={{ display: 'flex', gap: 8 }}>
                      {[3, 5, 7].map(d => (
                        <button key={d} className={`cp-chip${cpDays === d ? ' selected' : ''}`} onClick={() => setCpDays(d)}>{d} days</button>
                      ))}
                    </div>
                  </div>

                  {/* Summary of their answers */}
                  {!cpAiResult && !cpAiLoading && (
                    <div style={{ background: 'var(--cream)', borderRadius: 10, padding: '12px 14px', fontSize: '.79rem', color: 'var(--earth)', marginBottom: 16, lineHeight: 1.6 }}>
                      {cpGoals.length > 0 && <div>🎯 <strong>Goals:</strong> {cpGoals.join(', ')}</div>}
                      {cpRestrictions.filter(r => r !== 'none').length > 0 && <div>🥗 <strong>Restrictions:</strong> {cpRestrictions.filter(r => r !== 'none').join(', ')}</div>}
                      {cpAllergies.filter(a => a !== 'none').length > 0 && <div>⚠️ <strong>Allergies:</strong> {cpAllergies.filter(a => a !== 'none').join(', ')}</div>}
                      {cpIncludeFoods.length > 0 && <div>✅ <strong>Include:</strong> {cpIncludeFoods.join(', ')}</div>}
                      {cpExcludeFoods.length > 0 && <div>🚫 <strong>Avoid:</strong> {cpExcludeFoods.join(', ')}</div>}
                    </div>
                  )}

                  {/* Loading */}
                  {cpAiLoading && (
                    <div style={{ textAlign: 'center', padding: '32px 0' }}>
                      <div className="ai-loading"><div className="ai-loading-dots"><span></span><span></span><span></span></div></div>
                      <p style={{ color: 'var(--muted)', marginTop: 14, fontSize: '.85rem' }}>Gemini is crafting your personalized {cpDays}-day plan…</p>
                    </div>
                  )}

                  {/* Result */}
                  {cpAiResult && !cpAiLoading && (
                    <div>
                      <div style={{ display:'flex', alignItems:'center', gap:7, background:'rgba(232,168,62,.12)', border:'1.5px solid rgba(232,168,62,.3)', borderRadius:10, padding:'8px 13px', fontSize:'.75rem', color:'var(--earth)', marginBottom:12 }}>
                        <span style={{ fontSize:'1rem', flexShrink:0 }}>⚠️</span>
                        <span><strong>AI makes mistakes</strong> — please make sure the output is relevant to you.</span>
                      </div>
                      <div style={{ background: 'linear-gradient(135deg,var(--earth),var(--clay))', borderRadius: 12, padding: '14px 16px', color: 'white', marginBottom: 14, display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 8 }}>
                        <div>
                          <div style={{ fontFamily: 'Fraunces,serif', fontSize: '1.1rem', fontWeight: 700 }}>{cpAiResult.planName}</div>
                          {cpAiResult.tips && <div style={{ fontSize: '.75rem', opacity: .75, marginTop: 3 }}>💡 {cpAiResult.tips}</div>}
                        </div>
                        <div style={{ textAlign: 'center' }}>
                          <div style={{ fontFamily: 'Fraunces,serif', fontSize: '1.4rem', fontWeight: 900 }}>{cpAiResult.weeklyCalories || '~2100'}</div>
                          <div style={{ fontSize: '.62rem', opacity: .65 }}>kcal/week</div>
                        </div>
                      </div>

                      {/* Day tabs */}
                      <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 12 }}>
                        {(cpAiResult.days || []).map((d, i) => (
                          <button key={i} onClick={() => setCpAiDay(i)} style={{ padding: '6px 13px', borderRadius: 50, border: 'none', background: cpAiDay === i ? 'var(--clay)' : 'var(--cream)', color: cpAiDay === i ? 'white' : 'var(--earth)', fontWeight: 600, fontSize: '.76rem', cursor: 'pointer', transition: 'all .18s' }}>
                            {d.day}
                          </button>
                        ))}
                      </div>

                      {/* Meals for selected day */}
                      {cpAiResult.days?.[cpAiDay] && (
                        <div style={{ display: 'grid', gap: 8, marginBottom: 12 }}>
                          {(cpAiResult.days[cpAiDay].meals || []).map((meal, i) => (
                            <div key={i} style={{ background: 'var(--cream)', borderRadius: 10, padding: '10px 12px', display: 'flex', gap: 10, alignItems: 'flex-start' }}>
                              <span style={{ fontSize: '1.4rem', flexShrink: 0 }}>{mealEmoji(meal)}</span>
                              <div style={{ flex: 1 }}>
                                <div style={{ fontSize: '.72rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.05em', color: 'var(--clay)', marginBottom: 2 }}>{meal.type}</div>
                                <div style={{ fontWeight: 700, fontSize: '.86rem', color: 'var(--earth)' }}>{meal.name}</div>
                                <div style={{ fontSize: '.72rem', color: 'var(--muted)', marginTop: 2 }}>{(meal.ingredients || []).join(', ')}</div>
                              </div>
                              <div style={{ textAlign: 'right', flexShrink: 0 }}>
                                <div style={{ fontSize: '.76rem', fontWeight: 700, color: 'var(--sage)' }}>{meal.calories} kcal</div>
                                <div style={{ fontSize: '.68rem', color: 'var(--muted)' }}>⏱ {meal.time}</div>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}

                      {/* Buy + Avoid preview */}
                      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginTop: 4 }}>
                        {(cpAiResult.buyList || []).length > 0 && (
                          <div style={{ background: '#e8f5ea', borderRadius: 10, padding: '10px 12px', fontSize: '.77rem' }}>
                            <div style={{ fontWeight: 700, color: 'var(--sage)', marginBottom: 6 }}>🛒 Buy ({cpAiResult.buyList.length})</div>
                            {cpAiResult.buyList.slice(0, 5).map((item, i) => (
                              <div key={i} style={{ display: 'flex', gap: 5, alignItems: 'center', marginBottom: 3 }}>
                                <span>{item.emoji}</span>
                                <span style={{ color: 'var(--earth)', fontWeight: 500 }}>{item.name}</span>
                              </div>
                            ))}
                            {cpAiResult.buyList.length > 5 && <div style={{ color: 'var(--muted)', marginTop: 2 }}>+{cpAiResult.buyList.length - 5} more…</div>}
                          </div>
                        )}
                        {(cpAiResult.avoidList || []).length > 0 && (
                          <div style={{ background: '#fde8dc', borderRadius: 10, padding: '10px 12px', fontSize: '.77rem' }}>
                            <div style={{ fontWeight: 700, color: 'var(--clay)', marginBottom: 6 }}>🚫 Avoid ({cpAiResult.avoidList.length})</div>
                            {cpAiResult.avoidList.slice(0, 5).map((item, i) => (
                              <div key={i} style={{ display: 'flex', gap: 5, alignItems: 'center', marginBottom: 3 }}>
                                <span>{item.emoji}</span>
                                <span style={{ color: 'var(--earth)', fontWeight: 500 }}>{item.name}</span>
                              </div>
                            ))}
                            {cpAiResult.avoidList.length > 5 && <div style={{ color: 'var(--muted)', marginTop: 2 }}>+{cpAiResult.avoidList.length - 5} more…</div>}
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Generate button */}
                  {!cpAiResult && !cpAiLoading && (
                    <button
                      className="ai-gen-btn"
                      onClick={cpGenerateAIPlan}
                      style={{ marginTop: 8 }}
                    >
                      ✨ Generate My {cpDays}-Day Plan
                    </button>
                  )}
                  {cpAiResult && !cpAiLoading && (
                    <button
                      className="ai-gen-btn"
                      onClick={cpGenerateAIPlan}
                      style={{ marginTop: 8, opacity: .75 }}
                    >
                      🔄 Regenerate
                    </button>
                  )}
                </div>

                <div className="cp-btns" style={{ marginTop: 10 }}>
                  <button className="cp-cancel" onClick={() => setCpStep(4)}>← Back</button>
                  {cpAiResult
                    ? <button className="cp-confirm" onClick={cpApplyAndGoToMeals}>Apply & View Plan ✓</button>
                    : <button className="cp-cancel" onClick={() => setBuildPlanModal(false)}>Cancel</button>
                  }
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Add Food Modal */}
      {addModal && (
        <div className="modal-overlay open" onClick={e => e.target === e.currentTarget && setAddModal(false)}>
          <div className="multi-add-modal">
            <h2>🧺 Add Foods to Pantry</h2>
            <p className="sub-note">Type a food name and press Enter. Add as many as you like.</p>
            <div className="multi-add-input-row">
              <input type="text" value={addInput} onChange={e => setAddInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && addMultiItem()} placeholder="e.g. Chicken Breast, Eggs, Oats…" />
              <button onClick={addMultiItem}>+ Add</button>
            </div>
            <div style={{ marginTop: 14, maxHeight: 320, overflowY: 'auto' }}>
              {addItems.map((item, i) => (
                <div key={i} className="multi-add-item-row">
                  <span style={{ fontSize: '1.5rem' }}>{item.emoji}</span>
                  <span style={{ flex: 1, fontWeight: 600, fontSize: '.88rem' }}>{item.name}</span>
                  <select value={item.category} onChange={e => updateAddItemField(i, 'category', e.target.value)} style={{ fontSize: '.78rem', padding: '4px 8px', borderRadius: 6, border: '1.5px solid rgba(61,46,30,.18)' }}>
                    {['Grain','Protein','Dairy','Vegetable','Fruit','Snack','Beverage','Condiment','Other'].map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                  <button onClick={() => removeAddItem(i)} style={{ background: 'none', border: 'none', color: 'var(--muted)', cursor: 'pointer', fontSize: '1rem' }}>✕</button>
                </div>
              ))}
            </div>
            <div className="multi-bottom-row">
              <button className="multi-cancel-btn" onClick={() => setAddModal(false)}>Cancel</button>
              <button className="multi-confirm-btn" onClick={confirmMultiAdd} disabled={addItems.length === 0}>Add to Pantry ✓</button>
            </div>
          </div>
        </div>
      )}

      {/* Reason Modal */}
      {reasonModal && (
        <div className="modal-overlay open" onClick={e => e.target === e.currentTarget && setReasonModal(null)}>
          <div className="reason-modal">
            <div className="item-preview">{reasonModal.emoji}</div>
            <h2>Why did <span>{reasonModal.name}</span> run out?</h2>
            <p>Your answer shapes your shopping recommendations.</p>
            <div className="reason-choices">
              <button className="reason-btn consumed" onClick={() => confirmRemoval('consumed')}>
                <span className="r-icon">🍽️</span>
                <span><span className="r-label">Used / Consumed</span><span className="r-sub">Ate it all → suggest buying again</span></span>
              </button>
              <button className="reason-btn expired" onClick={() => confirmRemoval('expired')}>
                <span className="r-icon">🗑️</span>
                <span><span className="r-label">Expired / Thrown Out</span><span className="r-sub">Had to discard → move to Don't Buy</span></span>
              </button>
              <button className="reason-btn donated" onClick={() => confirmRemoval('donated')}>
                <span className="r-icon">🤝</span>
                <span><span className="r-label">Donated</span><span className="r-sub">Gave it away → no recommendation</span></span>
              </button>
            </div>
            <button className="reason-skip" onClick={() => confirmRemoval(null)}>Skip</button>
          </div>
        </div>
      )}

      {/* Swipe Sort Modal */}
      {swipeModal && (
        <div className="modal-overlay open" onClick={e => e.target === e.currentTarget && setSwipeModal(false)}>
          <div className="swipe-modal-wrap">
            {swipeDone ? (
              <div className="swipe-done-wrap">
                <div style={{ fontSize: '2.5rem', marginBottom: 10 }}>✅</div>
                <h3>All sorted!</h3>
                <p>✅ Will Finish: <strong>{swipeWillFinish.length}</strong> items<br />
                  ⚠️ May Not Finish: <strong>{swipeMayNot.length}</strong> items</p>
                <p style={{ marginTop: 8, fontSize: '.82rem', color: 'var(--muted)' }}>✨ Getting AI recommendations…</p>
                <div className="ai-loading"><div className="ai-loading-dots"><span></span><span></span><span></span></div></div>
              </div>
            ) : (
              <>
                <div className="swipe-progress">Item {Math.min(swipeIndex + 1, swipeQueue.length)} of {swipeQueue.length}</div>
                {swipeQueue[swipeIndex] && (
                  <div className="swipe-card-stack">
                    <div className="swipe-card peek"><div className="swipe-emoji">🍽️</div></div>
                    <div
                      ref={swipeCardRef}
                      className={`swipe-card front${swipeAnimating === 'left' ? ' exit-left' : swipeAnimating === 'right' ? ' exit-right' : ''}`}
                      style={swipeAnimating ? {} : {
                        transform: `translateX(${swipeDragX}px) rotate(${swipeDragX * 0.08}deg)`,
                        transition: swipeDragging ? 'none' : 'transform 0.3s ease',
                        cursor: 'grab',
                        userSelect: 'none',
                        borderColor: swipeDragX > 60 ? '#4caf50' : swipeDragX < -60 ? '#f44336' : undefined,
                        boxShadow: swipeDragX > 60 ? '0 0 20px rgba(76,175,80,0.4)' : swipeDragX < -60 ? '0 0 20px rgba(244,67,54,0.4)' : undefined,
                      }}
                      onMouseDown={e => onDragStart(e.clientX)}
                      onMouseMove={e => onDragMove(e.clientX)}
                      onMouseUp={onDragEnd}
                      onMouseLeave={onDragEnd}
                      onTouchStart={e => onDragStart(e.touches[0].clientX)}
                      onTouchMove={e => { e.preventDefault(); onDragMove(e.touches[0].clientX) }}
                      onTouchEnd={onDragEnd}
                    >
                      {swipeDragX > 60 && <div style={{position:'absolute',top:16,left:16,fontSize:'1.4rem',fontWeight:700,color:'#4caf50',opacity:Math.min((swipeDragX-60)/60,1)}}>✓ KEEP</div>}
                      {swipeDragX < -60 && <div style={{position:'absolute',top:16,right:16,fontSize:'1.4rem',fontWeight:700,color:'#f44336',opacity:Math.min((-swipeDragX-60)/60,1)}}>✗ DONATE</div>}
                      <div className="swipe-emoji">{swipeQueue[swipeIndex]?.emoji}</div>
                      <div className="swipe-name">{swipeQueue[swipeIndex]?.name}</div>
                      <div className="swipe-meta">{swipeQueue[swipeIndex]?.category} · Qty {swipeQueue[swipeIndex]?.qty}</div>
                    </div>
                  </div>
                )}
                <div className="swipe-hint">← Donate &nbsp;|&nbsp; Keep →</div>
                <div className="swipe-actions">
                  <button className="swipe-btn left" onClick={() => swipeCard('left')} title="May Not Finish">✗</button>
                  <button className="swipe-btn right" onClick={() => swipeCard('right')} title="Will Finish">✓</button>
                </div>
                <div className="swipe-labels">
                  <span className="swipe-label-left">✗ May Not Finish</span>
                  <span className="swipe-label-right">Will Finish ✓</span>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* AI Result Modal */}
      {aiResultModal && (
        <div className="modal-overlay open" onClick={e => e.target === e.currentTarget && setAiResultModal(false)}>
          <div className="ai-result-modal">
            <h2>🤖 AI Recommendations</h2>
            <p className="sub-note" style={{ fontSize: '.81rem', color: 'var(--muted)', marginBottom: 16 }}>Based on how you sorted your pantry:</p>
            {aiLoading ? (
              <div className="ai-loading"><div className="ai-loading-dots"><span></span><span></span><span></span></div><span style={{ fontSize: '.84rem', color: 'var(--muted)' }}>AI is analysing…</span></div>
            ) : aiResult && (
              <>
                <div style={{ display:'flex', alignItems:'center', gap:7, background:'rgba(232,168,62,.12)', border:'1.5px solid rgba(232,168,62,.3)', borderRadius:10, padding:'8px 13px', fontSize:'.75rem', color:'var(--earth)', marginBottom:14 }}>
                  <span style={{ fontSize:'1rem', flexShrink:0 }}>⚠️</span>
                  <span><strong>AI makes mistakes</strong> — please make sure the output is relevant to you.</span>
                </div>
                {aiResult.donate?.length > 0 && (
                  <div className="ai-result-section">
                    <div className="ai-result-section-title">🤝 Suggest Donating ({aiResult.donate.length} items)</div>
                    {aiResult.donate.map((f, i) => (
                      <div key={i} className="ai-food-item donate">
                        <span style={{ fontSize: '1.4rem' }}>{f.emoji}</span>
                        <div><div style={{ fontWeight: 600, fontSize: '.86rem' }}>{f.name}</div><div className="ai-food-reason">{f.reason}</div></div>
                      </div>
                    ))}
                    <button style={{ marginTop: 8, width: '100%', padding: 10, borderRadius: 10, border: 'none', background: 'var(--sage)', color: 'white', fontFamily: '"DM Sans",sans-serif', fontSize: '.85rem', fontWeight: 600, cursor: 'pointer' }} onClick={openDonateFromAI}>🤝 Donate These Items →</button>
                  </div>
                )}
                {aiResult.buyNext?.length > 0 && (
                  <div className="ai-result-section">
                    <div className="ai-result-section-title">🛒 Buy Next When Empty ({aiResult.buyNext.length} items)</div>
                    {aiResult.buyNext.map((f, i) => (
                      <div key={i} className="ai-food-item buy">
                        <span style={{ fontSize: '1.4rem' }}>{f.emoji}</span>
                        <div><div style={{ fontWeight: 600, fontSize: '.86rem' }}>{f.name}</div><div className="ai-food-reason">{f.reason}</div></div>
                      </div>
                    ))}
                  </div>
                )}
              </>
            )}
            <button className="modal-close" onClick={() => setAiResultModal(false)} style={{ marginTop: 4 }}>Close</button>
          </div>
        </div>
      )}

      {/* Donate Modal */}
      {donateModal && (
        <div className="modal-overlay open" onClick={e => e.target === e.currentTarget && setDonateModal(false)}>
          <div className="donate-shelter-modal">
            <h2>🤝 Donate Food</h2>
            <p className="sub-note" style={{ fontSize: '.81rem', color: 'var(--muted)', marginBottom: 14 }}>Choose a food bank, then pick a drop-off time.</p>
            <div style={{ fontSize: '.77rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.06em', color: 'var(--muted)', marginBottom: 8 }}>Items to Donate</div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 16 }}>
              {donateItems.map((f, i) => <div key={i} className="don-item-tag"><span>{f.emoji}</span>{f.name}</div>)}
            </div>
            <div style={{ fontSize: '.77rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.06em', color: 'var(--muted)', marginBottom: 8 }}>Select Food Bank</div>
            {shelters.map((s, i) => (
              <div key={i} className={`shelter-option ${selectedShelter?.name === s.name ? 'selected' : ''}`} onClick={() => { setSelectedShelter(s); setSelectedTimeSlot(null) }}>
                <div>
                  <div className="sh-name">{s.name}</div>
                  <div className="sh-dist">{s.address} · {s.distanceMi} mi</div>
                </div>
                <span className="badge foodbank">Food Bank</span>
              </div>
            ))}
            {selectedShelter && (
              <div style={{ display: 'block', marginTop: 12 }}>
                <div style={{ fontSize: '.77rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.06em', color: 'var(--muted)', marginBottom: 8 }}>Choose Drop-Off Time</div>
                <div className="time-slot-grid">
                  {DROP_TIMES.map(t => (
                    <div key={t} className={`time-slot ${selectedTimeSlot === t ? 'selected' : ''}`} onClick={() => setSelectedTimeSlot(t)}>{t}</div>
                  ))}
                </div>
              </div>
            )}
            <button
              className="donate-confirm-btn"
              onClick={confirmDonation}
              disabled={!selectedShelter || !selectedTimeSlot}
              style={{ opacity: (!selectedShelter || !selectedTimeSlot) ? .4 : 1, cursor: (!selectedShelter || !selectedTimeSlot) ? 'not-allowed' : 'pointer' }}
            >Confirm Donation →</button>
            <button className="donate-cancel-btn" onClick={() => setDonateModal(false)}>Cancel</button>
          </div>
        </div>
      )}

      {/* Store Lookup Modal */}
      {storeModal && (
        <div className="modal-overlay open" onClick={e => e.target === e.currentTarget && setStoreModal(null)}>
          <div className="store-modal">
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 6 }}>
              <span style={{ fontSize: '1.9rem' }}>{storeModal.emoji}</span>
              <div>
                <h2 style={{ fontFamily: '"Fraunces",serif', fontSize: '1.2rem', marginBottom: 0 }}>{storeModal.name}</h2>
                <p className="store-sub-note">Stores carrying this item nearby</p>
              </div>
            </div>
            {storeCarrying.length === 0
              ? <p className="no-stores">No nearby stores currently carry <strong>{storeModal.name}</strong>.</p>
              : storeCarrying.map((s, i) => (
                <div key={i} className="store-result">
                  <div><div className="sr-name">{s.name} &nbsp;{isOpenNow(s) ? <span className="open-pill">● Open</span> : <span className="closed-pill">Closed</span>}</div><div className="sr-dist">{s.distanceMi} mi · {s.address}</div></div>
                  <button className="go-btn" onClick={() => { setStoreModal(null); setView('nearby'); setNearbyTab('grocery') }}>View Store →</button>
                </div>
              ))
            }
            <button className="modal-close" onClick={() => setStoreModal(null)}>Close</button>
          </div>
        </div>
      )}

      {/* ── SETTINGS ── */}
      {/* ── AI MEAL PLAN ── */}
      {view === 'meals' && (
        <div className="view active">
          <h1 className="view-title">🧠 AI Meal Plan</h1>
          <p className="view-sub">Gemini generates a personalized weekly meal plan based on your pantry and goals.</p>
          {activePlan === 'custom' && mealPlans.custom && (
            <div style={{ display:'flex', alignItems:'center', gap:10, background:'#e8f5ea', borderRadius:12, padding:'11px 15px', marginBottom:16, border:'1.5px solid rgba(39,169,142,.25)' }}>
              <span style={{ fontSize:'1.2rem' }}>✨</span>
              <div style={{ flex:1 }}>
                <div style={{ fontSize:'.83rem', fontWeight:700, color:'var(--sage)' }}>{mealPlans.custom.name} is active</div>
                <div style={{ fontSize:'.75rem', color:'var(--muted)', marginTop:1 }}>Your Shopping List is already updated with {mealPlans.custom.buy?.length || 0} items to buy and {mealPlans.custom.avoid?.length || 0} to avoid.</div>
              </div>
              <button onClick={openBuildPlanModal} style={{ background:'none', border:'1.5px solid var(--sage)', borderRadius:50, color:'var(--sage)', fontSize:'.75rem', fontWeight:700, padding:'5px 12px', cursor:'pointer', whiteSpace:'nowrap' }}>Rebuild →</button>
            </div>
          )}
          <div style={{ background: 'var(--card-bg)', borderRadius: 18, padding: '24px', boxShadow: 'var(--shadow)', marginBottom: 22 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 14, flexWrap: 'wrap', marginBottom: 16 }}>
              <div style={{ flex: 1, minWidth: 200 }}>
                <div style={{ fontSize: '.77rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.07em', color: 'var(--muted)', marginBottom: 6 }}>Active Diet Plan</div>
                <select className="custom-select" value={activePlan} onChange={e => setActivePlan(e.target.value)} style={{ width: '100%' }}>
                  {planOptions.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
                </select>
              </div>
              <div style={{ flex: 2, minWidth: 240 }}>
                <div style={{ fontSize: '.77rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.07em', color: 'var(--muted)', marginBottom: 6 }}>Additional Preferences (optional)</div>
                <input className="search-input" type="text" value={aiMealPlanPrefs} onChange={e => setAiMealPlanPrefs(e.target.value)} placeholder="e.g. No shellfish, quick meals under 20 min, budget-friendly…" style={{ width: '100%' }} />
              </div>
            </div>
            <button className="add-btn" style={{ background: 'linear-gradient(135deg, var(--earth), var(--clay))', color: 'white', padding: '13px 28px', fontSize: '.95rem', width: '100%', justifyContent: 'center' }} onClick={generateAIMealPlan} disabled={aiMealPlanLoading}>
              {aiMealPlanLoading ? '⏳ Generating your 7-day plan…' : '🧠 Generate My Meal Plan'}
            </button>
          </div>

          {aiMealPlanLoading && (
            <div style={{ textAlign: 'center', padding: '60px 20px' }}>
              <div className="ai-loading"><div className="ai-loading-dots"><span></span><span></span><span></span></div></div>
              <p style={{ color: 'var(--muted)', marginTop: 16, fontSize: '.9rem' }}>Gemini is crafting personalized meals using your pantry items…</p>
            </div>
          )}

          {aiMealPlanResult && !aiMealPlanLoading && (
            <div>
              {/* Plan header */}
              <div style={{ background: 'linear-gradient(135deg, var(--earth), var(--clay))', borderRadius: 18, padding: '22px 26px', marginBottom: 22, color: 'white', display: 'flex', gap: 20, alignItems: 'center', flexWrap: 'wrap' }}>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: '.72rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.1em', opacity: .7, marginBottom: 4 }}>Your AI Plan</div>
                  <div style={{ fontFamily: 'Fraunces, serif', fontSize: '1.4rem', fontWeight: 700 }}>{aiMealPlanResult.planName || activePlan}</div>
                  {aiMealPlanResult.tips && <div style={{ fontSize: '.83rem', opacity: .75, marginTop: 6 }}>💡 {aiMealPlanResult.tips}</div>}
                </div>
                <div style={{ textAlign: 'center', background: 'rgba(255,255,255,.12)', borderRadius: 12, padding: '12px 20px' }}>
                  <div style={{ fontFamily: 'Fraunces, serif', fontSize: '1.6rem', fontWeight: 900 }}>{aiMealPlanResult.weeklyCalories || '~2100'}</div>
                  <div style={{ fontSize: '.68rem', opacity: .65 }}>cal/day avg</div>
                </div>
              </div>

              {/* Disclaimer + Delete */}
              <div style={{ display:'flex', alignItems:'center', gap:7, background:'rgba(232,168,62,.12)', border:'1.5px solid rgba(232,168,62,.3)', borderRadius:10, padding:'8px 13px', fontSize:'.75rem', color:'var(--earth)', margin:'0 0 14px 0' }}>
                  <span style={{ fontSize:'1rem', flexShrink:0 }}>⚠️</span>
                  <span><strong>AI makes mistakes</strong> — please make sure the output is relevant to you.</span>
                </div>
              <div style={{ display:'flex', justifyContent:'flex-end', marginBottom:12 }}>
                <button onClick={() => { setAiMealPlanResult(null); setAiMealPlanDay(0); saveUserData({ aiMealPlanResult: null, aiMealPlanDay: 0 }) }}
                  style={{ background:'rgba(200,50,50,.08)', border:'1.5px solid rgba(200,50,50,.2)', borderRadius:50, padding:'6px 16px', color:'#b03030', fontFamily:"'DM Sans',sans-serif", fontSize:'.78rem', fontWeight:700, cursor:'pointer', display:'flex', alignItems:'center', gap:6 }}>
                  🗑️ Delete Plan
                </button>
              </div>

              {/* Day tabs */}
              <div style={{ display: 'flex', gap: 8, marginBottom: 18, flexWrap: 'wrap' }}>
                {(aiMealPlanResult.days || []).map((d, i) => (
                  <button key={i} onClick={() => setAiMealPlanDay(i)} style={{ padding: '8px 16px', borderRadius: 50, border: 'none', background: aiMealPlanDay === i ? 'var(--clay)' : 'var(--card-bg)', color: aiMealPlanDay === i ? 'white' : 'var(--earth)', fontWeight: 600, fontSize: '.82rem', cursor: 'pointer', boxShadow: aiMealPlanDay === i ? '0 2px 12px rgba(196,113,74,.35)' : 'var(--shadow)', transition: 'all .2s' }}>
                    {d.day}
                  </button>
                ))}
              </div>

              {/* Day meals */}
              {aiMealPlanResult.days?.[aiMealPlanDay] && (
                <div style={{ display: 'grid', gap: 14 }}>
                  {(aiMealPlanResult.days[aiMealPlanDay].meals || []).map((meal, i) => (
                    <div key={i} style={{ background: 'var(--card-bg)', borderRadius: 16, padding: '20px 22px', boxShadow: 'var(--shadow)', display: 'flex', gap: 16, alignItems: 'flex-start', flexWrap: 'wrap' }}>
                      <div style={{ fontSize: '2rem', width: 48, height: 48, background: 'var(--cream)', borderRadius: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>{mealEmoji(meal)}</div>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: '.68rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.08em', color: 'var(--clay)', marginBottom: 3 }}>{meal.type}</div>
                        <div style={{ fontWeight: 700, fontSize: '1rem', color: 'var(--earth)', marginBottom: 6 }}>{meal.name}</div>
                        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginBottom: 8 }}>
                          {meal.calories && <span style={{ fontSize: '.72rem', background: 'var(--cream)', color: 'var(--muted)', padding: '2px 10px', borderRadius: 50, fontWeight: 600 }}>🔥 {meal.calories} cal</span>}
                          {meal.time && <span style={{ fontSize: '.72rem', background: 'var(--cream)', color: 'var(--muted)', padding: '2px 10px', borderRadius: 50, fontWeight: 600 }}>⏱️ {meal.time}</span>}
                        </div>
                        {meal.ingredients?.length > 0 && (
                          <div style={{ fontSize: '.79rem', color: 'var(--muted)' }}>
                            <strong>Ingredients:</strong> {meal.ingredients.join(', ')}
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Shopping list — confirm before adding */}
              {aiMealPlanResult.shoppingList?.length > 0 && (
                <div style={{ background: 'var(--card-bg)', borderRadius: 16, padding: '20px 22px', boxShadow: 'var(--shadow)', marginTop: 18 }}>
                  <div style={{ fontWeight: 700, fontSize: '.9rem', color: 'var(--earth)', marginBottom: 4 }}>🛒 Missing Ingredients</div>
                  <div style={{ fontSize: '.8rem', color: 'var(--muted)', marginBottom: 14 }}>Gemini summarized {aiMealPlanResult.shoppingList.length} items you'll need. Add them to your Buy Next list?</div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 16 }}>
                    {aiMealPlanResult.shoppingList.map((item, i) => {
                      const name = typeof item === 'object' ? item.name : item
                      const emoji = typeof item === 'object' ? item.emoji : '🛒'
                      const reason = typeof item === 'object' ? item.reason : ''
                      return (
                        <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, background: 'var(--bg)', borderRadius: 10, padding: '9px 13px' }}>
                          <span style={{ fontSize: '1.2rem' }}>{emoji}</span>
                          <div style={{ flex: 1 }}>
                            <div style={{ fontWeight: 600, fontSize: '.85rem' }}>{name}</div>
                            {reason && <div style={{ fontSize: '.75rem', color: 'var(--muted)', marginTop: 2 }}>{reason}</div>}
                          </div>
                        </div>
                      )
                    })}
                  </div>
                  {!shoppingConfirm ? (
                    <div style={{ display: 'flex', gap: 10 }}>
                      <button className="add-btn" style={{ flex: 1, justifyContent: 'center', background: 'linear-gradient(135deg, var(--earth), var(--clay))', color: 'white', padding: '11px 0' }}
                        onClick={() => {
                          const items = aiMealPlanResult.shoppingList.map(item => ({
                            name: typeof item === 'object' ? item.name : item,
                            emoji: typeof item === 'object' ? item.emoji : guessEmoji(item),
                            reason: typeof item === 'object' ? item.reason : 'Recommended by your AI meal plan.',
                            priority: 'high', foodGroup: 'meals', source: 'plan'
                          }))
                          const newPlans = { ...mealPlans, [activePlan]: { ...(mealPlans[activePlan] || {}), buy: [...(mealPlans[activePlan]?.buy || []), ...items] } }
                          saveMealPlans(newPlans)
                          setShoppingConfirm(true)
                          showToast('✅ Added to your Buy Next list!')
                        }}>
                        ✅ Yes, add to Buy Next
                      </button>
                      <button className="add-btn" style={{ flex: 1, justifyContent: 'center', background: 'var(--bg)', color: 'var(--muted)', padding: '11px 0', border: '1.5px solid var(--border)' }}
                        onClick={() => setShoppingConfirm(true)}>
                        ✕ Skip
                      </button>
                    </div>
                  ) : (
                    <div style={{ textAlign: 'center', fontSize: '.85rem', color: 'var(--sage)', fontWeight: 600, padding: '8px 0' }}>
                      ✅ Done — check your Buy Next list in Shopping
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {!aiMealPlanResult && !aiMealPlanLoading && (
            <div style={{ textAlign: 'center', padding: '60px 20px', color: 'var(--muted)' }}>
              <div style={{ fontSize: '3rem', marginBottom: 14 }}>🧠</div>
              <div style={{ fontFamily: 'Fraunces, serif', fontSize: '1.3rem', fontWeight: 700, color: 'var(--earth)', marginBottom: 8 }}>Your AI chef is ready</div>
              <div style={{ fontSize: '.88rem', maxWidth: 340, margin: '0 auto' }}>Select a diet plan above and click Generate. Gemini will create a personalized 7-day meal plan using your current pantry.</div>
            </div>
          )}
        </div>
      )}

      {/* ── AI STORE SUGGESTIONS ── */}

      {view === 'settings' && (
        <div className="view active" style={{ padding: '20px 22px' }}>
          <SettingsPanel
            theme={theme}
            onThemeChange={onThemeChange}
            user={user}
            onLogout={onLogout}
            onClearData={() => {
              if (!window.confirm('Clear all pantry items? This cannot be undone.')) return
              saveUserData({ pantry: [], nextId: 1, historyBuyList: [], historyAvoidList: [] })
              setDietConflicts({})
              showToast('🗑️ Pantry cleared')
            }}
            onExportData={() => {
              const data = { pantry, activePlan, historyBuyList, historyAvoidList, exportedAt: new Date().toISOString() }
              const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
              const url = URL.createObjectURL(blob)
              const a = document.createElement('a'); a.href = url; a.download = 'together-table-data.json'; a.click()
              URL.revokeObjectURL(url)
              showToast('📤 Data exported!')
            }}
            locationSection={
              <LocationSettingsRow
                label="Your Home Location"
                sub="Pin yourself on the Food Banks and Nearby Stores maps"
                address={userAddress}
                loading={userLocLoading}
                error={userLocError}
                input={userLocInput}
                setInput={setUserLocInput}
                onSubmit={applyUserLocation}
                onGPS={useGPS}
                onClear={() => { setUserAddress(''); setUserCoords(null); localStorage.removeItem('tt_user_loc_' + user.username) }}
              />
            }
          />
        </div>
      )}

      {toast && <Toast msg={toast} />}
    </div>
  )
}

// ─────────────────────────────────────────────
// FOODBANK APP
// ─────────────────────────────────────────────
function FoodbankApp({ user, onLogout, incomingDonations, shelters, setShelters, theme, onThemeChange, onClearDonations }) {
  const storageKey = `tt_fb_${user.username}`
  const [fbState, setFbState] = useState(() => loadFromStorage(storageKey, { ...DEFAULT_FB_STATE }))
  const [view, setView] = useState('fb-overview')
  const [toast, setToast] = useState('')
  const [donationsTab, setDonationsTab] = useState('incoming')
  const [completedDonationIds, setCompletedDonationIds] = useState(
    () => loadFromStorage(`tt_fb_completed_${user.username}`, [])
  )

  function markDonationComplete(donId) {
    const updated = [...completedDonationIds, donId]
    setCompletedDonationIds(updated)
    localStorage.setItem(`tt_fb_completed_${user.username}`, JSON.stringify(updated))
    showToast('✅ Donation marked as completed!')
  }

  function unmarkDonationComplete(donId) {
    const updated = completedDonationIds.filter(id => id !== donId)
    setCompletedDonationIds(updated)
    localStorage.setItem(`tt_fb_completed_${user.username}`, JSON.stringify(updated))
  }
  const [newReqName, setNewReqName] = useState('')
  const [newReqQty, setNewReqQty] = useState('')
  const [newReqCat] = useState('Grains')
  const [newReqUnit, setNewReqUnit] = useState('units')
  const [newInvName, setNewInvName] = useState('')
  const [newInvQty, setNewInvQty] = useState('')
  const [newInvCat, setNewInvCat] = useState('Grains')
  const [newInvCap, setNewInvCap] = useState('')
  const [newReqPool, setNewReqPool] = useState('')
  const [newWorkerName, setNewWorkerName] = useState('')
  const [newWorkerType, setNewWorkerType] = useState('volunteer')
  const [showAddWorker, setShowAddWorker] = useState(false)

  // Location editing state
  const [fbLocInput, setFbLocInput] = useState('')
  const [fbLocLoading, setFbLocLoading] = useState(false)
  const [fbLocError, setFbLocError] = useState('')

  async function updateFbLocation(addr) {
    if (!addr.trim()) return
    setFbLocLoading(true); setFbLocError('')
    try {
      const coords = await geocodeAddress(addr)
      if (!coords) { setFbLocError('Address not found — try a more specific address.'); setFbLocLoading(false); return }
      // Patch the shelter entry in shared shelters list
      const fbName = user.fbName || 'Community Food Bank'
      setShelters(cur => {
        const patched = cur.map(s => s.name === fbName ? { ...s, address: addr, lat: coords.lat, lng: coords.lng } : s)
        localStorage.setItem('tt_shelters', JSON.stringify(patched))
        dbSave('tt_shelters', patched)
        return patched
      })
      // Persist updated address on the user account
      user.fbAddress = addr
      const accounts = loadFromStorage('tt_accounts', [])
      const updatedAccts = accounts.map(a => a.username === user.username ? { ...a, fbAddress: addr } : a)
      localStorage.setItem('tt_accounts', JSON.stringify(updatedAccts))
      setFbLocInput('')
      showToast('\u{1F4CD} Food bank location updated!')
    } catch { setFbLocError('Could not geocode address. Check your Maps API key.') }
    setFbLocLoading(false)
  }

  function useFbGPS() {
    if (!navigator.geolocation) { setFbLocError('Geolocation not supported.'); return }
    setFbLocLoading(true); setFbLocError('')
    navigator.geolocation.getCurrentPosition(
      async pos => {
        const { latitude: lat, longitude: lng } = pos.coords
        try {
          await loadGoogleMaps()
          const geocoder = new window.google.maps.Geocoder()
          geocoder.geocode({ location: { lat, lng } }, (results, status) => {
            const addr = (status === 'OK' && results[0]) ? results[0].formatted_address : lat.toFixed(4) + ', ' + lng.toFixed(4)
            updateFbLocation(addr)
          })
        } catch { updateFbLocation(lat.toFixed(4) + ', ' + lng.toFixed(4)) }
      },
      () => { setFbLocError('Could not get GPS location.'); setFbLocLoading(false) },
      { timeout: 10000 }
    )
  }

  function saveFbState(newState) {
    setFbState(newState)
    localStorage.setItem(storageKey, JSON.stringify(newState))
    dbSave(storageKey, newState)
  }

  function showToast(msg) { setToast(msg); setTimeout(() => setToast(''), 4000) }

  // Auto-merge newly confirmed donations into inventory
  const processedIds = React.useRef(new Set(loadFromStorage(`tt_fb_processed_${user.username}`, [])))
  useEffect(() => {
    const myNew = incomingDonations.filter(d =>
      d.shelter === (user.fbName || 'City Food Bank') &&
      d.status === 'confirmed' &&
      !processedIds.current.has(d.id)
    )
    if (!myNew.length) return
    let inv = [...fbState.inventory]
    myNew.forEach(don => {
      don.items.forEach(f => {
        const existing = inv.find(i => i.name.toLowerCase() === f.name.toLowerCase())
        if (existing) {
          existing.qty = Math.min(existing.qty + (f.qty || 1), existing.cap || 999)
        } else {
          inv.push({ emoji: f.emoji || '📦', name: f.name, category: f.category || 'Donated', qty: f.qty || 1, cap: Math.max((f.qty || 1) * 3, 50) })
        }
        processedIds.current.add(don.id)
      })
    })
    const newProcessed = Array.from(processedIds.current)
    localStorage.setItem(`tt_fb_processed_${user.username}`, JSON.stringify(newProcessed))
    saveFbState({ ...fbState, inventory: inv })
    showToast(`📦 ${myNew.length} new donation${myNew.length !== 1 ? 's' : ''} added to inventory!`)
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [incomingDonations])

  // Arrow key scrolling
  useEffect(() => {
    const handleKey = (e) => {
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.tagName === 'SELECT') return
      if (e.key === 'ArrowDown') { e.preventDefault(); window.scrollBy({ top: 220, behavior: 'smooth' }) }
      if (e.key === 'ArrowUp') { e.preventDefault(); window.scrollBy({ top: -220, behavior: 'smooth' }) }
    }
    window.addEventListener('keydown', handleKey)
    return () => window.removeEventListener('keydown', handleKey)
  }, [])

  const myDonations = incomingDonations.filter(d => d.shelter === (user.fbName || 'City Food Bank'))
  const totalQty = fbState.inventory.reduce((s, f) => s + f.qty, 0)
  // eslint-disable-next-line no-unused-vars
  const totalCap = fbState.inventory.reduce((s, f) => s + f.cap, 0)
  const pendingReqs = fbState.requests.filter(r => r.status === 'pending').length

  function addRequest() {
    if (!newReqName) return
    const req = { emoji: guessEmoji(newReqName), name: newReqName, qty: parseInt(newReqQty) || 10, unit: newReqUnit, category: newReqCat, status: 'pending', id: Date.now() }
    saveFbState({ ...fbState, requests: [...fbState.requests, req] })
    setNewReqName(''); setNewReqQty('')
  }

  function fulfillReq(i) {
    const reqs = fbState.requests.map((r, idx) => idx === i ? { ...r, status: 'fulfilled' } : r)
    saveFbState({ ...fbState, requests: reqs })
  }

  function deleteReq(i) {
    saveFbState({ ...fbState, requests: fbState.requests.filter((_, idx) => idx !== i) })
  }

  function addInvItem() {
    if (!newInvName) return
    const existing = fbState.inventory.find(f => f.name.toLowerCase() === newInvName.toLowerCase())
    let inv
    if (existing) inv = fbState.inventory.map(f => f.name.toLowerCase() === newInvName.toLowerCase() ? { ...f, qty: f.qty + (parseInt(newInvQty) || 1) } : f)
    else inv = [...fbState.inventory, { emoji: guessEmoji(newInvName), name: newInvName, category: newInvCat, qty: parseInt(newInvQty) || 1, cap: parseInt(newInvCap) || 100 }]
    saveFbState({ ...fbState, inventory: inv })
    setNewInvName(''); setNewInvQty(''); setNewInvCap('')
    showToast(`✅ ${newInvName} added to inventory`)
  }

  // eslint-disable-next-line no-unused-vars
  function addReqPool() {
    if (!newReqPool.trim()) return
    saveFbState({ ...fbState, requirementPool: [...fbState.requirementPool, newReqPool.trim()] })
    setNewReqPool('')
  }

  function addWorker() {
    if (!newWorkerName) return
    saveFbState({ ...fbState, workers: [...fbState.workers, { id: Date.now(), name: newWorkerName, type: newWorkerType, requirements: [] }] })
    setNewWorkerName(''); setShowAddWorker(false)
  }

  function deleteWorker(i) {
    if (window.confirm(`Remove ${fbState.workers[i].name}?`)) saveFbState({ ...fbState, workers: fbState.workers.filter((_, idx) => idx !== i) })
  }

  function togglePolicy(i, val) {
    const policies = fbState.policies.map((p, idx) => idx === i ? { ...p, enabled: val } : p)
    saveFbState({ ...fbState, policies })
  }

  return (
    <div id="foodbank-app" className="dash-app-visible">
      <nav className="dash-nav">
        <div className="dash-nav-left">
          <div className="logo" style={{ fontSize: '1.1rem' }}>Together<span>TableAI</span></div>
          <div className="nav-btns">
            {[['fb-overview','📊 Overview'],['fb-bank','📦 Food Bank'],['fb-donations','🤝 Donations'],['fb-owner','⚙️ Settings']].map(([v,l]) => (
              <button key={v} className={`nav-btn ${view === v ? 'active' : ''}`} onClick={() => setView(v)}>{l}</button>
            ))}
          </div>
        </div>
        <div className="dash-nav-right">
          <div className="user-pill"><span className="u-name">{user.username}</span><span className="u-role">Food Bank</span></div>
          <button className="logout-btn" onClick={onLogout}>Sign Out</button>
        </div>
      </nav>

      <div style={{ padding: '26px 22px', maxWidth: 940, margin: '0 auto' }}>
        {/* Overview */}
        {view === 'fb-overview' && (
          <div>
            <h1 className="view-title">{user.fbName || 'Food Bank'} Overview</h1>
            <p className="view-sub" style={{ display:'flex', alignItems:'center', gap:6 }}>
              <span className="live-dot"></span>
              Live data — donations update in real time · {user.fbAddress || ''}
            </p>
            <div className="stat-cards">
              <div className="stat-card"><div className="sc-icon">📦</div><div className="sc-label">Total Stock</div><div className="sc-value">{totalQty}</div><div className="sc-sub">units in inventory</div></div>
              <div className="stat-card"><div className="sc-icon">👥</div><div className="sc-label">People Served</div><div className="sc-value">{fbState.people.toLocaleString()}</div><div className="sc-sub">needing food</div></div>
              <div className="stat-card"><div className="sc-icon">👷</div><div className="sc-label">Staff &amp; Volunteers</div><div className="sc-value">{fbState.staffFT + fbState.staffPT + fbState.staffVol}</div><div className="sc-sub">total workers</div></div>
              <div className="stat-card"><div className="sc-icon">📋</div><div className="sc-label">Pending Requests</div><div className="sc-value">{pendingReqs}</div><div className="sc-sub">food requests</div></div>
            </div>
            {/* Show food bank's own location on map */}
            {user.fbLat && user.fbLng && (
              <div style={{ marginBottom:22 }}>
                <div className="section-heading">📍 Your Location</div>
                <GoogleMap height={200} centerLat={user.fbLat} centerLng={user.fbLng}
                  markers={[{ name: user.fbName || 'Food Bank', address: user.fbAddress || '', hours: user.fbHours || '', lat: user.fbLat, lng: user.fbLng }]} />
              </div>
            )}
            <div className="section-heading">📊 Inventory Capacity</div>
            <div style={{ background: 'white', borderRadius: 18, padding: '22px 24px', boxShadow: 'var(--shadow)', marginBottom: 22 }}>
              {[...new Set(fbState.inventory.map(f => f.category))].map(cat => {
                const items = fbState.inventory.filter(f => f.category === cat)
                const qty = items.reduce((s, f) => s + f.qty, 0)
                const cap = items.reduce((s, f) => s + f.cap, 0)
                const pct = Math.round(qty / cap * 100)
                const cls = pct >= 70 ? 'green' : pct >= 40 ? 'amber' : 'red'
                return (
                  <div key={cat} style={{ marginBottom: 14 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '.84rem', fontWeight: 600, marginBottom: 5 }}>
                      <span>{cat}</span><span style={{ color: 'var(--muted)' }}>{qty} / {cap} units ({pct}%)</span>
                    </div>
                    <div className="progress-bar-wrap"><div className={`progress-bar-fill ${cls}`} style={{ width: `${pct}%` }}></div></div>
                  </div>
                )
              })}
            </div>
            <div className="section-heading">📬 Incoming Donations <span style={{ fontSize: '.78rem', color: 'var(--muted)' }}>{myDonations.length ? `${myDonations.length} total` : ''}</span></div>
            {myDonations.length === 0
              ? <div style={{ background:'white', borderRadius:14, padding:'24px', textAlign:'center', boxShadow:'var(--shadow)', color:'var(--muted)', fontSize:'.85rem', fontStyle:'italic' }}>
                  <div style={{ fontSize:'2rem', marginBottom:8 }}>📭</div>
                  No donations received yet. Share your food bank address so donors can find you!
                </div>
              : myDonations.slice().reverse().map((d, i) => (
                <div key={i} className="donation-card">
                  <div className="don-header">
                    <span className="don-user">{d.donorType === 'business' ? '🏪' : '👤'} {d.donor}</span>
                    <span className="don-time">📅 {d.date} · ⏰ {d.time}</span>
                  </div>
                  <div className="don-items">{d.items.map((it, j) => <div key={j} className="don-item-tag">{it.emoji} {it.name}{it.qty > 1 ? ` ×${it.qty}` : ''}</div>)}</div>
                  <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginTop:6 }}>
                    <span className={`don-status ${d.status}`}>{d.status === 'confirmed' ? '✅ Confirmed' : '⏳ Pending'}</span>
                    {d.donorType === 'business' && <span style={{ fontSize:'.7rem', background:'#e8f0fd', color:'#3b5fc0', padding:'2px 8px', borderRadius:50, fontWeight:600 }}>Business Donation</span>}
                  </div>
                </div>
              ))
            }
          </div>
        )}

        {/* Food Bank Management */}
        {view === 'fb-bank' && (
          <div>
            <h1 className="view-title">Food Bank Management</h1>
            <p className="view-sub">Manage inventory and food requests.</p>
            <div className="section-heading">📋 Food Requests <span style={{ fontSize: '.78rem', color: 'var(--muted)' }}>{fbState.requests.length} total</span></div>
            <div style={{ background: 'white', borderRadius: 14, padding: '16px 18px', boxShadow: 'var(--shadow)', marginBottom: 18 }}>
              <div style={{ display: 'flex', gap: 8, marginBottom: 14, flexWrap: 'wrap' }}>
                <input type="text" value={newReqName} onChange={e => setNewReqName(e.target.value)} placeholder="Item name" style={{ flex: 1, minWidth: 120, padding: '8px 12px', borderRadius: 9, border: '2px solid rgba(61,46,30,.14)', fontFamily: '"DM Sans",sans-serif', fontSize: '.84rem', outline: 'none' }} />
                <input type="number" value={newReqQty} onChange={e => setNewReqQty(e.target.value)} placeholder="Qty" style={{ width: 70, padding: '8px 12px', borderRadius: 9, border: '2px solid rgba(61,46,30,.14)', fontFamily: '"DM Sans",sans-serif', fontSize: '.84rem', outline: 'none' }} />
                <select value={newReqUnit} onChange={e => setNewReqUnit(e.target.value)} className="custom-select">
                  {['units','lbs','kg','cans','bags','boxes'].map(u => <option key={u}>{u}</option>)}
                </select>
                <button className="add-btn" onClick={addRequest}>+ Add Request</button>
              </div>
              {fbState.requests.length === 0
                ? <p style={{ color: 'var(--muted)', fontStyle: 'italic', fontSize: '.85rem' }}>No requests yet.</p>
                : fbState.requests.map((r, i) => (
                  <div key={i} className="req-item">
                    <span className="req-emoji">{r.emoji}</span>
                    <span className="req-name">{r.name}</span>
                    <span className="req-qty">{r.qty} {r.unit} · {r.category}</span>
                    <span className={`req-status ${r.status}`}>{r.status === 'pending' ? 'Pending' : 'Fulfilled'}</span>
                    {r.status === 'pending' && <button className="req-del" onClick={() => fulfillReq(i)} title="Mark fulfilled">✅</button>}
                    <button className="req-del" onClick={() => deleteReq(i)} title="Delete">✕</button>
                  </div>
                ))
              }
            </div>
            <div className="section-heading">📦 Inventory</div>
            <div style={{ background: 'white', borderRadius: 14, padding: '16px 18px', boxShadow: 'var(--shadow)', marginBottom: 18 }}>
              <div style={{ display: 'flex', gap: 8, marginBottom: 14, flexWrap: 'wrap' }}>
                <input type="text" value={newInvName} onChange={e => setNewInvName(e.target.value)} placeholder="Item name" style={{ flex: 1, minWidth: 120, padding: '8px 12px', borderRadius: 9, border: '2px solid rgba(61,46,30,.14)', fontFamily: '"DM Sans",sans-serif', fontSize: '.84rem', outline: 'none' }} />
                <input type="number" value={newInvQty} onChange={e => setNewInvQty(e.target.value)} placeholder="Qty" style={{ width: 70, padding: '8px 12px', borderRadius: 9, border: '2px solid rgba(61,46,30,.14)', fontFamily: '"DM Sans",sans-serif', fontSize: '.84rem', outline: 'none' }} />
                <input type="number" value={newInvCap} onChange={e => setNewInvCap(e.target.value)} placeholder="Max" style={{ width: 70, padding: '8px 12px', borderRadius: 9, border: '2px solid rgba(61,46,30,.14)', fontFamily: '"DM Sans",sans-serif', fontSize: '.84rem', outline: 'none' }} />
                <select value={newInvCat} onChange={e => setNewInvCat(e.target.value)} className="custom-select">
                  {['Grains','Proteins','Dairy','Vegetables','Fruits','Canned Goods','Snacks','Other'].map(c => <option key={c}>{c}</option>)}
                </select>
                <button className="add-btn" onClick={addInvItem}>+ Add</button>
              </div>
              <table className="inv-table">
                <thead><tr><th>Category</th><th>Item</th><th>Qty</th><th>Capacity</th><th></th></tr></thead>
                <tbody>
                  {fbState.inventory.map((f, i) => {
                    const pct = Math.round(f.qty / f.cap * 100)
                    const fillColor = pct >= 70 ? 'var(--sage)' : pct >= 40 ? 'var(--honey)' : '#c0392b'
                    return (
                      <tr key={i}>
                        <td>{f.category}</td>
                        <td><span style={{ marginRight: 6 }}>{f.emoji}</span>{f.name}</td>
                        <td className="inv-qty">{f.qty}</td>
                        <td className="inv-bar-cell">
                          <div className="inv-bar"><div className="inv-bar-fill" style={{ width: `${pct}%`, background: fillColor }}></div></div>
                          <div style={{ fontSize: '.7rem', color: 'var(--muted)', marginTop: 2 }}>{pct}% of {f.cap}</div>
                        </td>
                        <td><button className="req-del" onClick={() => saveFbState({ ...fbState, inventory: fbState.inventory.filter((_, idx) => idx !== i) })} title="Remove">🗑️</button></td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ── DONATIONS TAB ── */}
        {view === 'fb-donations' && (
          <div>
            <h1 className="view-title">🤝 Donations</h1>
            <p className="view-sub">Track incoming and completed donations to {user.fbName || 'your food bank'}.</p>

            {/* Subtabs */}
            <div style={{ display:'flex', gap:8, marginBottom:20 }}>
              <button onClick={() => setDonationsTab('incoming')} style={{ flex:1, padding:'9px 0', borderRadius:50, border:'none', fontWeight:700, fontSize:'.83rem', cursor:'pointer', background: donationsTab==='incoming' ? 'var(--earth)' : 'var(--card-bg)', color: donationsTab==='incoming' ? 'white' : 'var(--muted)', boxShadow: donationsTab==='incoming' ? 'var(--shadow)' : 'none' }}>
                📬 Incoming
                {myDonations.filter(d => !completedDonationIds.includes(d.id)).length > 0 &&
                  <span style={{ background:'rgba(255,255,255,.3)', borderRadius:50, padding:'1px 7px', marginLeft:4, fontSize:'.75rem' }}>
                    {myDonations.filter(d => !completedDonationIds.includes(d.id)).length}
                  </span>
                }
              </button>
              <button onClick={() => setDonationsTab('completed')} style={{ flex:1, padding:'9px 0', borderRadius:50, border:'none', fontWeight:700, fontSize:'.83rem', cursor:'pointer', background: donationsTab==='completed' ? 'var(--sage)' : 'var(--card-bg)', color: donationsTab==='completed' ? 'white' : 'var(--muted)', boxShadow: donationsTab==='completed' ? 'var(--shadow)' : 'none' }}>
                ✅ Completed
                {myDonations.filter(d => completedDonationIds.includes(d.id)).length > 0 &&
                  <span style={{ background:'rgba(255,255,255,.3)', borderRadius:50, padding:'1px 7px', marginLeft:4, fontSize:'.75rem' }}>
                    {myDonations.filter(d => completedDonationIds.includes(d.id)).length}
                  </span>
                }
              </button>
            </div>

            {donationsTab === 'incoming' && (() => {
              const incoming = myDonations.filter(d => !completedDonationIds.includes(d.id)).slice().reverse()
              return incoming.length === 0 ? (
                <div style={{ textAlign:'center', padding:'60px 20px', color:'var(--muted)' }}>
                  <div style={{ fontSize:'3rem', marginBottom:14 }}>📭</div>
                  <div style={{ fontFamily:'Fraunces, serif', fontSize:'1.2rem', fontWeight:700, color:'var(--earth)', marginBottom:8 }}>No incoming donations</div>
                  <div style={{ fontSize:'.88rem' }}>New donations from households and businesses will appear here.</div>
                </div>
              ) : (
                <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
                  {incoming.map((d, i) => (
                    <div key={i} style={{ background:'var(--card-bg)', borderRadius:16, padding:'16px 18px', boxShadow:'var(--shadow)' }}>
                      <div style={{ display:'flex', alignItems:'flex-start', gap:12 }}>
                        <input type="checkbox" checked={false} onChange={() => markDonationComplete(d.id)}
                          style={{ width:18, height:18, marginTop:4, cursor:'pointer', accentColor:'var(--sage)', flexShrink:0 }} />
                        <div style={{ flex:1 }}>
                          <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', marginBottom:8, flexWrap:'wrap', gap:6 }}>
                            <div>
                              <div style={{ fontWeight:700, fontSize:'.95rem', color:'var(--earth)' }}>
                                {d.donorType === 'business' ? '🏪' : '👤'} {d.donor}
                              </div>
                              <div style={{ fontSize:'.78rem', color:'var(--muted)', marginTop:3 }}>📅 {d.date} &nbsp;·&nbsp; ⏰ {d.time}</div>
                            </div>
                            <div style={{ display:'flex', gap:6, flexWrap:'wrap' }}>
                              <span className={`don-status ${d.status}`}>{d.status === 'confirmed' ? '✅ Confirmed' : '⏳ Pending'}</span>
                              {d.donorType === 'business' && <span style={{ fontSize:'.7rem', background:'#e8f0fd', color:'#3b5fc0', padding:'2px 8px', borderRadius:50, fontWeight:600 }}>Business</span>}
                            </div>
                          </div>
                          <div style={{ fontSize:'.78rem', fontWeight:700, color:'var(--muted)', textTransform:'uppercase', letterSpacing:'.06em', marginBottom:7 }}>Items</div>
                          <div style={{ display:'flex', flexWrap:'wrap', gap:6, marginBottom:12 }}>
                            {d.items.map((item, j) => (
                              <span key={j} style={{ display:'flex', alignItems:'center', gap:5, background:'var(--bg)', borderRadius:50, padding:'4px 11px', fontSize:'.8rem', fontWeight:600 }}>
                                <span>{item.emoji}</span> {item.name} {item.qty > 1 && <span style={{ color:'var(--muted)', fontSize:'.72rem' }}>×{item.qty}</span>}
                              </span>
                            ))}
                          </div>
                          <button onClick={() => markDonationComplete(d.id)}
                            style={{ background:'var(--sage)', color:'white', border:'none', borderRadius:50, padding:'6px 18px', fontSize:'.78rem', fontWeight:700, cursor:'pointer' }}>
                            ✅ Mark as Completed
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )
            })()}

            {donationsTab === 'completed' && (() => {
              const completed = myDonations.filter(d => completedDonationIds.includes(d.id)).slice().reverse()
              return completed.length === 0 ? (
                <div style={{ textAlign:'center', padding:'60px 20px', color:'var(--muted)' }}>
                  <div style={{ fontSize:'3rem', marginBottom:14 }}>✅</div>
                  <div style={{ fontFamily:'Fraunces, serif', fontSize:'1.2rem', fontWeight:700, color:'var(--earth)', marginBottom:8 }}>No completed donations yet</div>
                  <div style={{ fontSize:'.88rem' }}>Mark incoming donations as completed to move them here.</div>
                </div>
              ) : (
                <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
                  {completed.map((d, i) => (
                    <div key={i} style={{ background:'var(--card-bg)', borderRadius:16, padding:'16px 18px', boxShadow:'var(--shadow)', opacity:0.85 }}>
                      <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', marginBottom:8, flexWrap:'wrap', gap:6 }}>
                        <div>
                          <div style={{ fontWeight:700, fontSize:'.95rem', color:'var(--earth)' }}>
                            {d.donorType === 'business' ? '🏪' : '👤'} {d.donor}
                          </div>
                          <div style={{ fontSize:'.78rem', color:'var(--muted)', marginTop:3 }}>📅 {d.date} &nbsp;·&nbsp; ⏰ {d.time}</div>
                        </div>
                        <span style={{ background:'#e8f5ea', color:'var(--sage)', borderRadius:50, padding:'3px 11px', fontSize:'.72rem', fontWeight:700 }}>✅ Completed</span>
                      </div>
                      <div style={{ display:'flex', flexWrap:'wrap', gap:6, marginBottom:10 }}>
                        {d.items.map((item, j) => (
                          <span key={j} style={{ display:'flex', alignItems:'center', gap:5, background:'var(--bg)', borderRadius:50, padding:'4px 11px', fontSize:'.8rem', fontWeight:600 }}>
                            <span>{item.emoji}</span> {item.name} {item.qty > 1 && <span style={{ color:'var(--muted)', fontSize:'.72rem' }}>×{item.qty}</span>}
                          </span>
                        ))}
                      </div>
                      <button onClick={() => unmarkDonationComplete(d.id)}
                        style={{ background:'none', border:'1.5px solid #e0d6cc', borderRadius:50, padding:'5px 14px', fontSize:'.75rem', color:'var(--muted)', cursor:'pointer', fontWeight:600 }}>
                        ↩ Move back to Incoming
                      </button>
                    </div>
                  ))}
                </div>
              )
            })()}
          </div>
        )}

        {/* Settings */}
        {view === 'fb-owner' && (
          <div>
            <h1 className="view-title">Food Bank Settings</h1>
            <p className="view-sub">Manage your team and policies.</p>
            <div className="stat-cards" style={{ marginBottom: 22 }}>
              {[['Full-Time','ft','staffFT'],['Part-Time','pt','staffPT'],['Volunteers','vol','staffVol']].map(([l,,k]) => (
                <div key={k} className="stat-card">
                  <div className="sc-label">{l}</div>
                  <div className="counter-row" style={{ marginTop: 8 }}>
                    <button className="counter-btn" onClick={() => saveFbState({ ...fbState, [k]: Math.max(0, fbState[k] - 1) })}>−</button>
                    <span className="counter-num">{fbState[k]}</span>
                    <button className="counter-btn" onClick={() => saveFbState({ ...fbState, [k]: fbState[k] + 1 })}>+</button>
                  </div>
                </div>
              ))}
              <div className="stat-card">
                <div className="sc-label">People Needing Food</div>
                <div className="counter-row" style={{ marginTop: 8 }}>
                  <button className="counter-btn" onClick={() => saveFbState({ ...fbState, people: Math.max(0, fbState.people - 10) })}>−</button>
                  <span className="counter-num">{fbState.people}</span>
                  <button className="counter-btn" onClick={() => saveFbState({ ...fbState, people: fbState.people + 10 })}>+</button>
                </div>
              </div>
            </div>
            <div className="staff-card" style={{ marginBottom: 18 }}>
              <h3>👷 Workers &amp; Volunteers</h3>
              {fbState.workers.map((w, i) => (
                <div key={i} className="worker-card" style={{ background: 'var(--cream)', borderRadius: 12, padding: '10px 14px', marginBottom: 8, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div>
                    <div style={{ fontWeight: 600, fontSize: '.88rem' }}>{w.name}</div>
                    <div style={{ fontSize: '.74rem', color: 'var(--muted)' }}>{w.type}</div>
                  </div>
                  <button className="worker-del-btn" onClick={() => deleteWorker(i)}>🗑 Remove</button>
                </div>
              ))}
              {showAddWorker && (
                <div className="add-worker-form open">
                  <input type="text" value={newWorkerName} onChange={e => setNewWorkerName(e.target.value)} placeholder="Name" />
                  <select value={newWorkerType} onChange={e => setNewWorkerType(e.target.value)}>
                    <option value="employee">Employee</option>
                    <option value="volunteer">Volunteer</option>
                  </select>
                  <div style={{ display: 'flex', gap: 8 }}>
                    <button className="add-btn" onClick={addWorker}>Save</button>
                    <button className="multi-cancel-btn" onClick={() => setShowAddWorker(false)}>Cancel</button>
                  </div>
                </div>
              )}
              {!showAddWorker && <button className="add-worker-btn" onClick={() => setShowAddWorker(true)}>+ Add Worker or Volunteer</button>}
            </div>
            <div className="staff-card">
              <h3>⚙️ Policies</h3>
              {fbState.policies.map((p, i) => (
                <div key={i} className="staff-row">
                  <div><div className="sr-label">{p.label}</div></div>
                  <label className="toggle-switch">
                    <input type="checkbox" checked={p.enabled} onChange={e => togglePolicy(i, e.target.checked)} />
                    <span className="toggle-slider"></span>
                  </label>
                </div>
              ))}
            </div>
            <div style={{ marginTop: 28 }}>
              <SettingsPanel
                theme={theme}
                onThemeChange={onThemeChange}
                user={user}
                onLogout={onLogout}
                onClearData={() => {
                  if (!window.confirm('Clear all food bank data? This will reset inventory, requests, workers, and donations. This cannot be undone.')) return
                  const fresh = { ...DEFAULT_FB_STATE }
                  saveFbState(fresh)
                  onClearDonations(d => d.shelter === (user.fbName || 'City Food Bank'))
                  showToast('🗑️ All food bank data cleared')
                }}
                onExportData={() => {
                  const data = { inventory: fbState.inventory, requests: fbState.requests, workers: fbState.workers, donations: incomingDonations, exportedAt: new Date().toISOString() }
                  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
                  const url = URL.createObjectURL(blob)
                  const a = document.createElement('a'); a.href = url; a.download = 'foodbank-data.json'; a.click()
                  URL.revokeObjectURL(url)
                  showToast('📤 Data exported!')
                }}
                locationSection={
                  <LocationSettingsRow
                    label="Food Bank Address"
                    sub="Updates your pin on the community map visible to all customers"
                    address={user.fbAddress || ''}
                    loading={fbLocLoading}
                    error={fbLocError}
                    input={fbLocInput}
                    setInput={setFbLocInput}
                    onSubmit={updateFbLocation}
                    onGPS={useFbGPS}
                    onClear={null}
                  />
                }
              />
            </div>
          </div>
        )}
      </div>
      {toast && <Toast msg={toast} />}
    </div>
  )
}

// ─────────────────────────────────────────────
// STORE / BUSINESS APP
// ─────────────────────────────────────────────
function StoreApp({ user, onLogout, shelters, onDonationUpdate, onUpdateStoreInventory, theme, onThemeChange, onClearDonations, setGroceryStores, setSharedRestaurants }) {
  const storageKey = `tt_store_${user.username}`
  const initialStores = [{ name: user.regStoreName || 'My Store', address: user.regStoreAddr || '', inventory: [], soldToday: 0 }]
  const initialRests = user.bizType === 'restaurant' || user.bizType === 'both'
    ? [{ name: user.regRestName || 'My Restaurant', address: user.regRestAddr || '', inventory: [], serviceToday: 0 }]
    : []

  const [storeData, setStoreData] = useState(() => loadFromStorage(storageKey, { stores: initialStores, restaurants: initialRests, staffFT: 0, staffPT: 0, staffCas: 0 }))

  // Geocode own store/restaurant addresses on first mount if lat/lng missing
  useEffect(() => {
    let changed = false
    const updatedStores = storeData.stores.map(s => ({ ...s }))
    const updatedRests  = storeData.restaurants.map(r => ({ ...r }))

    const promises = []
    updatedStores.forEach((s, i) => {
      if (s.address && !s.lat) {
        promises.push(
          geocodeAddress(s.address).then(coords => {
            if (coords) { updatedStores[i] = { ...s, ...coords }; changed = true }
          })
        )
      }
    })
    updatedRests.forEach((r, i) => {
      if (r.address && !r.lat) {
        promises.push(
          geocodeAddress(r.address).then(coords => {
            if (coords) { updatedRests[i] = { ...r, ...coords }; changed = true }
          })
        )
      }
    })

    Promise.all(promises).then(() => {
      if (changed) {
        const updated = { ...storeData, stores: updatedStores, restaurants: updatedRests }
        setStoreData(updated)
        localStorage.setItem(storageKey, JSON.stringify(updated))
        dbSave(storageKey, updated)
      }
    })
  }, []) // eslint-disable-line

  const [view, setView] = useState('st-overview')
  const [currentStoreIdx, setCurrentStoreIdx] = useState(0)
  const [currentRestIdx, setCurrentRestIdx] = useState(0)
  const [toast, setToast] = useState('')
  const [addName, setAddName] = useState('')
  const [addQty, setAddQty] = useState('')
  const [addCat, setAddCat] = useState('Grains')
  const [addPrice, setAddPrice] = useState('')
  const [removeItem, setRemoveItem] = useState('')
  const [removeQty, setRemoveQty] = useState('')
  const [removeReason, setRemoveReason] = useState('sold')
  const [rsAddName, setRsAddName] = useState('')
  const [rsAddQty, setRsAddQty] = useState('')
  const [rsAddCat, setRsAddCat] = useState('Proteins')
  const [rsAddUnit, setRsAddUnit] = useState('units')
  const [rsRemoveItem, setRsRemoveItem] = useState('')
  const [rsRemoveQty, setRsRemoveQty] = useState('')
  const [rsRemoveReason, setRsRemoveReason] = useState('used')

  // ── Store-to-FoodBank Donation ──
  const [donateSelections, setDonateSelections] = useState({}) // { 'ItemName': qty }
  const [selectedFB, setSelectedFB] = useState(null)
  const [donateSlot, setDonateSlot] = useState(null)
  const [donateTab, setDonateTab] = useState('new')

  // Location editing state
  const [storeLocInput, setStoreLocInput] = useState('')
  const [storeLocLoading, setStoreLocLoading] = useState(false)
  const [storeLocError, setStoreLocError] = useState('')
  const [restLocInput, setRestLocInput] = useState('')
  const [restLocLoading, setRestLocLoading] = useState(false)
  const [restLocError, setRestLocError] = useState('')

  async function updateStoreLocation(addr, idx = 0) {
    if (!addr.trim()) return
    setStoreLocLoading(true); setStoreLocError('')
    try {
      const coords = await geocodeAddress(addr)
      if (!coords) { setStoreLocError('Address not found — try a more specific address.'); setStoreLocLoading(false); return }
      const storeName = storeData.stores[idx]?.name || user.regStoreName || 'My Store'
      const updatedStores = storeData.stores.map((s, i) => i === idx ? { ...s, address: addr, lat: coords.lat, lng: coords.lng } : s)
      saveStoreData({ ...storeData, stores: updatedStores })
      // Also patch groceryStores shared list
      if (setGroceryStores) {
        setGroceryStores(cur => {
          const patched = cur.map(s => s.name === storeName ? { ...s, address: addr, lat: coords.lat, lng: coords.lng } : s)
          localStorage.setItem('tt_stores', JSON.stringify(patched))
          dbSave('tt_stores', patched)
          return patched
        })
      }
      user.regStoreAddr = addr
      const accounts = loadFromStorage('tt_accounts', [])
      localStorage.setItem('tt_accounts', JSON.stringify(accounts.map(a => a.username === user.username ? { ...a, regStoreAddr: addr } : a)))
      setStoreLocInput('')
      showToast('\u{1F4CD} Store location updated!')
    } catch { setStoreLocError('Could not geocode address. Check your Maps API key.') }
    setStoreLocLoading(false)
  }

  async function updateRestLocation(addr, idx = 0) {
    if (!addr.trim()) return
    setRestLocLoading(true); setRestLocError('')
    try {
      const coords = await geocodeAddress(addr)
      if (!coords) { setRestLocError('Address not found — try a more specific address.'); setRestLocLoading(false); return }
      const restName = storeData.restaurants[idx]?.name || user.regRestName || 'My Restaurant'
      const updatedRests = storeData.restaurants.map((r, i) => i === idx ? { ...r, address: addr, lat: coords.lat, lng: coords.lng } : r)
      saveStoreData({ ...storeData, restaurants: updatedRests })
      if (setSharedRestaurants) {
        setSharedRestaurants(cur => {
          const patched = cur.map(r => r.name === restName ? { ...r, address: addr, lat: coords.lat, lng: coords.lng } : r)
          localStorage.setItem('tt_restaurants', JSON.stringify(patched))
          dbSave('tt_restaurants', patched)
          return patched
        })
      }
      user.regRestAddr = addr
      const accounts = loadFromStorage('tt_accounts', [])
      localStorage.setItem('tt_accounts', JSON.stringify(accounts.map(a => a.username === user.username ? { ...a, regRestAddr: addr } : a)))
      setRestLocInput('')
      showToast('\u{1F4CD} Restaurant location updated!')
    } catch { setRestLocError('Could not geocode address. Check your Maps API key.') }
    setRestLocLoading(false)
  }

  function saveStoreData(newData) {
    setStoreData(newData)
    localStorage.setItem(storageKey, JSON.stringify(newData))
    dbSave(storageKey, newData)
    if (onUpdateStoreInventory) {
      const storeName = user.regStoreName || 'My Store'
      const stocks = newData.stores.flatMap(s => s.inventory.map(f => f.name))
      onUpdateStoreInventory(storeName, stocks, newData.stores)
    }
  }
  function showToast(msg) { setToast(msg); setTimeout(() => setToast(''), 4000) }

  function confirmStoreDonation() {
    if (!selectedFB || !donateSlot) return
    const itemsToGive = Object.entries(donateSelections)
      .filter(([, qty]) => qty > 0)
      .map(([name, qty]) => {
        const found = currentStore.inventory.find(f => f.name === name)
        return found ? { emoji: found.emoji, name: found.name, qty } : null
      }).filter(Boolean)
    if (!itemsToGive.length) { showToast('⚠️ Select at least one item to donate.'); return }

    // Reduce store inventory
    const stores = storeData.stores.map((s, i) => {
      if (i !== currentStoreIdx) return s
      const newInv = s.inventory.map(f => {
        const giveQty = donateSelections[f.name] || 0
        if (!giveQty) return f
        const newQty = Math.max(0, f.qty - giveQty)
        return newQty === 0 ? null : { ...f, qty: newQty }
      }).filter(Boolean)
      return { ...s, inventory: newInv }
    })
    saveStoreData({ ...storeData, stores })

    // Create donation record (same shape as customer donations)
    const dateStr = new Date().toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })
    const donation = {
      id: Date.now(),
      donor: user.regStoreName || user.username,
      donorType: 'business',
      shelter: selectedFB.name,
      items: itemsToGive,
      time: donateSlot,
      date: dateStr,
      status: 'confirmed',
    }
    onDonationUpdate(donation)

    setDonateSelections({})
    setSelectedFB(null)
    setDonateSlot(null)
    showToast(`✅ Donation to ${selectedFB.name} confirmed for ${donateSlot}!`)
  }

  // Arrow key scrolling
  useEffect(() => {
    const handleKey = (e) => {
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.tagName === 'SELECT') return
      if (e.key === 'ArrowDown') { e.preventDefault(); window.scrollBy({ top: 220, behavior: 'smooth' }) }
      if (e.key === 'ArrowUp') { e.preventDefault(); window.scrollBy({ top: -220, behavior: 'smooth' }) }
    }
    window.addEventListener('keydown', handleKey)
    return () => window.removeEventListener('keydown', handleKey)
  }, [])

  const currentStore = storeData.stores[currentStoreIdx] || { name: '', inventory: [] }
  const currentRest = storeData.restaurants[currentRestIdx] || { name: '', inventory: [] }

  const allInv = [...storeData.stores.flatMap(s => s.inventory), ...storeData.restaurants.flatMap(r => r.inventory)]
  const totalQty = allInv.reduce((s, f) => s + (f.qty || 0), 0)
  const lowStock = allInv.filter(f => f.qty <= 10).length
  const totalSold = storeData.stores.reduce((s, st) => s + (st.soldToday || 0), 0) + storeData.restaurants.reduce((s, r) => s + (r.serviceToday || 0), 0)
  const totalLocs = storeData.stores.length + storeData.restaurants.length

  function stAddItem() {
    if (!addName || !addQty) { showToast('Please enter name and quantity.'); return }
    const stores = storeData.stores.map((s, i) => {
      if (i !== currentStoreIdx) return s
      const existing = s.inventory.find(f => f.name.toLowerCase() === addName.toLowerCase())
      if (existing) return { ...s, inventory: s.inventory.map(f => f.name.toLowerCase() === addName.toLowerCase() ? { ...f, qty: f.qty + parseInt(addQty) } : f) }
      return { ...s, inventory: [...s.inventory, { emoji: guessEmoji(addName), name: addName, category: addCat, qty: parseInt(addQty) || 1, price: parseFloat(addPrice) || 0 }] }
    })
    saveStoreData({ ...storeData, stores })
    setAddName(''); setAddQty(''); setAddPrice('')
  }

  function stRemoveItem() {
    if (!removeItem) return
    const qty = parseInt(removeQty) || 1
    const stores = storeData.stores.map((s, i) => {
      if (i !== currentStoreIdx) return s
      const item = s.inventory.find(f => f.name === removeItem)
      if (!item) return s
      const newQty = Math.max(0, item.qty - qty)
      const inv = newQty === 0 ? s.inventory.filter(f => f.name !== removeItem) : s.inventory.map(f => f.name === removeItem ? { ...f, qty: newQty } : f)
      return { ...s, inventory: inv, soldToday: (s.soldToday || 0) + (removeReason === 'sold' ? qty : 0) }
    })
    saveStoreData({ ...storeData, stores })
    setRemoveQty('')
  }

  function rsAddItem() {
    if (!rsAddName || !rsAddQty) return
    const restaurants = storeData.restaurants.map((r, i) => {
      if (i !== currentRestIdx) return r
      const existing = r.inventory.find(f => f.name.toLowerCase() === rsAddName.toLowerCase())
      if (existing) return { ...r, inventory: r.inventory.map(f => f.name.toLowerCase() === rsAddName.toLowerCase() ? { ...f, qty: f.qty + parseInt(rsAddQty) } : f) }
      return { ...r, inventory: [...r.inventory, { emoji: guessEmoji(rsAddName), name: rsAddName, category: rsAddCat, qty: parseInt(rsAddQty) || 1, unit: rsAddUnit }] }
    })
    saveStoreData({ ...storeData, restaurants })
    setRsAddName(''); setRsAddQty('')
  }

  function rsDoRemove() {
    if (!rsRemoveItem) return
    const qty = parseInt(rsRemoveQty) || 1
    const restaurants = storeData.restaurants.map((r, ri) => {
      if (ri !== currentRestIdx) return r
      const item = r.inventory.find(f => f.name === rsRemoveItem)
      if (!item) return r
      const newQty = Math.max(0, item.qty - qty)
      const inv = newQty === 0 ? r.inventory.filter(f => f.name !== rsRemoveItem) : r.inventory.map(f => f.name === rsRemoveItem ? { ...f, qty: newQty } : f)
      return { ...r, inventory: inv, usedToday: (r.usedToday || 0) + (rsRemoveReason === 'used' ? qty : 0) }
    })
    saveStoreData({ ...storeData, restaurants })
    setRsRemoveItem(''); setRsRemoveQty('')
  }

  const showBizType = user.bizType || 'store'
  const navItems = [
    ['st-overview', '📊 Overview'],
    ...(showBizType === 'store' || showBizType === 'both' ? [['st-stores', '🏪 Stores']] : []),
    ...(showBizType === 'restaurant' || showBizType === 'both' ? [['st-restaurants', '🍽️ Restaurants']] : []),
    ['st-donate', '🤝 Donate to Bank'],
    ['st-owner', '⚙️ Settings'],
  ]

  return (
    <div id="store-app" className="dash-app-visible">
      <nav className="dash-nav">
        <div className="dash-nav-left">
          <div className="logo" style={{ fontSize: '1.1rem' }}>Together<span>TableAI</span></div>
          <div className="nav-btns">
            {navItems.map(([v, l]) => <button key={v} className={`nav-btn ${view === v ? 'active' : ''}`} onClick={() => setView(v)}>{l}</button>)}
          </div>
        </div>
        <div className="dash-nav-right">
          <div className="user-pill"><span className="u-name">{user.username}</span><span className="u-role">Business</span></div>
          <button className="logout-btn" onClick={onLogout}>Sign Out</button>
        </div>
      </nav>

      <div style={{ padding: '26px 22px', maxWidth: 940, margin: '0 auto' }}>
        {/* Overview */}
        {view === 'st-overview' && (
          <div>
            <h1 className="view-title">Business Overview</h1>
            <p className="view-sub">Your business snapshot at a glance.</p>
            <div className="stat-cards">
              <div className="stat-card"><div className="sc-icon">🏢</div><div className="sc-label">Total Locations</div><div className="sc-value">{totalLocs}</div><div className="sc-sub">stores &amp; restaurants</div></div>
              <div className="stat-card"><div className="sc-icon">📦</div><div className="sc-label">Total Stock</div><div className="sc-value">{totalQty}</div><div className="sc-sub">units across locations</div></div>
              <div className="stat-card"><div className="sc-icon">💰</div><div className="sc-label">Sales Today</div><div className="sc-value">{totalSold}</div><div className="sc-sub">units moved</div></div>
              <div className="stat-card"><div className="sc-icon">⚠️</div><div className="sc-label">Low Stock</div><div className="sc-value">{lowStock}</div><div className="sc-sub">need restocking</div></div>
            </div>
            {/* Map of all registered locations */}
            {(() => {
              const storeMarkers = storeData.stores.filter(s => s.lat && s.lng).map(s => ({ name: s.name, address: s.address, lat: s.lat, lng: s.lng, type: 'grocery' }))
              const restMarkers  = storeData.restaurants.filter(r => r.lat && r.lng).map(r => ({ name: r.name, address: r.address, lat: r.lat, lng: r.lng, type: 'restaurant' }))
              const allMarkers   = [...storeMarkers, ...restMarkers]
              if (allMarkers.length === 0 && (user.regStoreAddr || user.regRestAddr)) {
                // Try to geocode from account address if not yet on storeData
                return null
              }
              return (
                <div style={{ marginBottom: 22 }}>
                  <div className="section-heading">📍 Your Locations</div>
                  <GoogleMap height={220} markers={allMarkers} />
                </div>
              )
            })()}
            <div className="section-heading">⚠️ Low Stock Alerts</div>
            {allInv.filter(f => f.qty <= 15).sort((a, b) => a.qty - b.qty).map((f, i) => (
              <div key={i} className="req-item">
                <span className="req-emoji">{f.emoji || '📦'}</span>
                <span className="req-name">{f.name}</span>
                <span className="req-qty">{f.qty} left</span>
                <span className={`req-status ${f.qty <= 5 ? 'pending' : 'fulfilled'}`}>{f.qty <= 5 ? '— Critical' : '— Low'}</span>
              </div>
            ))}
          </div>
        )}

        {/* Store Inventory */}
        {view === 'st-stores' && (
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 12, marginBottom: 20 }}>
              <div><h1 className="view-title">Stores</h1><p className="view-sub">Manage store locations and inventory.</p></div>
              {storeData.stores.length > 1 && (
                <select className="custom-select" value={currentStoreIdx} onChange={e => setCurrentStoreIdx(parseInt(e.target.value))}>
                  {storeData.stores.map((s, i) => <option key={i} value={i}>{s.name}</option>)}
                </select>
              )}
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 22 }}>
              <div className="food-form-card">
                <h3>➕ Add Stock</h3>
                <div className="food-form-grid">
                  <div><label>Item Name</label><input type="text" value={addName} onChange={e => setAddName(e.target.value)} placeholder="e.g. Whole Milk" /></div>
                  <div><label>Category</label><select value={addCat} onChange={e => setAddCat(e.target.value)}>{['Grains','Proteins','Dairy','Vegetables','Fruits','Canned Goods','Snacks','Beverages','Bakery','Other'].map(c => <option key={c}>{c}</option>)}</select></div>
                  <div><label>Quantity</label><input type="number" value={addQty} onChange={e => setAddQty(e.target.value)} placeholder="100" /></div>
                  <div><label>Unit Price ($)</label><input type="number" value={addPrice} onChange={e => setAddPrice(e.target.value)} placeholder="2.99" step="0.01" /></div>
                </div>
                <button className="form-submit-btn green" onClick={stAddItem}>➕ Add to Store</button>
              </div>
              <div className="food-form-card remove-card">
                <h3>➖ Remove Stock</h3>
                <div className="food-form-grid">
                  <div><label>Item</label>
                    <select value={removeItem} onChange={e => setRemoveItem(e.target.value)}>
                      <option value="">— Select —</option>
                      {currentStore.inventory.map(f => <option key={f.name} value={f.name}>{f.emoji} {f.name} ({f.qty})</option>)}
                    </select>
                  </div>
                  <div><label>Reason</label>
                    <select value={removeReason} onChange={e => setRemoveReason(e.target.value)}>
                      <option value="sold">Sold</option><option value="expired">Expired</option><option value="donated">Donated</option><option value="damaged">Damaged</option>
                    </select>
                  </div>
                  <div style={{ gridColumn: '1/-1' }}><label>Quantity</label><input type="number" value={removeQty} onChange={e => setRemoveQty(e.target.value)} placeholder="1" /></div>
                </div>
                <button className="form-submit-btn red" onClick={stRemoveItem}>➖ Remove Stock</button>
              </div>
            </div>
            <div className="section-heading">📦 Inventory <span style={{ fontSize: '.78rem', color: 'var(--muted)' }}>{currentStore.inventory.length} items</span></div>
            <table className="inv-table">
              <thead><tr><th>Item</th><th>Category</th><th>Qty</th><th>Price</th><th>Level</th><th></th></tr></thead>
              <tbody>
                {currentStore.inventory.slice().sort((a, b) => a.qty - b.qty).map((f, i) => {
                  const lvl = f.qty <= 5 ? 'Critical' : f.qty <= 15 ? 'Low' : f.qty <= 40 ? 'Good' : 'Plenty'
                  const clr = f.qty <= 5 ? '#c0392b' : f.qty <= 15 ? 'var(--honey)' : 'var(--sage)'
                  const pct = Math.min(Math.round(f.qty / 80 * 100), 100)
                  return (
                    <tr key={i}>
                      <td><span style={{ marginRight: 6 }}>{f.emoji || '📦'}</span><strong>{f.name}</strong></td>
                      <td>{f.category}</td>
                      <td className="inv-qty">{f.qty}</td>
                      <td>${(f.price || 0).toFixed(2)}</td>
                      <td className="inv-bar-cell">
                        <div className="inv-bar"><div className="inv-bar-fill" style={{ width: `${pct}%`, background: clr }}></div></div>
                        <div style={{ fontSize: '.7rem', color: 'var(--muted)', marginTop: 2 }}>{lvl}</div>
                      </td>
                      <td><button className="req-del" onClick={() => saveStoreData({ ...storeData, stores: storeData.stores.map((s, si) => si !== currentStoreIdx ? s : { ...s, inventory: s.inventory.filter((_, fi) => fi !== i) }) })}>🗑️</button></td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Restaurant Inventory */}
        {view === 'st-restaurants' && storeData.restaurants.length > 0 && (
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 12, marginBottom: 20 }}>
              <div><h1 className="view-title">Restaurants</h1><p className="view-sub">Manage kitchen inventory.</p></div>
              {storeData.restaurants.length > 1 && (
                <select className="custom-select" value={currentRestIdx} onChange={e => setCurrentRestIdx(parseInt(e.target.value))}>
                  {storeData.restaurants.map((r, i) => <option key={i} value={i}>{r.name}</option>)}
                </select>
              )}
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 22 }}>
              <div className="food-form-card">
                <h3>➕ Add Kitchen Stock</h3>
                <div className="food-form-grid">
                  <div><label>Ingredient</label><input type="text" value={rsAddName} onChange={e => setRsAddName(e.target.value)} placeholder="e.g. Chicken Breast" /></div>
                  <div><label>Category</label><select value={rsAddCat} onChange={e => setRsAddCat(e.target.value)}>{['Proteins','Vegetables','Fruits','Dairy','Grains','Sauces','Beverages','Dry Goods','Other'].map(c => <option key={c}>{c}</option>)}</select></div>
                  <div><label>Quantity</label><input type="number" value={rsAddQty} onChange={e => setRsAddQty(e.target.value)} placeholder="50" /></div>
                  <div><label>Unit</label><select value={rsAddUnit} onChange={e => setRsAddUnit(e.target.value)}>{['lbs','kg','units','litres','cans','bags'].map(u => <option key={u}>{u}</option>)}</select></div>
                </div>
                <button className="form-submit-btn green" onClick={rsAddItem}>➕ Add to Kitchen</button>
              </div>
              <div className="food-form-card remove-card">
                <h3>➖ Remove Stock</h3>
                <div className="food-form-grid">
                  <div><label>Item</label>
                    <select value={rsRemoveItem} onChange={e => setRsRemoveItem(e.target.value)}>
                      <option value="">— Select —</option>
                      {currentRest.inventory.map(f => <option key={f.name} value={f.name}>{f.emoji} {f.name} ({f.qty} {f.unit})</option>)}
                    </select>
                  </div>
                  <div><label>Reason</label>
                    <select value={rsRemoveReason} onChange={e => setRsRemoveReason(e.target.value)}>
                      <option value="used">Used in Kitchen</option><option value="expired">Expired</option><option value="donated">Donated</option><option value="damaged">Damaged</option>
                    </select>
                  </div>
                  <div style={{ gridColumn: '1/-1' }}><label>Quantity</label><input type="number" value={rsRemoveQty} onChange={e => setRsRemoveQty(e.target.value)} placeholder="1" /></div>
                </div>
                <button className="form-submit-btn red" onClick={rsDoRemove}>➖ Remove Stock</button>
              </div>
            </div>
            <div className="section-heading">📦 Kitchen Inventory</div>
            <table className="inv-table">
              <thead><tr><th>Item</th><th>Category</th><th>Qty</th><th>Unit</th><th>Level</th><th></th></tr></thead>
              <tbody>
                {currentRest.inventory.slice().sort((a, b) => a.qty - b.qty).map((f, i) => {
                  const lvl = f.qty <= 5 ? 'Critical' : f.qty <= 15 ? 'Low' : f.qty <= 40 ? 'Good' : 'Plenty'
                  const clr = f.qty <= 5 ? '#c0392b' : f.qty <= 15 ? 'var(--honey)' : 'var(--sage)'
                  const pct = Math.min(Math.round(f.qty / 80 * 100), 100)
                  return (
                    <tr key={i}>
                      <td><span style={{ marginRight: 6 }}>{f.emoji || '🍽️'}</span><strong>{f.name}</strong></td>
                      <td>{f.category}</td>
                      <td className="inv-qty">{f.qty}</td>
                      <td>{f.unit}</td>
                      <td className="inv-bar-cell">
                        <div className="inv-bar"><div className="inv-bar-fill" style={{ width: `${pct}%`, background: clr }}></div></div>
                        <div style={{ fontSize: '.7rem', color: 'var(--muted)', marginTop: 2 }}>{lvl}</div>
                      </td>
                      <td><button className="req-del" onClick={() => saveStoreData({ ...storeData, restaurants: storeData.restaurants.map((r, ri) => ri !== currentRestIdx ? r : { ...r, inventory: r.inventory.filter((_, fi) => fi !== i) }) })}>🗑️</button></td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* ── DONATE TO FOOD BANK ── */}
        {view === 'st-donate' && (
          <div>
            <h1 className="view-title">🤝 Donate to Food Bank</h1>
            <p className="view-sub">Send surplus stock directly from your store to a local food bank.</p>

            {/* Sub-tabs */}
            <div style={{ display:'flex', gap:8, marginBottom:20 }}>
              <button onClick={() => setDonateTab('new')} style={{ flex:1, padding:'9px 0', borderRadius:50, border:'none', fontWeight:700, fontSize:'.83rem', cursor:'pointer', background: donateTab==='new' ? 'var(--earth)' : 'var(--card-bg)', color: donateTab==='new' ? 'white' : 'var(--muted)', boxShadow: donateTab==='new' ? 'var(--shadow)' : 'none' }}>🤝 New Donation</button>
              <button onClick={() => setDonateTab('history')} style={{ flex:1, padding:'9px 0', borderRadius:50, border:'none', fontWeight:700, fontSize:'.83rem', cursor:'pointer', background: donateTab==='history' ? 'var(--earth)' : 'var(--card-bg)', color: donateTab==='history' ? 'white' : 'var(--muted)', boxShadow: donateTab==='history' ? 'var(--shadow)' : 'none' }}>
                📋 History
                {(() => { try { const all = JSON.parse(localStorage.getItem('tt_donations') || '[]'); const mine = all.filter(d => d.donor === (user.regStoreName || user.username) || d.donor === (user.regRestName || '')); return mine.length > 0 ? <span style={{ background:'rgba(255,255,255,.3)', borderRadius:50, padding:'1px 7px', marginLeft:4, fontSize:'.75rem' }}>{mine.length}</span> : null } catch { return null } })()}
              </button>
            </div>

            {donateTab === 'history' && (() => {
              let myDonations = []
              try { myDonations = JSON.parse(localStorage.getItem('tt_donations') || '[]').filter(d => d.donor === (user.regStoreName || user.username) || d.donor === (user.regRestName || user.username)) } catch {}
              return myDonations.length === 0 ? (
                <div style={{ textAlign:'center', padding:'60px 20px', color:'var(--muted)' }}>
                  <div style={{ fontSize:'3rem', marginBottom:14 }}>🤝</div>
                  <div style={{ fontFamily:'Fraunces, serif', fontSize:'1.2rem', fontWeight:700, color:'var(--earth)', marginBottom:8 }}>No donations yet</div>
                  <div style={{ fontSize:'.88rem' }}>Your confirmed food bank donations will appear here.</div>
                </div>
              ) : (
                <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
                  {[...myDonations].reverse().map((d, i) => (
                    <div key={i} style={{ background:'var(--card-bg)', borderRadius:16, padding:'16px 18px', boxShadow:'var(--shadow)' }}>
                      <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', marginBottom:10 }}>
                        <div>
                          <div style={{ fontWeight:700, fontSize:'.95rem', color:'var(--earth)' }}>🏛️ {d.shelter}</div>
                          <div style={{ fontSize:'.78rem', color:'var(--muted)', marginTop:3 }}>📅 {d.date} &nbsp;·&nbsp; ⏰ {d.time}</div>
                        </div>
                        <span style={{ background:'#e8f5ea', color:'var(--sage)', borderRadius:50, padding:'3px 11px', fontSize:'.72rem', fontWeight:700, whiteSpace:'nowrap' }}>✅ Confirmed</span>
                      </div>
                      <div style={{ fontSize:'.78rem', fontWeight:700, color:'var(--muted)', textTransform:'uppercase', letterSpacing:'.06em', marginBottom:7 }}>Items Donated</div>
                      <div style={{ display:'flex', flexWrap:'wrap', gap:6 }}>
                        {d.items.map((item, j) => (
                          <span key={j} style={{ display:'flex', alignItems:'center', gap:5, background:'var(--bg)', borderRadius:50, padding:'4px 11px', fontSize:'.8rem', fontWeight:600 }}>
                            <span>{item.emoji}</span> {item.name} {item.qty > 1 && <span style={{ color:'var(--muted)', fontSize:'.72rem' }}>×{item.qty}</span>}
                          </span>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              )
            })()}

            {donateTab === 'new' && <>
            {/* Step 1 – pick items */}
            <div className="section-heading"><span className="step-number">1</span> Select Items to Donate</div>
            {currentStore.inventory.length === 0 ? (
              <p style={{ color: 'var(--muted)', fontStyle: 'italic', fontSize: '.85rem' }}>
                No inventory in {currentStore.name}. Add stock in the Stores tab first.
              </p>
            ) : (
              <div style={{ background: 'white', borderRadius: 14, padding: '16px 18px', boxShadow: 'var(--shadow)', marginBottom: 22 }}>
                {currentStore.inventory.map((f, i) => {
                  const selected = donateSelections[f.name] || 0
                  return (
                    <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 0', borderBottom: i < currentStore.inventory.length - 1 ? '1px solid var(--cream)' : 'none' }}>
                      <span style={{ fontSize: '1.5rem', minWidth: 32 }}>{f.emoji}</span>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontWeight: 600, fontSize: '.88rem' }}>{f.name}</div>
                        <div style={{ fontSize: '.74rem', color: 'var(--muted)' }}>{f.qty} in stock · {f.category}</div>
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <button className="qty-btn" onClick={() => setDonateSelections(prev => ({ ...prev, [f.name]: Math.max(0, (prev[f.name] || 0) - 1) }))}>−</button>
                        <span style={{ minWidth: 28, textAlign: 'center', fontWeight: 600, fontSize: '.9rem' }}>{selected}</span>
                        <button className="qty-btn" onClick={() => setDonateSelections(prev => ({ ...prev, [f.name]: Math.min(f.qty, (prev[f.name] || 0) + 1) }))}>+</button>
                      </div>
                    </div>
                  )
                })}
                <div style={{ marginTop: 12, padding: '10px 0 0', borderTop: '1px solid var(--cream)', fontSize: '.82rem', color: 'var(--muted)' }}>
                  {Object.values(donateSelections).filter(q => q > 0).length} item type(s) selected ·{' '}
                  {Object.values(donateSelections).reduce((s, q) => s + q, 0)} total units
                </div>
              </div>
            )}

            {/* Step 2 – pick food bank */}
            <div className="section-heading"><span className="step-number">2</span> Choose a Food Bank</div>
            {(shelters || []).length === 0 ? (
              <p style={{ color: 'var(--muted)', fontStyle: 'italic', fontSize: '.85rem' }}>No food banks registered yet.</p>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 22 }}>
                {(shelters || []).map((s, i) => (
                  <div
                    key={i}
                    className={`shelter-option ${selectedFB?.name === s.name ? 'selected' : ''}`}
                    onClick={() => { setSelectedFB(s); setDonateSlot(null) }}
                    style={{ cursor: 'pointer', background: 'white', borderRadius: 12, padding: '12px 16px', boxShadow: 'var(--shadow)', border: selectedFB?.name === s.name ? '2px solid var(--sage)' : '2px solid transparent', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}
                  >
                    <div>
                      <div style={{ fontWeight: 700, fontSize: '.9rem' }}>{s.name}</div>
                      <div style={{ fontSize: '.76rem', color: 'var(--muted)', marginTop: 2 }}>{s.address} {s.distanceMi ? `· ${s.distanceMi} mi` : ''}</div>
                      <div style={{ fontSize: '.74rem', color: 'var(--muted)' }}>{s.hours}</div>
                    </div>
                    <span className="badge foodbank">Food Bank</span>
                  </div>
                ))}
              </div>
            )}

            {/* Step 3 – pick time */}
            {selectedFB && (
              <>
                <div className="section-heading"><span className="step-number">3</span> Choose Drop-Off Time</div>
                <div className="time-slot-grid" style={{ marginBottom: 22 }}>
                  {['9:00 AM','10:30 AM','12:00 PM','1:30 PM','3:00 PM','4:30 PM'].map(t => (
                    <div
                      key={t}
                      className={`time-slot ${donateSlot === t ? 'selected' : ''}`}
                      onClick={() => setDonateSlot(t)}
                    >{t}</div>
                  ))}
                </div>
              </>
            )}

            {/* Summary & confirm */}
            {Object.values(donateSelections).some(q => q > 0) && selectedFB && donateSlot && (
              <div style={{ background: 'var(--cream)', borderRadius: 14, padding: '16px 18px', marginBottom: 18, fontSize: '.85rem' }}>
                <strong>Donation Summary</strong>
                <div style={{ marginTop: 8, color: 'var(--muted)' }}>
                  To: <strong>{selectedFB.name}</strong> · Drop-off: <strong>{donateSlot}</strong><br />
                  Items:{' '}
                  {Object.entries(donateSelections).filter(([,q]) => q > 0).map(([name, qty]) => {
                    const f = currentStore.inventory.find(i => i.name === name)
                    return `${f?.emoji || ''} ${name} ×${qty}`
                  }).join('  ·  ')}
                </div>
              </div>
            )}

            <button
              className="form-submit-btn green"
              style={{ opacity: (Object.values(donateSelections).some(q => q > 0) && selectedFB && donateSlot) ? 1 : 0.4, cursor: (Object.values(donateSelections).some(q => q > 0) && selectedFB && donateSlot) ? 'pointer' : 'not-allowed', marginTop: 4 }}
              onClick={confirmStoreDonation}
              disabled={!Object.values(donateSelections).some(q => q > 0) || !selectedFB || !donateSlot}
            >
              ✅ Confirm Donation →
            </button>
            </>}
          </div>
        )}

        {/* Owner Settings */}
        {view === 'st-owner' && (
          <div>
            <h1 className="view-title">Owner Settings</h1>
            <div className="stat-cards" style={{ marginBottom: 22 }}>
              {[['Full-Time', 'staffFT'], ['Part-Time', 'staffPT'], ['Casual', 'staffCas']].map(([l, k]) => (
                <div key={k} className="stat-card">
                  <div className="sc-label">{l}</div>
                  <div className="counter-row" style={{ marginTop: 8 }}>
                    <button className="counter-btn" onClick={() => saveStoreData({ ...storeData, [k]: Math.max(0, (storeData[k] || 0) - 1) })}>−</button>
                    <span className="counter-num">{storeData[k] || 0}</span>
                    <button className="counter-btn" onClick={() => saveStoreData({ ...storeData, [k]: (storeData[k] || 0) + 1 })}>+</button>
                  </div>
                </div>
              ))}
            </div>
            <div style={{ marginTop: 28 }}>
              <SettingsPanel
                theme={theme}
                onThemeChange={onThemeChange}
                user={user}
                onLogout={onLogout}
                onClearData={() => {
                  if (!window.confirm('Clear all store data? This will reset all inventory across every location and remove your donation history. This cannot be undone.')) return
                  const clearedStores = storeData.stores.map(s => ({ ...s, inventory: [], soldToday: 0 }))
                  const clearedRests  = storeData.restaurants.map(r => ({ ...r, inventory: [], serviceToday: 0 }))
                  saveStoreData({ ...storeData, stores: clearedStores, restaurants: clearedRests, staffFT: 0, staffPT: 0, staffCas: 0 })
                  onClearDonations(d => d.donor === (user.regStoreName || user.username))
                  showToast('🗑️ All store data cleared')
                }}
                onExportData={() => {
                  const data = { stores: storeData.stores, restaurants: storeData.restaurants, exportedAt: new Date().toISOString() }
                  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
                  const url = URL.createObjectURL(blob)
                  const a = document.createElement('a'); a.href = url; a.download = 'store-data.json'; a.click()
                  URL.revokeObjectURL(url)
                  showToast('📤 Data exported!')
                }}
                locationSection={
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
                    {(user.bizType === 'store' || user.bizType === 'both') && (
                      <div>
                        <div style={{ fontSize: '.78rem', fontWeight: 700, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '.04em', marginBottom: 8 }}>
                          🛒 {storeData.stores[0]?.name || 'Store'}
                        </div>
                        <LocationSettingsRow
                          label="Store Address"
                          sub="Updates your pin on the customer Nearby Stores map"
                          address={storeData.stores[0]?.address || ''}
                          loading={storeLocLoading}
                          error={storeLocError}
                          input={storeLocInput}
                          setInput={setStoreLocInput}
                          onSubmit={addr => updateStoreLocation(addr, 0)}
                          onGPS={() => {
                            if (!navigator.geolocation) { setStoreLocError('Geolocation not supported.'); return }
                            setStoreLocLoading(true); setStoreLocError('')
                            navigator.geolocation.getCurrentPosition(
                              async pos => {
                                const { latitude: lat, longitude: lng } = pos.coords
                                try {
                                  await loadGoogleMaps()
                                  const geocoder = new window.google.maps.Geocoder()
                                  geocoder.geocode({ location: { lat, lng } }, (results, status) => {
                                    const addr = (status === 'OK' && results[0]) ? results[0].formatted_address : lat.toFixed(4) + ', ' + lng.toFixed(4)
                                    updateStoreLocation(addr, 0)
                                  })
                                } catch { updateStoreLocation(lat.toFixed(4) + ', ' + lng.toFixed(4), 0) }
                              },
                              () => { setStoreLocError('Could not get GPS location.'); setStoreLocLoading(false) },
                              { timeout: 10000 }
                            )
                          }}
                          onClear={null}
                        />
                      </div>
                    )}
                    {(user.bizType === 'restaurant' || user.bizType === 'both') && (
                      <div>
                        <div style={{ fontSize: '.78rem', fontWeight: 700, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '.04em', marginBottom: 8 }}>
                          🍴 {storeData.restaurants[0]?.name || 'Restaurant'}
                        </div>
                        <LocationSettingsRow
                          label="Restaurant Address"
                          sub="Updates your pin on the customer Nearby Stores map"
                          address={storeData.restaurants[0]?.address || ''}
                          loading={restLocLoading}
                          error={restLocError}
                          input={restLocInput}
                          setInput={setRestLocInput}
                          onSubmit={addr => updateRestLocation(addr, 0)}
                          onGPS={() => {
                            if (!navigator.geolocation) { setRestLocError('Geolocation not supported.'); return }
                            setRestLocLoading(true); setRestLocError('')
                            navigator.geolocation.getCurrentPosition(
                              async pos => {
                                const { latitude: lat, longitude: lng } = pos.coords
                                try {
                                  await loadGoogleMaps()
                                  const geocoder = new window.google.maps.Geocoder()
                                  geocoder.geocode({ location: { lat, lng } }, (results, status) => {
                                    const addr = (status === 'OK' && results[0]) ? results[0].formatted_address : lat.toFixed(4) + ', ' + lng.toFixed(4)
                                    updateRestLocation(addr, 0)
                                  })
                                } catch { updateRestLocation(lat.toFixed(4) + ', ' + lng.toFixed(4), 0) }
                              },
                              () => { setRestLocError('Could not get GPS location.'); setRestLocLoading(false) },
                              { timeout: 10000 }
                            )
                          }}
                          onClear={null}
                        />
                      </div>
                    )}
                  </div>
                }
              />
            </div>
          </div>
        )}
      </div>
      {toast && <Toast msg={toast} />}
    </div>
  )
}

// ─────────────────────────────────────────────
// AUTH SCREEN  (Login + Sign-up)
// ─────────────────────────────────────────────
function AuthScreen({ onLogin, theme, onThemeChange, initialTab = 'login', onBack }) {
  const [tab, setTab] = useState(initialTab)
  const [loginUser, setLoginUser] = useState('')
  const [loginPass, setLoginPass] = useState('')
  const [loginErr, setLoginErr] = useState('')
  const [signupUser, setSignupUser] = useState('')
  const [signupPass, setSignupPass] = useState('')
  const [signupErr, setSignupErr] = useState('')
  const [role, setRole] = useState('customer')
  const [bizType, setBizType] = useState('store')
  const [fbName, setFbName] = useState('')
  const [fbAddress, setFbAddress] = useState('')
  const [fbHours, setFbHours] = useState('')
  const [storeName, setStoreName] = useState('')
  const [storeAddr, setStoreAddr] = useState('')
  const [restName, setRestName] = useState('')
  const [restAddr, setRestAddr] = useState('')
  const cardRef = React.useRef(null)
  const currentPalette = PALETTES.find(p => (theme || 'earthy-light').startsWith(p.id)) || PALETTES[0]
  const [adminOpen, setAdminOpen] = React.useState(false)
  const [adminAuthed, setAdminAuthed] = React.useState(false)
  const [adminUser, setAdminUser] = React.useState('')
  const [adminPass, setAdminPass] = React.useState('')
  const [adminErr, setAdminErr] = React.useState('')

  function doAdminLogin() {
    if (adminUser === 'rats' && adminPass === '098') {
      setAdminAuthed(true)
      setAdminErr('')
    } else {
      setAdminErr('Incorrect credentials.')
    }
  }

  function closeAdmin() {
    setAdminOpen(false)
    setAdminAuthed(false)
    setAdminUser('')
    setAdminPass('')
    setAdminErr('')
  }

  useEffect(() => {
    const handler = (e) => {
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.tagName === 'SELECT') return
      if (e.key === 'ArrowDown') { e.preventDefault(); cardRef.current?.scrollBy({ top: 150, behavior: 'smooth' }) }
      if (e.key === 'ArrowUp')   { e.preventDefault(); cardRef.current?.scrollBy({ top: -150, behavior: 'smooth' }) }
    }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [])

  const [accounts, setAccounts] = useState(() => loadFromStorage('tt_accounts', DEMO_ACCOUNTS))

  // Sync accounts from Firestore so logins created on other devices work
  useEffect(() => {
    dbLoad('tt_accounts', DEMO_ACCOUNTS).then(data => {
      if (data && data.length) {
        setAccounts(data)
        localStorage.setItem('tt_accounts', JSON.stringify(data))
      }
    })
  }, [])

  function doLogin() {
    const acct = accounts.find(a => a.username === loginUser && a.password === loginPass)
    if (!acct) { setLoginErr('Incorrect username or password.'); return }
    setLoginErr('')
    onLogin(acct)
  }

  function doSignup() {
    if (!signupUser || !signupPass) { setSignupErr('Please fill in both fields.'); return }
    if (accounts.find(a => a.username === signupUser.trim())) { setSignupErr('Username already taken.'); return }
    

    let acct
    if (role === 'foodbank') {
      if (!fbName || !fbAddress || !fbHours) { setSignupErr('Please fill in food bank details.'); return }
      acct = { username: signupUser, password: signupPass, role: 'foodbank', fbName, fbAddress, fbHours }
    } else if (role === 'business') {
      if ((bizType === 'store' || bizType === 'both') && (!storeName || !storeAddr)) { setSignupErr('Please fill in store details.'); return }
      if ((bizType === 'restaurant' || bizType === 'both') && (!restName || !restAddr)) { setSignupErr('Please fill in restaurant details.'); return }
      acct = { username: signupUser, password: signupPass, role: 'business', bizType, regStoreName: storeName, regStoreAddr: storeAddr, regRestName: restName, regRestAddr: restAddr }
    } else {
      acct = { username: signupUser, password: signupPass, role: 'customer' }
    }

    const updated = [...accounts, acct]
    setAccounts(updated)
    localStorage.setItem('tt_accounts', JSON.stringify(updated))
    dbSave('tt_accounts', updated)
    setSignupErr('')
    onLogin(acct)
  }

  return (
    <div id="auth-screen" style={{ background: currentPalette.authGrad, transition: 'background 0.5s ease' }}>

      {/* ── Admin button — bottom left ── */}
      <button
        onClick={() => setAdminOpen(true)}
        style={{
          position: 'fixed', bottom: 24, left: 24, zIndex: 200,
          background: 'rgba(255,255,255,.1)', backdropFilter: 'blur(10px)',
          border: '1px solid rgba(255,255,255,.15)', borderRadius: 10,
          color: 'rgba(255,255,255,.6)', fontFamily: "'DM Sans',sans-serif",
          fontSize: '.75rem', fontWeight: 700, padding: '8px 14px',
          cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6,
          transition: 'background .2s, color .2s',
        }}
        onMouseEnter={e => { e.currentTarget.style.background = 'rgba(255,255,255,.18)'; e.currentTarget.style.color = 'white' }}
        onMouseLeave={e => { e.currentTarget.style.background = 'rgba(255,255,255,.1)'; e.currentTarget.style.color = 'rgba(255,255,255,.6)' }}
      >
        🛡️ Admin
      </button>

      {/* ── Admin modal ── */}
      {adminOpen && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,.6)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}
          onClick={e => e.target === e.currentTarget && closeAdmin()}>
          <div style={{ background: 'white', borderRadius: 20, padding: '28px 26px', width: '100%', maxWidth: 420, maxHeight: '85vh', overflowY: 'auto', fontFamily: "'DM Sans',sans-serif" }}>

            {/* ── Header ── */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <span style={{ fontSize: '1.3rem' }}>🛡️</span>
                <h2 style={{ fontSize: '1.1rem', fontWeight: 800, color: '#1a1a1b', margin: 0 }}>
                  {adminAuthed ? 'Admin Panel' : 'Admin Sign In'}
                </h2>
              </div>
              <button onClick={closeAdmin} style={{ background: 'none', border: 'none', fontSize: '1.2rem', cursor: 'pointer', color: '#999' }}>✕</button>
            </div>

            {/* ── Login gate ── */}
            {!adminAuthed ? (
              <div>
                <p style={{ fontSize: '.84rem', color: '#888', marginBottom: 18 }}>
                  This area is restricted. Enter your admin credentials to continue.
                </p>
                {adminErr && (
                  <div style={{ background: '#fde8dc', color: '#c4714a', borderRadius: 9, padding: '9px 14px', fontSize: '.82rem', fontWeight: 600, marginBottom: 14 }}>
                    ⚠️ {adminErr}
                  </div>
                )}
                <label style={{ fontSize: '.76rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.06em', color: '#888', display: 'block', marginBottom: 5 }}>Username</label>
                <input
                  type="text"
                  value={adminUser}
                  onChange={e => setAdminUser(e.target.value)}
                  placeholder="Admin username"
                  autoComplete="off"
                  style={{ width: '100%', padding: '10px 14px', borderRadius: 10, border: '2px solid #eee', fontFamily: "'DM Sans',sans-serif", fontSize: '.9rem', marginBottom: 12, outline: 'none', boxSizing: 'border-box' }}
                  onFocus={e => e.target.style.borderColor = '#c4714a'}
                  onBlur={e => e.target.style.borderColor = '#eee'}
                />
                <label style={{ fontSize: '.76rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.06em', color: '#888', display: 'block', marginBottom: 5 }}>Password</label>
                <input
                  type="password"
                  value={adminPass}
                  onChange={e => setAdminPass(e.target.value)}
                  placeholder="Admin password"
                  onKeyDown={e => e.key === 'Enter' && doAdminLogin()}
                  style={{ width: '100%', padding: '10px 14px', borderRadius: 10, border: '2px solid #eee', fontFamily: "'DM Sans',sans-serif", fontSize: '.9rem', marginBottom: 18, outline: 'none', boxSizing: 'border-box' }}
                  onFocus={e => e.target.style.borderColor = '#c4714a'}
                  onBlur={e => e.target.style.borderColor = '#eee'}
                />
                <button
                  onClick={doAdminLogin}
                  style={{ width: '100%', padding: '12px 16px', borderRadius: 10, border: 'none', background: 'linear-gradient(135deg,#3d2e1e,#c4714a)', color: 'white', fontFamily: "'DM Sans',sans-serif", fontWeight: 700, fontSize: '.92rem', cursor: 'pointer' }}
                >
                  Sign In to Admin →
                </button>
              </div>
            ) : (
              <div>
                {/* ── Accounts list ── */}
                <div style={{ fontSize: '.72rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.07em', color: '#999', marginBottom: 10 }}>
                  Registered Accounts ({accounts.length})
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 20 }}>
                  {accounts.map((a, i) => (
                    <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, background: '#f9f9f9', borderRadius: 10, padding: '10px 14px' }}>
                      <span style={{ fontSize: '1.1rem' }}>
                        {a.role === 'foodbank' ? '🏛️' : a.role === 'business' ? '🏪' : '🛒'}
                      </span>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontWeight: 700, fontSize: '.88rem', color: '#1a1a1b' }}>@{a.username}</div>
                        <div style={{ fontSize: '.74rem', color: '#999' }}>
                          {a.role === 'foodbank' ? `Food Bank · ${a.fbName || ''}` : a.role === 'business' ? `Business · ${a.regStoreName || ''}` : 'Customer'}
                        </div>
                      </div>
                      <button
                        onClick={() => {
                          if (!window.confirm(`Delete account "@${a.username}"?`)) return
                          const updated = accounts.filter((_, idx) => idx !== i)
                          setAccounts(updated)
                          localStorage.setItem('tt_accounts', JSON.stringify(updated))
                          dbSave('tt_accounts', updated)
                        }}
                        style={{ background: '#fde8dc', border: 'none', borderRadius: 7, color: '#c4714a', fontWeight: 700, fontSize: '.75rem', padding: '5px 10px', cursor: 'pointer' }}
                      >
                        Delete
                      </button>
                    </div>
                  ))}
                </div>

                {/* ── Danger zone ── */}
                <div style={{ borderTop: '1px solid #f0f0f0', paddingTop: 16 }}>
                  <div style={{ fontSize: '.72rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.07em', color: '#e05a5a', marginBottom: 10 }}>
                    ⚠️ Danger Zone
                  </div>
                  <button
                    onClick={() => {
                      if (!window.confirm('Reset ALL accounts to demo defaults? This cannot be undone.')) return
                      setAccounts(DEMO_ACCOUNTS)
                      localStorage.setItem('tt_accounts', JSON.stringify(DEMO_ACCOUNTS))
                      dbSave('tt_accounts', DEMO_ACCOUNTS)
                    }}
                    style={{ width: '100%', padding: '10px 16px', borderRadius: 10, border: '1.5px solid #fbb', background: '#fff5f5', color: '#c0392b', fontFamily: "'DM Sans',sans-serif", fontWeight: 700, fontSize: '.84rem', cursor: 'pointer', marginBottom: 8 }}
                  >
                    🔄 Reset to Demo Accounts
                  </button>
                  <button
                    onClick={() => {
                      if (!window.confirm('Wipe ALL accounts AND all app data from localStorage? This cannot be undone.')) return
                      localStorage.clear()
                      setAccounts(DEMO_ACCOUNTS)
                      localStorage.setItem('tt_accounts', JSON.stringify(DEMO_ACCOUNTS))
                      dbSave('tt_accounts', DEMO_ACCOUNTS)
                      closeAdmin()
                    }}
                    style={{ width: '100%', padding: '10px 16px', borderRadius: 10, border: '1.5px solid #fbb', background: '#fff0f0', color: '#c0392b', fontFamily: "'DM Sans',sans-serif", fontWeight: 700, fontSize: '.84rem', cursor: 'pointer' }}
                  >
                    🗑️ Wipe All App Data
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ── Theme picker — top-right floating swatches ── */}
      <div className="auth-theme-picker">
        {PALETTES.map(p => (
          <button
            key={p.id}
            title={p.label}
            className={`auth-swatch${currentPalette.id === p.id ? ' active' : ''}`}
            onClick={() => { onThemeChange(p.id + '-light') }}
            style={{ background: `linear-gradient(135deg, ${p.bg} 50%, ${p.fg} 50%)` }}
          />
        ))}
      </div>

      <div className="auth-card" ref={cardRef}>
        {onBack && (
        <button onClick={onBack} style={{background:'none',border:'none',cursor:'pointer',color:'var(--muted)',fontSize:'.82rem',fontWeight:600,fontFamily:"'DM Sans',sans-serif",marginBottom:8,display:'flex',alignItems:'center',gap:5,padding:'4px 0',alignSelf:'flex-start'}}>← Back to home</button>
      )}
      <div className="auth-logo">Together<span>TableAI</span></div>
        <p className="auth-tagline">Bringing communities to the table, together.</p>
        <div className="auth-tabs">
          <button className={`auth-tab ${tab === 'login' ? 'active' : ''}`} onClick={() => setTab('login')}>Sign In</button>
          <button className={`auth-tab ${tab === 'signup' ? 'active' : ''}`} onClick={() => setTab('signup')}>Create Account</button>
        </div>

        {tab === 'login' && (
          <div className="auth-step active">
            {loginErr && <div className="auth-error show">{loginErr}</div>}
            <div className="auth-form">
              <label>Username</label>
              <input type="text" value={loginUser} onChange={e => setLoginUser(e.target.value)} placeholder="Enter your username" autoComplete="off" />
              <label>Password</label>
              <input type="password" value={loginPass} onChange={e => setLoginPass(e.target.value)} placeholder="Enter your password" onKeyDown={e => e.key === 'Enter' && doLogin()} />
              <button className="auth-submit" onClick={doLogin}>Sign In →</button>
            </div>

          </div>
        )}

        {tab === 'signup' && (
          <div className="auth-step active">
            {signupErr && <div className="auth-error show">{signupErr}</div>}
            <div className="auth-form">
              <label>Choose your role</label>
              <div className="auth-role-grid">
                {[['customer', '🛒', 'Customer'], ['foodbank', '🏛️', 'Food Bank Owner'], ['business', '💼', 'Business Owner']].map(([r, icon, label]) => (
                  <div key={r} className={`role-card ${role === r ? 'selected' : ''}`} onClick={() => setRole(r)}>
                    <div className="r-icon">{icon}</div><div className="r-name">{label}</div>
                  </div>
                ))}
              </div>

              {role === 'foodbank' && (
                <div style={{ background: 'var(--cream)', borderRadius: 14, padding: '14px 16px', marginBottom: 14 }}>
                  <div style={{ fontSize: '.8rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.06em', color: 'var(--clay)', marginBottom: 10 }}>🏛️ Register Your Food Bank</div>
                  <label>Food Bank Name</label>
                  <input type="text" value={fbName} onChange={e => setFbName(e.target.value)} placeholder="e.g. Westside Community Pantry" />
                  <label>Address</label>
                  <input type="text" value={fbAddress} onChange={e => setFbAddress(e.target.value)} placeholder="e.g. 100 Main Street" />
                  <label>Hours</label>
                  <input type="text" value={fbHours} onChange={e => setFbHours(e.target.value)} placeholder="e.g. Mon–Fri · 9am–5pm" />
                </div>
              )}

              {role === 'business' && (
                <div style={{ marginBottom: 14 }}>
                  <label>Business Type</label>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 9, marginBottom: 4 }}>
                    {[['store', '🏪', 'Store'], ['restaurant', '🍽️', 'Restaurant'], ['both', '🏢', 'Both']].map(([t, icon, label]) => (
                      <div key={t} className={`role-card ${bizType === t ? 'selected' : ''}`} onClick={() => setBizType(t)}>
                        <div className="r-icon">{icon}</div><div className="r-name">{label}</div>
                      </div>
                    ))}
                  </div>
                  {(bizType === 'store' || bizType === 'both') && (
                    <div style={{ background: 'var(--cream)', borderRadius: 14, padding: '14px 16px', marginBottom: 10 }}>
                      <label>Store Name</label>
                      <input type="text" value={storeName} onChange={e => setStoreName(e.target.value)} placeholder="e.g. My Corner Market" />
                      <label>Address</label>
                      <input type="text" value={storeAddr} onChange={e => setStoreAddr(e.target.value)} placeholder="e.g. 200 Oak Street" />
                    </div>
                  )}
                  {(bizType === 'restaurant' || bizType === 'both') && (
                    <div style={{ background: 'var(--cream)', borderRadius: 14, padding: '14px 16px', marginBottom: 10 }}>
                      <label>Restaurant Name</label>
                      <input type="text" value={restName} onChange={e => setRestName(e.target.value)} placeholder="e.g. The Family Kitchen" />
                      <label>Address</label>
                      <input type="text" value={restAddr} onChange={e => setRestAddr(e.target.value)} placeholder="e.g. 300 Elm Avenue" />
                    </div>
                  )}
                </div>
              )}

              <label>Username</label>
              <input
                type="text"
                value={signupUser}
                onChange={e => setSignupUser(e.target.value)}
                placeholder="Pick a username"
                autoComplete="off"
                style={signupUser && accounts.find(a => a.username === signupUser.trim())
                  ? { borderColor: '#c0392b', background: '#fff5f5' }
                  : signupUser && signupUser.length >= 3 && !accounts.find(a => a.username === signupUser.trim())
                  ? { borderColor: 'var(--sage)', background: '#f6faf6' }
                  : {}}
              />
              {signupUser && accounts.find(a => a.username === signupUser.trim()) && (
                <div style={{ marginTop: -8, marginBottom: 8, fontSize: '.78rem', color: '#c0392b', fontWeight: 600, display: 'flex', alignItems: 'center', gap: 4 }}>
                  ✕ Username already taken
                </div>
              )}
              {signupUser && signupUser.length >= 3 && !accounts.find(a => a.username === signupUser.trim()) && (
                <div style={{ marginTop: -8, marginBottom: 8, fontSize: '.78rem', color: 'var(--sage)', fontWeight: 600, display: 'flex', alignItems: 'center', gap: 4 }}>
                  ✓ Username is available
                </div>
              )}
              <label>Password</label>
              <input type="password" value={signupPass} onChange={e => setSignupPass(e.target.value)} placeholder="Create a password" onKeyDown={e => e.key === 'Enter' && doSignup()} />
              <button className="auth-submit" onClick={doSignup}>Create Account →</button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

// ─────────────────────────────────────────────
// ROOT APP
// ─────────────────────────────────────────────
export default function App() {
  // ── Session (localStorage only — device-specific) ─────────
  const [currentUser, setCurrentUser] = useState(() => {
    try {
      const saved = localStorage.getItem('tt_current_user')
      if (!saved) return null
      const u = JSON.parse(saved)
      const accounts = loadFromStorage('tt_accounts', DEMO_ACCOUNTS)
      return accounts.find(a => a.username === u.username && a.password === u.password) || null
    } catch { return null }
  })

  const [theme, setTheme] = useState(() => {
    const saved = localStorage.getItem('tt_theme') || 'earthy-light'
    return saved.endsWith('-dark') ? saved.replace('-dark', '-light') : saved
  })

  useEffect(() => {
    applyTheme(theme)
    localStorage.setItem('tt_theme', theme)
  }, [theme])

  // ── Shared state (synced via Firestore real-time listeners) ─
  const [shelters, setShelters] = useState(() => loadFromStorage('tt_shelters', []))
  const [groceryStores, setGroceryStores] = useState(() => loadFromStorage('tt_stores', []))
  const [sharedRestaurants, setSharedRestaurants] = useState(() => loadFromStorage('tt_restaurants', []))
  const [incomingDonations, setIncomingDonations] = useState(() => loadFromStorage('tt_donations', []))

  // ── On mount: pull latest from Firestore + subscribe ───────
  useEffect(() => {
    // Load shared data once from Firestore (initial sync)
    dbLoad('tt_shelters', []).then(data => setShelters(data))
    dbLoad('tt_stores', []).then(data => setGroceryStores(data))
    dbLoad('tt_restaurants', []).then(data => setSharedRestaurants(data))
    dbLoad('tt_donations', []).then(data => setIncomingDonations(data))

    // Real-time listeners for cross-profile live updates
    const unsubDon = dbSubscribe('tt_donations', data => setIncomingDonations(data))
    const unsubShelters = dbSubscribe('tt_shelters', data => setShelters(data))
    const unsubStores = dbSubscribe('tt_stores', data => setGroceryStores(data))
    const unsubRests = dbSubscribe('tt_restaurants', data => setSharedRestaurants(data))

    return () => { unsubDon(); unsubShelters(); unsubStores(); unsubRests() }
  }, [])

  // ── Also sync per-user data from Firestore on login ────────
  useEffect(() => {
    if (!currentUser) return
    const key = currentUser.role === 'foodbank'
      ? `tt_fb_${currentUser.username}`
      : currentUser.role === 'business'
        ? `tt_store_${currentUser.username}`
        : `tt_user_${currentUser.username}`
    dbLoad(key, null).then(data => {
      if (data) localStorage.setItem(key, JSON.stringify(data))
    })
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentUser?.username])

  function handleLogin(acct) {
    if (acct.role === 'foodbank' && acct.fbName) {
      setShelters(prev => {
        if (prev.find(s => s.name === acct.fbName)) return prev
        const newEntry = {
          name: acct.fbName, address: acct.fbAddress || '',
          distanceMi: 0, hours: acct.fbHours || 'Call ahead',
          openHours: [9, 17], openDays: [1,2,3,4,5,6],
          type: 'foodbank', peopleNeeded: 0, maxPeople: 300, needLevel: 'medium',
          lat: null, lng: null
        }
        const updated = [...prev, newEntry]
        localStorage.setItem('tt_shelters', JSON.stringify(updated))
        dbSave('tt_shelters', updated)
        // Geocode address async and update with lat/lng
        geocodeAddress(acct.fbAddress).then(coords => {
          if (!coords) return
          setShelters(cur => {
            const patched = cur.map(s => s.name === acct.fbName ? { ...s, lat: coords.lat, lng: coords.lng } : s)
            localStorage.setItem('tt_shelters', JSON.stringify(patched))
            dbSave('tt_shelters', patched)
            return patched
          })
        })
        return updated
      })
    }
    if (acct.role === 'business' && acct.regStoreName && (acct.bizType === 'store' || acct.bizType === 'both')) {
      setGroceryStores(prev => {
        if (prev.find(s => s.name === acct.regStoreName)) return prev
        const newEntry = {
          name: acct.regStoreName, address: acct.regStoreAddr || '',
          distanceMi: 0, hours: 'Daily · 9am–8pm',
          openHours: [9, 20], openDays: [0,1,2,3,4,5,6],
          rating: 4.0, stocks: [], type: 'grocery', lat: null, lng: null
        }
        const updated = [...prev, newEntry]
        localStorage.setItem('tt_stores', JSON.stringify(updated))
        dbSave('tt_stores', updated)
        geocodeAddress(acct.regStoreAddr).then(coords => {
          if (!coords) return
          setGroceryStores(cur => {
            const patched = cur.map(s => s.name === acct.regStoreName ? { ...s, lat: coords.lat, lng: coords.lng } : s)
            localStorage.setItem('tt_stores', JSON.stringify(patched))
            dbSave('tt_stores', patched)
            return patched
          })
        })
        return updated
      })
    }
    if (acct.role === 'business' && acct.regRestName && (acct.bizType === 'restaurant' || acct.bizType === 'both')) {
      setSharedRestaurants(prev => {
        if (prev.find(r => r.name === acct.regRestName)) return prev
        const newEntry = {
          name: acct.regRestName, address: acct.regRestAddr || '',
          distanceMi: 0, hours: 'Daily · 11am–10pm',
          openHours: [11, 22], openDays: [0,1,2,3,4,5,6],
          rating: 4.0, type: 'restaurant', lat: null, lng: null
        }
        const updated = [...prev, newEntry]
        localStorage.setItem('tt_restaurants', JSON.stringify(updated))
        dbSave('tt_restaurants', updated)
        geocodeAddress(acct.regRestAddr).then(coords => {
          if (!coords) return
          setSharedRestaurants(cur => {
            const patched = cur.map(r => r.name === acct.regRestName ? { ...r, lat: coords.lat, lng: coords.lng } : r)
            localStorage.setItem('tt_restaurants', JSON.stringify(patched))
            dbSave('tt_restaurants', patched)
            return patched
          })
        })
        return updated
      })
    }
    // Save account to Firestore so other devices can log in
    const accounts = loadFromStorage('tt_accounts', DEMO_ACCOUNTS)
    if (!accounts.find(a => a.username === acct.username)) {
      const updated = [...accounts, acct]
      localStorage.setItem('tt_accounts', JSON.stringify(updated))
      dbSave('tt_accounts', updated)
    }
    setCurrentUser(acct)
    localStorage.setItem('tt_current_user', JSON.stringify(acct))
  }

  function handleLogout() {
    setCurrentUser(null)
    localStorage.removeItem('tt_current_user')
  }

  function handleDonationUpdate(donation) {
    setIncomingDonations(prev => {
      const updated = [donation, ...prev]
      localStorage.setItem('tt_donations', JSON.stringify(updated))
      dbSave('tt_donations', updated)
      return updated
    })
  }

  function handleClearDonations(filterFn) {
    setIncomingDonations(prev => {
      const updated = prev.filter(d => !filterFn(d))
      localStorage.setItem('tt_donations', JSON.stringify(updated))
      dbSave('tt_donations', updated)
      return updated
    })
  }

  function handleUpdateStoreInventory(storeName, stocks, storesList) {
    setGroceryStores(prev => {
      const updated = prev.map(s => {
        if (s.name !== storeName) return s
        return { ...s, stocks, inventory: storesList.find(st => st.name === storeName)?.inventory || s.inventory || [] }
      })
      localStorage.setItem('tt_stores', JSON.stringify(updated))
      dbSave('tt_stores', updated)
      return updated
    })
  }

  if (!currentUser) {
    return <AuthScreen onLogin={handleLogin} theme={theme} onThemeChange={setTheme} initialTab={window.__tt_auth_tab || 'login'} onBack={() => { document.getElementById('lp-wrap').style.display = ''; document.getElementById('root').style.display = 'none'; window.scrollTo(0,0) }} />
  }

  if (currentUser.role === 'customer') {
    return (
      <CustomerApp
        user={currentUser}
        onLogout={handleLogout}
        shelters={shelters}
        setShelters={newShelters => {
          setShelters(newShelters)
          localStorage.setItem('tt_shelters', JSON.stringify(newShelters))
        }}
        groceryStores={groceryStores}
        sharedRestaurants={sharedRestaurants}
        onDonationUpdate={handleDonationUpdate}
        theme={theme}
        onThemeChange={setTheme}
      />
    )
  }

  if (currentUser.role === 'foodbank') {
    return <FoodbankApp user={currentUser} onLogout={handleLogout} incomingDonations={incomingDonations} shelters={shelters} setShelters={setShelters} theme={theme} onThemeChange={setTheme} onClearDonations={handleClearDonations} />
  }

  if (currentUser.role === 'business') {
    return <StoreApp user={currentUser} onLogout={handleLogout} shelters={shelters} onDonationUpdate={handleDonationUpdate} onUpdateStoreInventory={handleUpdateStoreInventory} theme={theme} onThemeChange={setTheme} onClearDonations={handleClearDonations} setGroceryStores={setGroceryStores} setSharedRestaurants={setSharedRestaurants} />
  }

  return <AuthScreen onLogin={handleLogin} theme={theme} onThemeChange={setTheme} initialTab={window.__tt_auth_tab || 'login'} onBack={() => { document.getElementById('lp-wrap').style.display = ''; document.getElementById('root').style.display = 'none'; window.scrollTo(0,0) }} />
}
