// ─────────────────────────────────────────────────────────
//  FIREBASE CONFIG  —  Together Table v19
//
//  Firebase is OPTIONAL — the app works fully offline without it.
//  To enable cross-device sync, follow the setup steps in README.md
//  and add your keys to the .env file.
// ─────────────────────────────────────────────────────────

import { initializeApp, getApps } from 'firebase/app'
import { getFirestore } from 'firebase/firestore'

const firebaseConfig = {
  apiKey:            process.env.REACT_APP_FIREBASE_API_KEY            || '',
  authDomain:        process.env.REACT_APP_FIREBASE_AUTH_DOMAIN        || '',
  projectId:         process.env.REACT_APP_FIREBASE_PROJECT_ID         || '',
  storageBucket:     process.env.REACT_APP_FIREBASE_STORAGE_BUCKET     || '',
  messagingSenderId: process.env.REACT_APP_FIREBASE_MESSAGING_SENDER_ID || '',
  appId:             process.env.REACT_APP_FIREBASE_APP_ID             || '',
}

export const isFirebaseConfigured =
  !!(firebaseConfig.apiKey && firebaseConfig.projectId &&
     firebaseConfig.apiKey.length > 10)

let db = null
if (isFirebaseConfigured) {
  try {
    const app = getApps().length ? getApps()[0] : initializeApp(firebaseConfig)
    db = getFirestore(app)
  } catch (e) {
    console.warn('[Firebase] init failed — running in offline mode:', e.message)
  }
}

export { db }
