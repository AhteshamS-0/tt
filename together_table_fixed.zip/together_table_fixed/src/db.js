// ─────────────────────────────────────────────────────────
//  db.js  —  Hybrid Firestore + localStorage layer
//
//  Works entirely on localStorage when Firebase is not configured.
//  Automatically syncs to Firestore when keys are provided in .env
// ─────────────────────────────────────────────────────────

import { doc, getDoc, setDoc, onSnapshot, deleteDoc } from 'firebase/firestore'
import { db, isFirebaseConfigured } from './firebase.js'

const COL = 'tt_data'

function localGet(key, fallback) {
  try {
    const v = localStorage.getItem(key)
    return v ? JSON.parse(v) : fallback
  } catch { return fallback }
}

function localSet(key, value) {
  try { localStorage.setItem(key, JSON.stringify(value)) } catch {}
}

export async function dbLoad(key, fallback) {
  if (!isFirebaseConfigured || !db) return localGet(key, fallback)
  try {
    const snap = await getDoc(doc(db, COL, key))
    if (snap.exists()) {
      const data = snap.data().v
      localSet(key, data)
      return data
    }
  } catch (e) {
    console.warn(`[db] load ${key} failed, using cache`, e.message)
  }
  return localGet(key, fallback)
}

export async function dbSave(key, value) {
  localSet(key, value)
  if (!isFirebaseConfigured || !db) return
  try {
    await setDoc(doc(db, COL, key), { v: value, updatedAt: Date.now() })
  } catch (e) {
    console.warn(`[db] save ${key} failed`, e.message)
  }
}

export async function dbDelete(key) {
  try { localStorage.removeItem(key) } catch {}
  if (!isFirebaseConfigured || !db) return
  try { await deleteDoc(doc(db, COL, key)) } catch {}
}

export function dbSubscribe(key, callback) {
  if (!isFirebaseConfigured || !db) return () => {}
  return onSnapshot(
    doc(db, COL, key),
    (snap) => {
      if (snap.exists()) {
        const data = snap.data().v
        localSet(key, data)
        callback(data)
      }
    },
    (err) => console.warn(`[db] subscribe ${key} error`, err.message)
  )
}
